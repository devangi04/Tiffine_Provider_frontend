import { Text } from 'react-native';
import { Link } from 'expo-router';
// import { ScrollContainer } from '@/components/scrollable/scrollable';
import {store} from '../store'
import { Provider } from 'react-redux';

export default function HomeScreen() {
  const scrollItems = Array.from({ length: 20 }, (_, i) => ({
    id: i + 1,
    text: `Scrollable Item ${i + 1}`
  }));

  return (
<>


      <Text style={{ fontSize: 24, marginBottom: 20 }}>Home Screen</Text>
      
      <Link 
        href="/login" 
        style={{ 
          marginVertical: 10,
          padding: 12,
          backgroundColor: '#007AFF',
          color: 'white',
          borderRadius: 8,
          width: '80%',
          textAlign: 'center'
        }}
      >
        Go to Login
      </Link>
      
      <Link 
        href="/register"
        style={{
          marginVertical: 10,
          padding: 12,
          backgroundColor: '#34C759',
          color: 'white',
          borderRadius: 8,
          width: '80%',
          textAlign: 'center'
        }}
      >
        Go to Register
      </Link>
</>
      
  );
}