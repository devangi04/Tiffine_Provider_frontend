// app/_layout.tsx
import { DarkTheme, DefaultTheme, ThemeProvider } from '@react-navigation/native';
import { useFonts } from 'expo-font';
import { Stack, usePathname } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { SafeAreaView, StyleSheet, View, KeyboardAvoidingView, Platform } from 'react-native';
import 'react-native-reanimated';
import ProviderInitializer from '../components/providerintializer';

// Redux
import { Provider } from 'react-redux';
import { persistor, store } from './store';
import { PersistGate } from 'redux-persist/integration/react';

// Custom UI
import Header from '../components/header';
import BottomNavBar from '../components/navbar';
import DashboardHeader from '../components/dahsboardheader';

function LayoutContent() {
  const pathname = usePathname();
  const insets = useSafeAreaInsets();

  // ✅ Route config with header + navbar visibility
  const routeConfig: Record<
    string,
    { title: string; subtitle?: string; showHeader?: boolean; showNavbar?: boolean; headerType?: 'default' | 'dashboard' | 'none'; }
  > = {
    '/dashboard': { title: '',  showHeader: false, showNavbar: true , headerType: 'dashboard'},
    '/profile': { title: 'Profile', subtitle: 'Manage your account', showHeader: true, showNavbar: true,  headerType: 'default'},
    '/custmorelist': { title: 'Customers', subtitle: 'All registered users', showHeader: true, showNavbar: true , headerType: 'default'},
    '/response': { title: 'Responses', subtitle: 'Latest updates', showHeader: true, showNavbar: true, headerType: 'default' },
    '/schedule': { title: 'Weekley Schedule', subtitle: 'Upcoming Menus', showHeader: true, showNavbar: true , headerType: 'default'},
    '/dishmaster': { title: 'Dish Mangement', subtitle: 'Create Dishes', showHeader: true, showNavbar: true , headerType: 'default'},
    '/menupreview': { title: ' Menu preview ', subtitle: 'Create Menus', showHeader: true, showNavbar: false , headerType: 'default'},
    '/payment': { title: 'Payment Status ', subtitle: 'See Customer Payment ', showHeader: true, showNavbar: true , headerType: 'default'},
    '/savedmenu': { title: 'saved Menu', subtitle: 'See Weekley Menus', showHeader: true, showNavbar: true , headerType: 'default'},
    '/subscriptionmanagement': { title: 'Subscription details', subtitle: 'see your details', showHeader: true, showNavbar: true , headerType: 'default'},
    '/menu': { title: 'Weekly Menu ', subtitle: 'Create Menus', showHeader: true, showNavbar: false , headerType: 'default'},
    '/categorymaster': { title: 'CategoryMaster ', subtitle: 'Manage Categories', showHeader: true, showNavbar: true , headerType: 'default'},
        '/edit': { title: 'Personal Details ', subtitle: 'Manage Details', showHeader: true, showNavbar: false , headerType: 'default'},

    // ❌ No header & navbar on auth screens
    '/login': { title: '', showHeader: false, showNavbar: false },
    '/forgotpassword': { title: '', showHeader: false, showNavbar: false },
  };

  // Find current route config
  const current = Object.keys(routeConfig).find((route) =>
    pathname.startsWith(route)
  );
  const headerData = current
    ? routeConfig[current]
    : { title: '', showHeader: false, showNavbar: false, headerType: 'none' as const };

  const renderHeader = () => {
    if (!headerData.showHeader) return null;

    switch (headerData.headerType) {
      case 'dashboard':
        return <DashboardHeader />;
      case 'default':
        return <Header title={headerData.title} subtitle={headerData.subtitle} />;
      case 'none':
      default:
        return null;
    }
  };

  return (
    <View style={styles.container}>
      {/* ✅ Sticky Header */}
      <View style={styles.stickyHeader}>
        {renderHeader()}
      </View>
      
      {/* ✅ Main Content Area */}
      <View style={styles.content}>
        <Stack
          screenOptions={{
            headerShown: false,
            animation: 'slide_from_right',
            gestureEnabled: true,
            presentation: 'card',
          }}
        >
         
          <Stack.Screen name="welcome"/>
          <Stack.Screen name="forgotpassword" />
          <Stack.Screen name="(tabs)" />
          <Stack.Screen name="+not-found" />
        </Stack>
      </View>

      {/* ✅ Bottom Navbar - Will AUTO-HIDE when keyboard opens */}
      {headerData.showNavbar && <BottomNavBar />}

      <StatusBar style="light" />
    </View>
  );
}

export default function RootLayout() {
  const [loaded] = useFonts({
    SpaceMono: require('../assets/fonts/SpaceMono-Regular.ttf'),
  });

  if (!loaded) return null;

  return (
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <ProviderInitializer />
        <ThemeProvider value={DefaultTheme}>
          <SafeAreaProvider>
            <LayoutContent />
          </SafeAreaProvider>
        </ThemeProvider>
      </PersistGate>
    </Provider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f7fa',
  },
  stickyHeader: {
    zIndex: 1000,
    elevation: 1000,
  },
  content: {
    flex: 1,
  },
});