import React, { useState, useEffect, useRef } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  StyleSheet, 
  Alert, 
  ScrollView,
  Platform,
  SafeAreaView,
  StatusBar,
  Animated,
  Dimensions,
  KeyboardAvoidingView,
  ActivityIndicator
} from 'react-native';
import axios from 'axios';
const { width } = Dimensions.get('window');
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons, FontAwesome } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useAppDispatch } from './store/hooks';
import { setProvider, setLoading, setError } from './store/slices/providerslice';
import OTPInputBoxes from '@/components/otpbox';

// Floating Input Component
const FloatingInput = ({ 
  label, 
  value, 
  onChangeText, 
  keyboardType = 'default',
  secureTextEntry = false,
  showPasswordToggle = false,
  onTogglePassword,
  maxLength,
  autoCapitalize = 'none',
  autoCorrect = false,
  placeholder
}: {
  label: string;
  value: string;
  onChangeText: (text: string) => void;
  keyboardType?: any;
  secureTextEntry?: boolean;
  showPasswordToggle?: boolean;
  onTogglePassword?: () => void;
  maxLength?: number;
  autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
  autoCorrect?: boolean;
  placeholder?: string;
}) => {
  const [isFocused, setIsFocused] = useState(false);
  const animatedValue = useRef(new Animated.Value(value ? 1 : 0)).current;

  useEffect(() => {
    Animated.timing(animatedValue, {
      toValue: (isFocused || value) ? 1 : 0,
      duration: 150,
      useNativeDriver: false,
    }).start();
  }, [animatedValue, isFocused, value]);

  const labelStyle = {
    position: 'absolute',
    left: 20,
    top: animatedValue.interpolate({
      inputRange: [0, 1],
      outputRange: [20, -10],
    }),
    fontSize: animatedValue.interpolate({
      inputRange: [0, 1],
      outputRange: [16, 13],
    }),
    color: animatedValue.interpolate({
      inputRange: [0, 1],
      outputRange: ['#9CA3AF', '#007AFF'],
    }),
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 6,
    fontWeight: '500',
    zIndex: 1,
  } as any;

  const containerStyle = {
    borderColor: animatedValue.interpolate({
      inputRange: [0, 1],
      outputRange: ['#E5E7EB', '#007AFF'],
    }),
  } as any;

  return (
    <View style={styles.floatingInputContainer}>
      <Animated.View style={[styles.floatingInputWrapper, containerStyle]}>
        <Animated.Text style={labelStyle}>
          {label}
        </Animated.Text>
        <TextInput
          style={[
            styles.floatingInput,
            showPasswordToggle && styles.floatingInputWithIcon
          ]}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          onChangeText={onChangeText}
          value={value}
          keyboardType={keyboardType}
          secureTextEntry={secureTextEntry}
          maxLength={maxLength}
          autoCapitalize={autoCapitalize}
          autoCorrect={autoCorrect}
          placeholder={isFocused ? placeholder : ''}
          placeholderTextColor="#9CA3AF"
        />
        {showPasswordToggle && (
          <TouchableOpacity 
            style={styles.floatingEyeIcon}
            onPress={onTogglePassword}
          >
            <Ionicons 
              name={secureTextEntry ? "eye-off-outline" : "eye-outline"} 
              size={20} 
              color="#999" 
            />
          </TouchableOpacity>
        )}
      </Animated.View>
    </View>
  );
};

const AuthScreen = () => {
  const dispatch = useAppDispatch();
  const router = useRouter();
  const { email: paramEmail } = useLocalSearchParams();
  
  const [activeTab, setActiveTab] = useState(paramEmail ? 'verify' : 'login');
  
  // Login form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  
  // Register form states
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  // OTP verification states
  const [otp, setOtp] = useState('');
  const [verificationEmail, setVerificationEmail] = useState(paramEmail || '');
  
  const [isLoading, setIsLoading] = useState(false);

  // Animation values for smooth transitions
  const fadeAnim = useRef(new Animated.Value(1)).current;
  const slideAnim = useRef(new Animated.Value(0)).current;
  const headerFadeAnim = useRef(new Animated.Value(1)).current;
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const nav = useNavigation();
  useEffect(() => {
    nav.setOptions({
      headerShown: false,
    });
  }, [nav]);

  // DEVELOPMENT ONLY - Replace with your computer's local IP
  const API_BASE_URL = 'http://192.168.1.178:5000';

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Error', 'Please enter both email and password');
      return;
    }

    if (!/^\S+@\S+\.\S+$/.test(email)) {
      Alert.alert('Error', 'Please enter a valid email address');
      return;
    }

    setIsLoading(true);
    dispatch(setLoading(true));
    dispatch(setError(null));

    try {
      const response = await axios.post(
        `${API_BASE_URL}/api/auth/login`,
        { email, password },
        {
          timeout: 10000,
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }
        }
      );

      if (response.data.success) {
        const providerData = response.data.data;

        dispatch(setProvider({
          id: providerData.providerId,
          email: providerData.email,
          name: providerData.name,
          subscription: providerData.subscription
        }));

        if (!providerData.subscription || 
            !providerData.subscription.status || 
            providerData.subscription.status !== 'active') {
          
          Alert.alert(
            "Subscription Required",
            "Your subscription is not active. Please subscribe to a plan to continue.",
            [
              {
                text: "OK",
                onPress: () => {
                  router.replace({
                    pathname: "/subscription",
                    params: { 
                      providerId: providerData.providerId, 
                      providerEmail: providerData.email 
                    }
                  });
                }
              }
            ]
          );
          return;
        } else {
          router.replace("/dashboard");
        }
      } else {
        throw new Error(response.data.error || 'Login failed');
      }
    } catch (error) {
      let errorMessage = 'Login failed. Please try again.';
      
      if (error.response) {
        errorMessage = error.response.data?.error || 
                      error.response.data?.message || 
                      `Server error (${error.response.status})`;
      } else if (error.code === 'ECONNABORTED') {
        errorMessage = 'Request timeout. Check your connection.';
      } else if (error.message.includes('Network Error')) {
        errorMessage = 'Cannot connect to server. Please:\n\n• Ensure both devices are on same WiFi\n• Verify backend is running\n• Check your local IP is correct';
      }

      Alert.alert('Error', errorMessage);
      console.error('Login error:', error);
    } finally {
      setIsLoading(false);
      dispatch(setLoading(false));
    }
  };

  const handleRegister = async () => {
    if (!name || !email || !phone || !password) {
      Alert.alert('Error', 'All fields are required!');
      return;
    }

    if (!/^\S+@\S+\.\S+$/.test(email)) {
      Alert.alert('Error', 'Please enter a valid email address');
      return;
    }

    if (password.length < 4) {
      Alert.alert('Error', 'Password must be at least 4 characters');
      return;
    }

    if (password !== confirmPassword) {
      Alert.alert('Error', 'Passwords do not match');
      return;
    }

    setIsLoading(true);

    try {
      const response = await axios.post(`${API_BASE_URL}/api/providers/register`, {
        name, email, phone, password
      });

      if (response.data.success) {
        setVerificationEmail(email);
        setActiveTab('verify');
        
        setName('');
        setPhone('');
        setConfirmPassword('');
        setPassword('');

        Alert.alert('Registration Successful', 'Please check your email for the OTP verification code.');
      } else {
        throw new Error(response.data.message || 'Registration failed');
      }
    } catch (error) {
      console.error(error);
      Alert.alert('Error', error.response?.data?.error || error.message || 'Registration failed');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    if (!otp || otp.length !== 4) {
      Alert.alert("Error", "Please enter a valid 4-digit OTP");
      return;
    }

    setIsLoading(true);

    try {
      const response = await axios.post(
        `${API_BASE_URL}/api/providers/verify-otp`, 
        { email: verificationEmail, otp }
      );

      if (response.data.success) {
        Alert.alert("Success", "Account verified successfully!", [
          {
            text: "Continue to Login",
            onPress: () => {
              setOtp('');
              setVerificationEmail('');
              setActiveTab('login');
            }
          }
        ]);
      } else {
        Alert.alert("Error", response.data.error || "OTP verification failed");
      }
    } catch (err) {
      Alert.alert("Error", err.response?.data?.error || "Something went wrong");
    } finally {
      setIsLoading(false);
    }
  };

  const resendOTP = async () => {
    if (!verificationEmail) {
      Alert.alert('Error', 'No email address found for resending OTP');
      return;
    }

    setIsLoading(true);

    try {
      const response = await axios.post(`${API_BASE_URL}/api/providers/resend-otp`, {
        email: verificationEmail
      });

      if (response.data.success) {
        Alert.alert('Success', 'New OTP sent to your email');
      } else {
        Alert.alert('Error', response.data.error || 'Failed to resend OTP');
      }
    } catch (error) {
      Alert.alert('Error', error.response?.data?.error || 'Failed to resend OTP');
    } finally {
      setIsLoading(false);
    }
  };

  const clearForms = () => {
    setEmail('');
    setPassword('');
    setName('');
    setPhone('');
    setConfirmPassword('');
    setOtp('');
    setShowPassword(false);
    setShowConfirmPassword(false);
  };

  const switchTab = (tab) => {
    if (tab === activeTab) return;
    
    // Start exit animation for both form and header
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 0,
        duration: 220,
        useNativeDriver: true,
      }),
      Animated.timing(headerFadeAnim, {
        toValue: 0,
        duration: 180,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: tab === 'register' ? -40 : 40,
        duration: 220,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 0.95,
        duration: 220,
        useNativeDriver: true,
      })
    ]).start(() => {
      // Switch tab after exit animation
      setActiveTab(tab);
      if (tab !== 'verify') {
        clearForms();
      }
      
      // Reset positions for entry
      slideAnim.setValue(tab === 'register' ? 40 : -40);
      scaleAnim.setValue(0.95);
      
      // Start enter animation with easing
      Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
        Animated.timing(headerFadeAnim, {
          toValue: 1,
          duration: 280,
          useNativeDriver: true,
        }),
        Animated.spring(slideAnim, {
          toValue: 0,
          tension: 100,
          friction: 8,
          useNativeDriver: true,
        }),
        Animated.spring(scaleAnim, {
          toValue: 1,
          tension: 100,
          friction: 8,
          useNativeDriver: true,
        })
      ]).start();
    });
  };

  const renderLoginForm = () => (
    <>
      <FloatingInput
        label="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
        autoCorrect={false}
        placeholder="Enter your email"
      />

      <FloatingInput
        label="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry={!showPassword}
        showPasswordToggle={true}
        onTogglePassword={() => setShowPassword(!showPassword)}
        autoCorrect={false}
        placeholder="Enter your password"
      />

      {/* Forgot Password */}
      <TouchableOpacity style={styles.forgotPasswordContainer}>
        <Text style={styles.forgotPassword}>Forgot Password?</Text>
      </TouchableOpacity>

      {/* Login Button */}
      <TouchableOpacity
        style={[styles.loginBtn, isLoading && styles.disabledButton]}
        onPress={handleLogin}
        disabled={isLoading}
        activeOpacity={0.8}
      >
        {isLoading ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={styles.loginBtnText}>Login</Text>
        )}
      </TouchableOpacity>

      {/* Divider */}
      <View style={styles.divider}>
        <View style={styles.dividerLine} />
        <Text style={styles.dividerText}>or continue with</Text>
        <View style={styles.dividerLine} />
      </View>

      {/* Social Login */}
      <View style={styles.socialLogin}>
        <TouchableOpacity style={styles.socialBtn}>
          <FontAwesome name="google" size={20} color="#4285F4" />
          <Text style={styles.socialBtnText}>Google</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.socialBtn}>
          <Ionicons name="logo-apple" size={20} color="#000" />
          <Text style={styles.socialBtnText}>Apple</Text>
        </TouchableOpacity>
      </View>

      {/* Sign Up Link */}
      <View style={styles.signupLink}>
        <Text style={styles.signupText}>Don't have an account? </Text>
        <TouchableOpacity onPress={() => switchTab('register')}>
          <Text style={styles.signupLinkText}>Sign Up</Text>
        </TouchableOpacity>
      </View>
    </>
  );

  const renderRegisterForm = () => (
    <>
      <FloatingInput
        label="Full Name"
        value={name}
        onChangeText={setName}
        autoCapitalize="words"
        autoCorrect={false}
        placeholder="Enter your full name"
      />

      <FloatingInput
        label="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
        autoCorrect={false}
        placeholder="Enter your email"
      />

      <FloatingInput
        label="Phone Number"
        value={phone}
        onChangeText={setPhone}
        keyboardType="phone-pad"
        autoCorrect={false}
        maxLength={10}
        placeholder="Enter your phone number"
      />

      <FloatingInput
        label="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry={!showPassword}
        showPasswordToggle={true}
        onTogglePassword={() => setShowPassword(!showPassword)}
        autoCorrect={false}
        placeholder="Enter your password"
      />

      <FloatingInput
        label="Confirm Password"
        value={confirmPassword}
        onChangeText={setConfirmPassword}
        secureTextEntry={!showConfirmPassword}
        showPasswordToggle={true}
        onTogglePassword={() => setShowConfirmPassword(!showConfirmPassword)}
        autoCorrect={false}
        placeholder="Confirm your password"
      />

      {/* Register Button */}
      <TouchableOpacity
        style={[styles.loginBtn, isLoading && styles.disabledButton]}
        onPress={handleRegister}
        disabled={isLoading}
        activeOpacity={0.8}
      >
        {isLoading ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={styles.loginBtnText}>Create Account</Text>
        )}
      </TouchableOpacity>

      {/* Divider */}
      <View style={styles.divider}>
        <View style={styles.dividerLine} />
        <Text style={styles.dividerText}>or continue with</Text>
        <View style={styles.dividerLine} />
      </View>

      {/* Social Login */}
      <View style={styles.socialLogin}>
        <TouchableOpacity style={styles.socialBtn}>
          <FontAwesome name="google" size={20} color="#4285F4" />
          <Text style={styles.socialBtnText}>Google</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.socialBtn}>
          <Ionicons name="logo-apple" size={20} color="#000" />
          <Text style={styles.socialBtnText}>Apple</Text>
        </TouchableOpacity>
      </View>

      {/* Sign In Link */}
      <View style={styles.signupLink}>
        <Text style={styles.signupText}>Already have an account? </Text>
        <TouchableOpacity onPress={() => switchTab('login')}>
          <Text style={styles.signupLinkText}>Sign In</Text>
        </TouchableOpacity>
      </View>
    </>
  );

  const renderVerifyForm = () => (
    <>
      {/* Verification Icon */}
      <View style={styles.verifyIconContainer}>
        <View style={styles.verifyIcon}>
          <Ionicons name="mail-outline" size={60} color="#007AFF" />
        </View>
      </View>

      {/* Email Display */}
      <View style={styles.floatingInputContainer}>
        <View style={[styles.floatingInputWrapper, styles.disabledInputWrapper]}>
          <Text style={styles.disabledLabel}>Email</Text>
          <TextInput
            style={[styles.floatingInput, styles.disabledInputText]}
            value={verificationEmail}
            editable={false}
          />
        </View>
      </View>

      {/* OTP Input */}
      <View style={styles.inputGroup}>
        <Text style={styles.label}>Enter OTP</Text>
        <OTPInputBoxes otp={otp} setOtp={setOtp} length={4} />
      </View>

      {/* Resend OTP */}
      <TouchableOpacity style={styles.forgotPasswordContainer} onPress={resendOTP}>
        <Text style={styles.forgotPassword}>Resend OTP</Text>
      </TouchableOpacity>

      {/* Verify Button */}
      <TouchableOpacity
        style={[styles.loginBtn, isLoading && styles.disabledButton]}
        onPress={handleVerifyOTP}
        disabled={isLoading}
        activeOpacity={0.8}
      >
        {isLoading ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={styles.loginBtnText}>Verify OTP</Text>
        )}
      </TouchableOpacity>

      {/* Back to Login Link */}
      <View style={styles.signupLink}>
        <Text style={styles.signupText}>Want to go back? </Text>
        <TouchableOpacity onPress={() => switchTab('login')}>
          <Text style={styles.signupLinkText}>Login</Text>
        </TouchableOpacity>
      </View>
    </>
  );

  const getHeaderTitle = () => {
    switch (activeTab) {
      case 'login': return 'Get Started With Us';
      case 'register': return 'Create an Account';
      case 'verify': return 'Verify Your Email';
      default: return 'Get Started With Us';
    }
  };

  const getHeaderSubtitle = () => {
    switch (activeTab) {
      case 'login': return 'Sign in to your Account';
      case 'register': return 'Already have an account? Log in';
      case 'verify': return `Enter OTP `;
      default: return 'Sign in to your Account';
    }
  };

  const renderTabs = () => {
    if (activeTab === 'verify') {
      return null;
    }

    return (
      <View style={styles.tabContainer}>
        <TouchableOpacity 
          style={activeTab === 'login' ? styles.activeTab : styles.inactiveTab}
          onPress={() => switchTab('login')}
        >
          <Text style={activeTab === 'login' ? styles.activeTabText : styles.inactiveTabText}>
            Login
          </Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={activeTab === 'register' ? styles.activeTab : styles.inactiveTab}
          onPress={() => switchTab('register')}
        >
          <Text style={activeTab === 'register' ? styles.activeTabText : styles.inactiveTabText}>
            Register
          </Text>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView 
          contentContainerStyle={styles.scrollContainer}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Header */}
          <Animated.View 
            style={[
              styles.header,
              {
                opacity: headerFadeAnim,
              }
            ]}
          >
            <Text style={styles.headerTitle}>{getHeaderTitle()}</Text>
            <Text style={styles.headerSubtitle}>{getHeaderSubtitle()}</Text>
          </Animated.View>

          {/* Tab Buttons */}
          {renderTabs()}

          {/* Form Container */}
          <Animated.View 
            style={[
              styles.formContainer,
              {
                opacity: fadeAnim,
                transform: [
                  { translateX: slideAnim },
                  { scale: scaleAnim }
                ]
              }
            ]}
          >
            {activeTab === 'login' && renderLoginForm()}
            {activeTab === 'register' && renderRegisterForm()}
            {activeTab === 'verify' && renderVerifyForm()}
          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  scrollContainer: {
    flexGrow: 1,
  },
  header: {
    paddingHorizontal: 30,
    paddingTop: 60,
    paddingBottom: 40,
    backgroundColor: '#f8f9fa',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 26,
    fontWeight: '700',
    color: '#1a1a1a',
    textAlign: 'center',
    lineHeight: 32,
    marginTop: 25,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#666',
    marginTop: 8,
    textAlign: 'center',
  },
  tabContainer: {
    flexDirection: 'row',
    marginHorizontal: 30,
    marginBottom: 30,
    backgroundColor: '#e9ecef',
    borderRadius: 25,
    padding: 4,
  },
  activeTab: {
    flex: 1,
    backgroundColor: '#007AFF',
    paddingVertical: 12,
    borderRadius: 22,
    alignItems: 'center',
  },
  inactiveTab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
  },
  activeTabText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  inactiveTabText: {
    color: '#666',
    fontSize: 16,
    fontWeight: '500',
  },
  formContainer: {
    paddingHorizontal: 30,
    flex: 1,
  },
  // Floating Input Styles
  floatingInputContainer: {
    marginBottom: 20,
  },
  floatingInputWrapper: {
    borderWidth: 1.5,
    borderRadius: 16,
    backgroundColor: '#FFFFFF',
    position: 'relative',
    minHeight: 58,
  },
  floatingInput: {
    fontSize: 16,
    color: '#1F2937',
    paddingHorizontal: 20,
    paddingVertical: 20,
    fontWeight: '400',
    minHeight: 58,
  },
  floatingInputWithIcon: {
    paddingRight: 50,
  },
  floatingEyeIcon: {
    position: 'absolute',
    right: 16,
    top: 19,
    padding: 4,
  },
  disabledInputWrapper: {
    backgroundColor: '#F9FAFB',
    borderColor: '#E5E7EB',
  },
  disabledLabel: {
    position: 'absolute',
    left: 20,
    top: -10,
    fontSize: 13,
    color: '#6B7280',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 6,
    fontWeight: '500',
    zIndex: 1,
  },
  disabledInputText: {
    color: '#6B7280',
  },
  // Legacy styles for OTP section
  inputGroup: {
    marginBottom: 20,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1a1a1a',
    marginBottom: 8,
  },
  verifyIconContainer: {
    alignItems: 'center',
    marginBottom: 30,
  },
  verifyIcon: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#f0f8ff',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#007AFF',
  },
  forgotPasswordContainer: {
    alignItems: 'flex-end',
    marginBottom: 30,
  },
  forgotPassword: {
    color: '#007AFF',
    fontSize: 14,
    fontWeight: '500',
  },
  loginBtn: {
    backgroundColor: '#007AFF',
    borderRadius: 25,
    height: 52,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 30,
    shadowColor: '#007AFF',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  disabledButton: {
    backgroundColor: '#99c2ff',
    shadowOpacity: 0.1,
  },
  loginBtnText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 30,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#e1e5e9',
  },
  dividerText: {
    paddingHorizontal: 16,
    color: '#666',
    fontSize: 14,
  },
  socialLogin: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 30,
    gap: 12,
  },
  socialBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e1e5e9',
    paddingVertical: 14,
    gap: 8,
  },
  socialBtnText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#1a1a1a',
  },
  signupLink: {
    flexDirection: 'row',
    justifyContent: 'center',
    paddingBottom: 30,
  },
  signupText: {
    color: '#666',
    fontSize: 16,
  },
  signupLinkText: {
    color: '#007AFF',
    fontWeight: '600',
    fontSize: 16,
  },
});

export default AuthScreen;