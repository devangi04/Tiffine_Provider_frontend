import React, { useState, useEffect, useRef } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  StyleSheet, 
  Alert, 
  ScrollView,
  Platform,
  StatusBar,
  Animated,
  Dimensions,
  KeyboardAvoidingView,
  ActivityIndicator
} from 'react-native';
import axios from 'axios';

import { LinearGradient } from 'expo-linear-gradient';
const { width } = Dimensions.get('window');
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons, FontAwesome } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useAppDispatch } from './store/hooks';
import { setProvider, setLoading, clearProvider } from './store/slices/providerslice';
import OTPInputBoxes from '@/components/otpbox';
import { SafeAreaView } from 'react-native-safe-area-context';
import { persistor } from './store'; 

// Floating Input Component with auto-focus navigation
const FloatingInput = ({ 
  label, 
  value, 
  onChangeText, 
  keyboardType = 'default',
  secureTextEntry = false,
  showPasswordToggle = false,
  onTogglePassword,
  maxLength,
  autoCapitalize = 'none',
  autoCorrect = false,
  placeholder,
  onSubmitEditing,
  returnKeyType = 'next',
  inputRef,
  editable = true
}: {
  label: string;
  value: string;
  onChangeText: (text: string) => void;
  keyboardType?: any;
  secureTextEntry?: boolean;
  showPasswordToggle?: boolean;
  onTogglePassword?: () => void;
  maxLength?: number;
  autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
  autoCorrect?: boolean;
  placeholder?: string;
  onSubmitEditing?: () => void;
  returnKeyType?: 'next' | 'done' | 'go' | 'send';
  inputRef?: React.RefObject<TextInput>;
  editable?: boolean;
}) => {
  const [isFocused, setIsFocused] = useState(false);
  const animatedValue = useRef(new Animated.Value(value ? 1 : 0)).current;

  useEffect(() => {
    Animated.timing(animatedValue, {
      toValue: (isFocused || value) ? 1 : 0,
      duration: 200,
      useNativeDriver: false,
    }).start();
  }, [animatedValue, isFocused, value]);

  const labelStyle = {
    position: 'absolute',
    left: 20,
    top: animatedValue.interpolate({
      inputRange: [0, 1],
      outputRange: [20, -10],
    }),
    fontSize: animatedValue.interpolate({
      inputRange: [0, 1],
      outputRange: [16, 13],
    }),
    color: animatedValue.interpolate({
      inputRange: [0, 1],
      outputRange: ['#9CA3AF', '#007AFF'],
    }),
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 4,
    fontWeight: '500',
    zIndex: 1,
  } as any;

  const containerStyle = {
    borderColor: animatedValue.interpolate({
      inputRange: [0, 1],
      outputRange: ['#E5E7EB', '#007AFF'],
    }),
  } as any;

  return (
    <View style={styles.floatingInputContainer}>
      <Animated.View style={[
        styles.floatingInputWrapper, 
        containerStyle,
        !editable && styles.disabledInputWrapper
      ]}>
        <Animated.Text style={[
          labelStyle,
          !editable && styles.disabledLabel
        ]}>
          {label}
        </Animated.Text>
        <TextInput
          ref={inputRef}
          style={[
            styles.floatingInput,
            showPasswordToggle && styles.floatingInputWithIcon,
            !editable && styles.disabledInputText
          ]}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          onChangeText={onChangeText}
          value={value}
          keyboardType={keyboardType}
          secureTextEntry={secureTextEntry}
          maxLength={maxLength}
          autoCapitalize={autoCapitalize}
          autoCorrect={autoCorrect}
          placeholder={isFocused ? placeholder : ''}
          placeholderTextColor="#9CA3AF"
          onSubmitEditing={onSubmitEditing}
          returnKeyType={returnKeyType}
          blurOnSubmit={false}
          editable={editable}
        />
        {showPasswordToggle && (
          <TouchableOpacity 
            style={styles.floatingEyeIcon}
            onPress={onTogglePassword}
          >
            <Ionicons 
              name={secureTextEntry ? "eye-off-outline" : "eye-outline"} 
              size={20} 
              color="#999" 
            />
          </TouchableOpacity>
        )}
      </Animated.View>
    </View>
  );
};

const AuthScreen = () => {
  const dispatch = useAppDispatch();
  const router = useRouter();
  const { email: paramEmail, logout, timestamp } = useLocalSearchParams();
  
  const [activeTab, setActiveTab] = useState(paramEmail ? 'verify' : 'login');
  
  // Login form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoginSubmitted, setIsLoginSubmitted] = useState(false);
  
  // Register form states
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isRegisterSubmitted, setIsRegisterSubmitted] = useState(false);
  
  // OTP verification states
  const [otp, setOtp] = useState('');
  const [verificationEmail, setVerificationEmail] = useState(paramEmail || '');
  
  // Forgot password states
  const [forgotEmail, setForgotEmail] = useState('');
  const [resetOtp, setResetOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newConfirmPassword, setNewConfirmPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showNewConfirmPassword, setShowNewConfirmPassword] = useState(false);
  
  const [isLoading, setIsLoading] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  // Enhanced tab animation with spring physics
  const tabSlideAnim = useRef(new Animated.Value(0)).current;

  // Input refs for auto-focus navigation - LOGIN
  const loginEmailRef = useRef<TextInput>(null);
  const loginPasswordRef = useRef<TextInput>(null);

  // Input refs for auto-focus navigation - REGISTER
  const nameRef = useRef<TextInput>(null);
  const emailRef = useRef<TextInput>(null);
  const phoneRef = useRef<TextInput>(null);
  const passwordRef = useRef<TextInput>(null);
  const confirmPasswordRef = useRef<TextInput>(null);

  // Input refs for forgot password
  const forgotEmailRef = useRef<TextInput>(null);
  const newPasswordRef = useRef<TextInput>(null);
  const newConfirmPasswordRef = useRef<TextInput>(null);

  const nav = useNavigation();
  useEffect(() => {
    nav.setOptions({
      headerShown: false,
    });
  }, [nav]);

  // Optimized logout effect
  const logoutProcessedRef = useRef(false);

  useEffect(() => {
  if (logoutProcessedRef.current || logout !== 'true' || isLoggingOut) {
    return;
  }

    console.log('🔄 Logout effect triggered');

  const performLogoutCleanup = async () => {
    try {
      setIsLoggingOut(true);
      logoutProcessedRef.current = true;

      // 1. Clear all forms and state first
      clearForms();
      setActiveTab('login');
      
      // 2. Clear Redux store
      dispatch(clearProvider());
      
      // 3. Clear persisted data
      await persistor.purge();
      
      console.log('✅ Logout cleanup completed');
      
      // 4. Reset states after cleanup
      setTimeout(() => {
        setIsLoggingOut(false);
        logoutProcessedRef.current = false;
      }, 1000);
      
    } catch (error) {
      console.error('❌ Error during logout cleanup:', error);
      setIsLoggingOut(false);
      logoutProcessedRef.current = false;
    }
  };

  performLogoutCleanup();
}, [logout, dispatch, isLoggingOut]);

  useEffect(() => {
    if (paramEmail && typeof paramEmail === 'string') {
      setVerificationEmail(paramEmail);
      setActiveTab('verify');
    }
  }, [paramEmail]);

  // DEVELOPMENT ONLY - Replace with your computer's local IP
  const API_BASE_URL = 'http://192.168.1.178:5000';

  // Enhanced tab animation with spring effect
  const animateTabChange = (newTab: string) => {
    setActiveTab(newTab);
    
    // Calculate slide position based on tab
    let slideValue = 0;
    if (newTab === 'register') slideValue = 1;
    
    // Smooth slide animation with spring physics
    Animated.spring(tabSlideAnim, {
      toValue: slideValue,
      tension: 120,
      friction: 8,
      useNativeDriver: false,
    }).start();
  };

  const switchTab = (tab: string) => {
    if (tab === activeTab) return;
    
    animateTabChange(tab);
    setIsRegisterSubmitted(false);
    setIsLoginSubmitted(false);
    
    if (tab !== 'verify' && tab !== 'forgot-otp' && tab !== 'reset-password') {
      clearForms();
    }
  };

  // Enhanced auto-focus navigation with better timing
  const focusNextField = (nextRef: React.RefObject<TextInput>) => {
    setTimeout(() => {
      nextRef.current?.focus();
    }, 50);
  };

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Error', 'Please enter both email and password');
      return;
    }

    if (!/^\S+@\S+\.\S+$/.test(email)) {
      Alert.alert('Error', 'Please enter a valid email address');
      return;
    }

    setIsLoading(true);
    setIsLoginSubmitted(true);
    dispatch(setLoading(true));

    try {
      const response = await axios.post(
        `${API_BASE_URL}/api/auth/login`,
        { email, password },
        {
          timeout: 10000,
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }
        }
      );

      if (response.data.success) {
        const providerData = response.data.data;

        dispatch(setProvider({
          id: providerData.providerId,
          email: providerData.email,
          name: providerData.name,
          subscription: providerData.subscription
        }));

        if (!providerData.subscription || 
            !providerData.subscription.status || 
            providerData.subscription.status !== 'active') {
          
          Alert.alert(
            "Subscription Required",
            "Your subscription is not active. Please subscribe to a plan to continue.",
            [
              {
                text: "OK",
                onPress: () => {
                  router.replace({
                    pathname: "/subscription",
                    params: { 
                      providerId: providerData.providerId, 
                      providerEmail: providerData.email 
                    }
                  });
                }
              }
            ]
          );
          return;
        } else {
          router.replace("/dashboard");
        }
      } else {
        setIsLoginSubmitted(false);
        throw new Error(response.data.error || 'Login failed');
      }
    } catch (error: any) {
      setIsLoginSubmitted(false);
      let errorMessage = 'Login failed. Please try again.';
      
      if (error.response) {
        errorMessage = error.response.data?.error || 
                      error.response.data?.message || 
                      `Server error (${error.response.status})`;
      } else if (error.code === 'ECONNABORTED') {
        errorMessage = 'Request timeout. Check your connection.';
      } else if (error.message.includes('Network Error')) {
        errorMessage = 'Cannot connect to server. Please:\n\n• Ensure both devices are on same WiFi\n• Verify backend is running\n• Check your local IP is correct';
      }

      Alert.alert('Error', errorMessage);
    } finally {
      setIsLoading(false);
      dispatch(setLoading(false));
    }
  };

  const handleRegister = async () => {
    if (!name || !email || !phone || !password) {
      Alert.alert('Error', 'All fields are required!');
      return;
    }

    if (!/^\S+@\S+\.\S+$/.test(email)) {
      Alert.alert('Error', 'Please enter a valid email address');
      return;
    }

    if (password.length < 4) {
      Alert.alert('Error', 'Password must be at least 4 characters');
      return;
    }

    if (password !== confirmPassword) {
      Alert.alert('Error', 'Passwords do not match');
      return;
    }

    setIsLoading(true);
    setIsRegisterSubmitted(true);

    try {
      const response = await axios.post(`${API_BASE_URL}/api/providers/register`, {
        name, email, phone, password
      });

      if (response.data.success) {
        setVerificationEmail(email);
        setActiveTab('verify');
        
        Alert.alert('Registration Successful', 'Please check your email for the OTP verification code.');
      } else {
        setIsRegisterSubmitted(false);
        throw new Error(response.data.message || 'Registration failed');
      }
    } catch (error: any) {
      console.error(error);
      setIsRegisterSubmitted(false);
      Alert.alert('Error', 'Registration failed');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    if (!otp || otp.length !== 4) {
      Alert.alert("Error", "Please enter a valid 4-digit OTP");
      return;
    }

    setIsLoading(true);

    try {
      const response = await axios.post(
        `${API_BASE_URL}/api/providers/verify-otp`, 
        { email: verificationEmail, otp }
      );

      if (response.data.success) {
        Alert.alert("Success", "Account verified successfully!", [
          {
            text: "Continue to Login",
            onPress: () => {
              // Auto-fill email in login form
              setEmail(verificationEmail);
              setOtp('');
              setVerificationEmail('');
              setActiveTab('login');
              setIsRegisterSubmitted(false);
              // Reset capsule to login position
              Animated.spring(tabSlideAnim, {
                toValue: 0,
                tension: 120,
                friction: 8,
                useNativeDriver: false,
              }).start();
            }
          }
        ]);
      } else {
        Alert.alert("Error", "OTP verification failed");
      }
    } catch (err: any) {
      Alert.alert("Error", "Something went wrong");
    } finally {
      setIsLoading(false);
    }
  };

  // Forgot Password Functions
  const handleSendResetOTP = async () => {
    if (!forgotEmail || !/^\S+@\S+\.\S+$/.test(forgotEmail)) {
      Alert.alert('Error', 'Please enter a valid email address');
      return;
    }

    setIsLoading(true);
    try {
      const response = await axios.post(`${API_BASE_URL}/api/providers/forgot-password`, { 
        email: forgotEmail 
      });
      
      if (response.data.success) {
        setActiveTab('forgot-otp');
        Alert.alert('Success', 'OTP sent to your email');
      } else {
        throw new Error('Failed to send OTP');
      }
    } catch (error: any) {
      Alert.alert('Error', 'Failed to send OTP');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyResetOTP = async () => {
    if (!resetOtp || resetOtp.length !== 4) {
      Alert.alert('Error', 'Please enter a valid 4-digit OTP');
      return;
    }

    setIsLoading(true);
    try {
      const response = await axios.post(`${API_BASE_URL}/api/providers/verify-reset-otp`, {
        email: forgotEmail,
        otp: resetOtp
      });

      if (response.data.success) {
        setActiveTab('reset-password');
        Alert.alert('Success', 'OTP verified successfully');
      } else {
        throw new Error('Invalid OTP');
      }
    } catch (error: any) {
      Alert.alert('Error', 'Invalid OTP');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetPassword = async () => {
    if (!newPassword || !newConfirmPassword) {
      Alert.alert('Error', 'Please enter both passwords');
      return;
    }

    if (newPassword.length < 6) {
      Alert.alert('Error', 'Password must be at least 6 characters');
      return;
    }

    if (newPassword !== newConfirmPassword) {
      Alert.alert('Error', 'Passwords do not match');
      return;
    }

    setIsLoading(true);
    try {
      const response = await axios.post(`${API_BASE_URL}/api/providers/reset-password`, {
        email: forgotEmail,
        otp: resetOtp,
        newPassword
      });

      if (response.data.success) {
        Alert.alert('Success', 'Password reset successfully!', [
          { 
            text: 'OK', 
            onPress: () => {
              clearForms();
              setActiveTab('login');
              // Reset capsule to login position
              Animated.spring(tabSlideAnim, {
                toValue: 0,
                tension: 120,
                friction: 8,
                useNativeDriver: false,
              }).start();
            }
          }
        ]);
      } else {
        throw new Error('Password reset failed');
      }
    } catch (error: any) {
      Alert.alert('Error', 'Password reset failed');
    } finally {
      setIsLoading(false);
    }
  };

  const resendOTP = async () => {
    if (!verificationEmail) {
      Alert.alert('Error', 'No email address found for resending OTP');
      return;
    }

    setIsLoading(true);

    try {
      const response = await axios.post(`${API_BASE_URL}/api/providers/resend-otp`, {
        email: verificationEmail
      });

      if (response.data.success) {
        Alert.alert('Success', 'New OTP sent to your email');
      } else {
        Alert.alert('Error', 'Failed to resend OTP');
      }
    } catch (error: any) {
      Alert.alert('Error', 'Failed to resend OTP');
    } finally {
      setIsLoading(false);
    }
  };

  const resendResetOTP = async () => {
    try {
      const response = await axios.post(`${API_BASE_URL}/api/providers/resend-reset-otp`, { 
        email: forgotEmail 
      });
      if (response.data.success) {
        Alert.alert('Success', 'New OTP sent to your email');
      }
    } catch (error: any) {
      Alert.alert('Error', 'Failed to resend OTP');
    }
  };

  const clearForms = () => {
    setEmail('');
    setPassword('');
    setName('');
    setPhone('');
    setConfirmPassword('');
    setOtp('');
    setForgotEmail('');
    setResetOtp('');
    setNewPassword('');
    setNewConfirmPassword('');
    setShowPassword(false);
    setShowConfirmPassword(false);
    setShowNewPassword(false);
    setShowNewConfirmPassword(false);
    setIsRegisterSubmitted(false);
    setIsLoginSubmitted(false);
  };

  const renderLoginForm = () => (
    <>
      <FloatingInput
        label="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
        autoCorrect={false}
        inputRef={loginEmailRef}
        onSubmitEditing={() => focusNextField(loginPasswordRef)}
        returnKeyType="next"
        editable={!isLoginSubmitted}
      />

      <FloatingInput
        label="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry={!showPassword}
        showPasswordToggle={true}
        onTogglePassword={() => setShowPassword(!showPassword)}
        autoCorrect={false}
        inputRef={loginPasswordRef}
        onSubmitEditing={handleLogin}
        returnKeyType="done"
        editable={!isLoginSubmitted}
      />

      {/* Forgot Password */}
      <TouchableOpacity 
        style={styles.forgotPasswordContainer}
        onPress={() => switchTab('forgot-password')}
        disabled={isLoginSubmitted}
      >
        <Text style={[styles.forgotPassword, isLoginSubmitted && styles.disabledText]}>
          Forgot Password?
        </Text>
      </TouchableOpacity>

      {/* Login Button */}
      <TouchableOpacity
        style={[styles.loginBtnWrapper, (isLoading || isLoginSubmitted) && styles.disabledButton]}
        onPress={handleLogin}
        disabled={isLoading || isLoginSubmitted}
        activeOpacity={0.8}
      >
        <LinearGradient
          colors={['#7190fa', '#09d6c8']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.loginBtn}
        >
          {isLoading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.loginBtnText}>
              {isLoginSubmitted ? 'Logging in...' : 'Login'}
            </Text>
          )}
        </LinearGradient>
      </TouchableOpacity>

      {/* Sign Up Link */}
      <View style={styles.signupLink}>
        <Text style={styles.signupText}>Don't have an account? </Text>
        <TouchableOpacity 
          onPress={() => switchTab('register')}
          disabled={isLoginSubmitted}
        >
          <Text style={[styles.signupLinkText, isLoginSubmitted && styles.disabledText]}>
            Sign Up
          </Text>
        </TouchableOpacity>
      </View>
    </>
  );

  const renderRegisterForm = () => (
    <>
      <FloatingInput
        label="Full Name"
        value={name}
        onChangeText={setName}
        autoCapitalize="words"
        autoCorrect={false}
        inputRef={nameRef}
        onSubmitEditing={() => focusNextField(emailRef)}
        returnKeyType="next"
        editable={!isRegisterSubmitted}
      />

      <FloatingInput
        label="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
        autoCorrect={false}
        inputRef={emailRef}
        onSubmitEditing={() => focusNextField(phoneRef)}
        returnKeyType="next"
        editable={!isRegisterSubmitted}
      />

      <FloatingInput
        label="Phone Number"
        value={phone}
        onChangeText={setPhone}
        keyboardType="phone-pad"
        autoCorrect={false}
        maxLength={10}
        inputRef={phoneRef}
        onSubmitEditing={() => focusNextField(passwordRef)}
        returnKeyType="next"
        editable={!isRegisterSubmitted}
      />

      <FloatingInput
        label="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry={!showPassword}
        showPasswordToggle={true}
        onTogglePassword={() => setShowPassword(!showPassword)}
        autoCorrect={false}
        inputRef={passwordRef}
        onSubmitEditing={() => focusNextField(confirmPasswordRef)}
        returnKeyType="next"
        editable={!isRegisterSubmitted}
      />

      <FloatingInput
        label="Confirm Password"
        value={confirmPassword}
        onChangeText={setConfirmPassword}
        secureTextEntry={!showConfirmPassword}
        showPasswordToggle={true}
        onTogglePassword={() => setShowConfirmPassword(!showConfirmPassword)}
        autoCorrect={false}
        inputRef={confirmPasswordRef}
        onSubmitEditing={handleRegister}
        returnKeyType="done"
        editable={!isRegisterSubmitted}
      />

      {/* Register Button */}
      <TouchableOpacity
        style={[styles.loginBtnWrapper, (isLoading || isRegisterSubmitted) && styles.disabledButton]}
        onPress={handleRegister}
        disabled={isLoading || isRegisterSubmitted}
        activeOpacity={0.8}
      >
        <LinearGradient
          colors={['#7190fa', '#09d6c8']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.loginBtn}
        >
          {isLoading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.loginBtnText}>
              {isRegisterSubmitted ? 'Submitted' : 'Create Account'}
            </Text>
          )}
        </LinearGradient>
      </TouchableOpacity>

      {/* Back to Login Link */}
      <View style={styles.signupLink}>
        <Text style={styles.signupText}>Already have an account? </Text>
        <TouchableOpacity 
          onPress={() => switchTab('login')}
          disabled={isRegisterSubmitted}
        >
          <Text style={[styles.signupLinkText, isRegisterSubmitted && styles.disabledText]}>
            Sign In
          </Text>
        </TouchableOpacity>
      </View>
    </>
  );

  const renderVerifyForm = () => (
    <>
      {/* Verification Icon */}
      <View style={styles.verifyIconContainer}>
        <View style={styles.verifyIcon}>
          <Ionicons name="mail-outline" size={60} color="#007AFF" />
        </View>
      </View>

      {/* Email Display */}
      <FloatingInput
        label="Email"
        value={verificationEmail}
        onChangeText={() => {}}
        editable={false}
      />

      {/* OTP Input */}
      <View style={styles.inputGroup}>
        <Text style={styles.label}>Enter OTP</Text>
        <OTPInputBoxes otp={otp} setOtp={setOtp} length={4} />
      </View>

      {/* Resend OTP */}
      <TouchableOpacity 
        style={styles.forgotPasswordContainer} 
        onPress={resendOTP}
        disabled={isLoading}
      >
        <Text style={[styles.forgotPassword, isLoading && styles.disabledText]}>
          Resend OTP
        </Text>
      </TouchableOpacity>

      {/* Verify Button */}
      <TouchableOpacity
        style={[styles.loginBtnWrapper, isLoading && styles.disabledButton]}
        onPress={handleVerifyOTP}
        disabled={isLoading}
        activeOpacity={0.8}
      >
        <LinearGradient
          colors={['#7190fa', '#09d6c8']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.loginBtn}
        >
          {isLoading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.loginBtnText}>Verify OTP</Text>
          )}
        </LinearGradient>
      </TouchableOpacity>

      {/* Back to Login Link */}
      <View style={styles.signupLink}>
        <Text style={styles.signupText}>Want to go back? </Text>
        <TouchableOpacity onPress={() => switchTab('login')}>
          <Text style={styles.signupLinkText}>Login</Text>
        </TouchableOpacity>
      </View>
    </>
  );

  const renderForgotPasswordForm = () => (
    <>
      {/* Forgot Password Icon */}
      <View style={styles.verifyIconContainer}>
        <View style={styles.verifyIcon}>
          <Ionicons name="lock-closed-outline" size={60} color="#007AFF" />
        </View>
      </View>

      <Text style={styles.subtitle}>Enter your email to receive a password reset OTP</Text>
      
      <FloatingInput
        label="Email"
        value={forgotEmail}
        onChangeText={setForgotEmail}
        keyboardType="email-address"
        autoCapitalize="none"
        inputRef={forgotEmailRef}
        onSubmitEditing={handleSendResetOTP}
        returnKeyType="send"
      />

      <TouchableOpacity
        style={[styles.loginBtnWrapper, isLoading && styles.disabledButton]}
        onPress={handleSendResetOTP}
        disabled={isLoading}
        activeOpacity={0.8}
      >
        <LinearGradient
          colors={['#7190fa', '#09d6c8']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.loginBtn}
        >
          {isLoading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.loginBtnText}>Send OTP</Text>
          )}
        </LinearGradient>
      </TouchableOpacity>

      {/* Back to Login Link */}
      <View style={styles.signupLink}>
        <Text style={styles.signupText}>Remember your password? </Text>
        <TouchableOpacity onPress={() => switchTab('login')}>
          <Text style={styles.signupLinkText}>Login</Text>
        </TouchableOpacity>
      </View>
    </>
  );

  const renderForgotOTPForm = () => (
    <>
      {/* Verification Icon */}
      <View style={styles.verifyIconContainer}>
        <View style={styles.verifyIcon}>
          <Ionicons name="mail-outline" size={60} color="#007AFF" />
        </View>
      </View>

      <Text style={styles.subtitle}>Enter the 4-digit OTP sent to {forgotEmail}</Text>

      {/* Email Display */}
      <FloatingInput
        label="Email"
        value={forgotEmail}
        onChangeText={() => {}}
        editable={false}
      />
      
      {/* OTP Input */}
      <View style={styles.inputGroup}>
        <Text style={styles.label}>Enter OTP</Text>
        <OTPInputBoxes otp={resetOtp} setOtp={setResetOtp} length={4} />
      </View>
      
      <TouchableOpacity 
        style={styles.forgotPasswordContainer} 
        onPress={resendResetOTP}
        disabled={isLoading}
      >
        <Text style={[styles.forgotPassword, isLoading && styles.disabledText]}>
          Didn't receive OTP? Resend
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={[styles.loginBtnWrapper, isLoading && styles.disabledButton]}
        onPress={handleVerifyResetOTP}
        disabled={isLoading}
        activeOpacity={0.8}
      >
        <LinearGradient
          colors={['#7190fa', '#09d6c8']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.loginBtn}
        >
          {isLoading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.loginBtnText}>Verify OTP</Text>
          )}
        </LinearGradient>
      </TouchableOpacity>

      {/* Back to Login Link */}
      <View style={styles.signupLink}>
        <Text style={styles.signupText}>Want to go back? </Text>
        <TouchableOpacity onPress={() => switchTab('login')}>
          <Text style={styles.signupLinkText}>Login</Text>
        </TouchableOpacity>
      </View>
    </>
  );

  const renderResetPasswordForm = () => (
    <>
      {/* Reset Password Icon */}
      <View style={styles.verifyIconContainer}>
        <View style={styles.verifyIcon}>
          <Ionicons name="key-outline" size={60} color="#007AFF" />
        </View>
      </View>

      <Text style={styles.subtitle}>Create your new password</Text>
      
      <FloatingInput
        label="New Password"
        value={newPassword}
        onChangeText={setNewPassword}
        secureTextEntry={!showNewPassword}
        showPasswordToggle={true}
        onTogglePassword={() => setShowNewPassword(!showNewPassword)}
        inputRef={newPasswordRef}
        onSubmitEditing={() => focusNextField(newConfirmPasswordRef)}
        returnKeyType="next"
      />

      <FloatingInput
        label="Confirm New Password"
        value={newConfirmPassword}
        onChangeText={setNewConfirmPassword}
        secureTextEntry={!showNewConfirmPassword}
        showPasswordToggle={true}
        onTogglePassword={() => setShowNewConfirmPassword(!showNewConfirmPassword)}
        inputRef={newConfirmPasswordRef}
        onSubmitEditing={handleResetPassword}
        returnKeyType="done"
      />

      <TouchableOpacity
        style={[styles.loginBtnWrapper, isLoading && styles.disabledButton]}
        onPress={handleResetPassword}
        disabled={isLoading}
        activeOpacity={0.8}
      >
        <LinearGradient
          colors={['#7190fa', '#09d6c8']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.loginBtn}
        >
          {isLoading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.loginBtnText}>Reset Password</Text>
          )}
        </LinearGradient>
      </TouchableOpacity>

      {/* Back to Login Link */}
      <View style={styles.signupLink}>
        <Text style={styles.signupText}>Want to go back? </Text>
        <TouchableOpacity onPress={() => switchTab('login')}>
          <Text style={styles.signupLinkText}>Login</Text>
        </TouchableOpacity>
      </View>
    </>
  );

  const getHeaderTitle = () => {
    switch (activeTab) {
      case 'login': return 'Get Started With Us';
      case 'register': return 'Create an Account';
      case 'verify': return 'Verify Your Email';
      case 'forgot-password': return 'Forgot Password';
      case 'forgot-otp': return 'Verify OTP';
      case 'reset-password': return 'Reset Password';
      default: return 'Get Started With Us';
    }
  };

  const getHeaderSubtitle = () => {
    switch (activeTab) {
      case 'login': return 'Sign in to your Account';
      case 'register': return 'Signup your account';
      case 'verify': return 'Enter OTP';
      case 'forgot-password': return 'Reset your password';
      case 'forgot-otp': return 'Enter verification code';
      case 'reset-password': return 'Create new password';
      default: return 'Sign in to your Account';
    }
  };

  const renderTabs = () => {
    // Hide tabs for special flows
    if (['verify', 'forgot-password', 'forgot-otp', 'reset-password'].includes(activeTab)) {
      return null;
    }

    return (
      <Animated.View style={styles.tabContainer}>
        <Animated.View 
          style={[
            styles.tabIndicator,
            {
              transform: [{
                translateX: tabSlideAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [4, width/2 - 34],
                })
              }],
              shadowOpacity: tabSlideAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [0.3, 0.4],
              }),
              elevation: tabSlideAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [3, 5],
              }),
            }
          ]} 
        >
          <LinearGradient
            colors={['#7190fa', '#09d6c8']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.tabIndicatorGradient}
          />
        </Animated.View>
        <TouchableOpacity 
          style={styles.tabButton}
          onPress={() => switchTab('login')}
          activeOpacity={0.7}
        >
          <Text style={[
            styles.tabText,
            activeTab === 'login' ? styles.activeTabText : styles.inactiveTabText
          ]}>
            Login
          </Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.tabButton}
          onPress={() => switchTab('register')}
          activeOpacity={0.7}
        >
          <Text style={[
            styles.tabText,
            activeTab === 'register' ? styles.activeTabText : styles.inactiveTabText
          ]}>
            Register
          </Text>
        </TouchableOpacity>
      </Animated.View>
    );
  };

  return (
    <>
      <SafeAreaView style={styles.container}>
        <StatusBar
          barStyle="dark-content"
          backgroundColor="#1c1919ff"
          translucent={false}
        />
        <KeyboardAvoidingView
          style={styles.container}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
          <ScrollView 
            contentContainerStyle={styles.scrollContainer}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            {/* Header */}
            <View style={styles.header}>
              <Text style={styles.headerTitle}>{getHeaderTitle()}</Text>
              <Text style={styles.headerSubtitle}>{getHeaderSubtitle()}</Text>
            </View>

            {/* Tab Buttons */}
            {renderTabs()}

            {/* Form Container */}
            <View style={styles.formContainer}>
              {activeTab === 'login' && renderLoginForm()}
              {activeTab === 'register' && renderRegisterForm()}
              {activeTab === 'verify' && renderVerifyForm()}
              {activeTab === 'forgot-password' && renderForgotPasswordForm()}
              {activeTab === 'forgot-otp' && renderForgotOTPForm()}
              {activeTab === 'reset-password' && renderResetPasswordForm()}
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffff',
  },
  scrollContainer: {
    flexGrow: 1,
  },
  header: {
    paddingHorizontal: 30,
    paddingBottom: 40,
    backgroundColor: '#ffff',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 26,
    fontWeight: '700',
    color: '#1a1a1a',
    textAlign: 'center',
    lineHeight: 32,
    marginTop: 45,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#666',
    marginTop: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 30,
    lineHeight: 22,
    paddingHorizontal: 10,
  },
  tabContainer: {
    position: 'relative',
    flexDirection: 'row',
    marginHorizontal: 30,
    marginBottom: 30,
    backgroundColor: '#e9ecef',
    borderRadius: 25,
    padding: 4,
    height: 50,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  tabIndicator: {
    position: 'absolute',
    top: 4,
    left: 0,
    width: width/2 - 34,
    height: 42,
    borderRadius: 21,
    shadowColor: '#007AFF',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 4,
    overflow: 'hidden', // Important for gradient to respect borderRadius
  },
  tabIndicatorGradient: {
    width: '100%',
    height: '100%',
    borderRadius: 21,
  },
  tabButton: {
    flex: 1,
    paddingVertical: 9,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1,
  },
  tabText: {
    fontSize: 15,
    fontWeight: '600',
  },
  activeTabText: {
    color: '#fff',
    fontWeight: '700',
  },
  inactiveTabText: {
    color: '#666',
    fontWeight: '600',
  },
  formContainer: {
    paddingHorizontal: 30,
    flex: 1,
  },
  // Floating Input Styles
  floatingInputContainer: {
    marginBottom: 20,
  },
  floatingInputWrapper: {
    borderWidth: 1.5,
    borderRadius: 16,
    backgroundColor: '#FFFFFF',
    position: 'relative',
    minHeight: 58,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  floatingInput: {
    fontSize: 16,
    color: '#1F2937',
    paddingHorizontal: 20,
    paddingVertical: 20,
    fontWeight: '400',
    minHeight: 58,
  },
  floatingInputWithIcon: {
    paddingRight: 50,
  },
  floatingEyeIcon: {
    position: 'absolute',
    right: 16,
    top: 19,
    padding: 4,
  },
  disabledInputWrapper: {
    backgroundColor: '#F9FAFB',
    borderColor: '#E5E7EB',
  },
  disabledLabel: {
    position: 'absolute',
    left: 20,
    top: -10,
    fontSize: 13,
    color: '#6B7280',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 6,
    fontWeight: '500',
    zIndex: 1,
  },
  disabledInputText: {
    color: '#6B7280',
  },
  disabledText: {
    color: '#9CA3AF',
  },
  // Button Styles
  loginBtnWrapper: {
    borderRadius: 25,
    height: 52,
    marginBottom: 30,
    shadowColor: '#007AFF',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
    overflow: 'hidden', // Important for gradient
  },
  loginBtn: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  disabledButton: {
    opacity: 0.6,
  },
  loginBtnText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  // Legacy styles for OTP section
  inputGroup: {
    marginBottom: 20,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1a1a1a',
    marginBottom: 8,
  },
  verifyIconContainer: {
    alignItems: 'center',
    marginBottom: 30,
  },
  verifyIcon: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#f0f8ff',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#007AFF',
  },
  forgotPasswordContainer: {
    alignItems: 'flex-end',
    marginBottom: 30,
  },
  forgotPassword: {
    color: '#007AFF',
    fontSize: 14,
    fontWeight: '500',
  },
  signupLink: {
    flexDirection: 'row',
    justifyContent: 'center',
    paddingBottom: 30,
  },
  signupText: {
    color: '#666',
    fontSize: 16,
  },
  signupLinkText: {
    color: '#007AFF',
    fontWeight: '600',
    fontSize: 16,
  },
});

export default AuthScreen;