// CustomerListScreen.tsx
import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  Alert,
  Animated,
  TextInput,
  ActivityIndicator,
  FlatList,
  Dimensions,
  Easing,
  RefreshControl
} from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RouteProp } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import BottomNavBar from '@/components/navbar';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppSelector, useAppDispatch } from './store/hooks';
import { 
  fetchCustomers, 
  setCurrentCustomer, 
  deleteCustomer as deleteCustomerAction,
  toggleCustomerActive as toggleCustomerStatusAction
} from './store/slices/customerslice';

type RootStackParamList = {
  AddCustomer: undefined;
  CustomerList: undefined;
  Profile: undefined;
  Bill: undefined;
};

type CustomerListScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'CustomerList'
>;

type Props = {
  navigation: CustomerListScreenNavigationProp;
  route: RouteProp<RootStackParamList, 'CustomerList'>;
};

type Customer = {
  _id: string;
  name: string;
  phone: string;
  email:string;
  address: string;
  area: string;
  preference: 'veg' | 'non-veg' | 'jain';
  tiffinRate: number;
  isActive: boolean;
  createdAt: string;
  providerId: string;
  totalDue?: number;
};

const ITEMS_PER_PAGE = 10;
const { width } = Dimensions.get('window');

const CustomerListScreen: React.FC<Props> = ({ navigation }) => {
  const dispatch = useAppDispatch();
  const { customers, loading, error } = useAppSelector((state) => state.customer);
  const provider = useAppSelector((state) => state.provider);
  const providerId = provider.id;

  const [filteredCustomers, setFilteredCustomers] = useState<Customer[]>([]);
  const [activeNav, setActiveNav] = useState('Menu');
  const navbarOpacity = new Animated.Value(1);
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [refreshing, setRefreshing] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  
  const searchInputRef = useRef<TextInput>(null);
  const searchWidth = useRef(new Animated.Value(200)).current;
  const paginationOpacity = useRef(new Animated.Value(1)).current;

  const nav = useNavigation();
  
  useEffect(() => {
    nav.setOptions({
      headerShown: false,
    });
  }, [nav]);

  useEffect(() => {
    loadCustomers();
  }, []);

  useEffect(() => {
    filterCustomers();
  }, [searchQuery, customers]);

  const handleSearchFocus = () => {
    setIsSearchFocused(true);
    Animated.parallel([
      Animated.spring(searchWidth, {
        toValue: width - 32,
        damping: 20,
        stiffness: 180,
        mass: 1,
        useNativeDriver: false,
      }),
      Animated.timing(paginationOpacity, {
        toValue: 0,
        duration: 250,
        easing: Easing.inOut(Easing.ease),
        useNativeDriver: true,
      }),
    ]).start();
  };

  const handleSearchBlur = () => {
    if (searchQuery === '') {
      setIsSearchFocused(false);
      Animated.parallel([
        Animated.spring(searchWidth, {
          toValue: 200,
          damping: 20,
          stiffness: 180,
          mass: 1,
          useNativeDriver: false,
        }),
        Animated.timing(paginationOpacity, {
          toValue: 1,
          duration: 250,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ]).start();
    }
  };

  const clearSearch = () => {
    setSearchQuery('');
    searchInputRef.current?.blur();
    setIsSearchFocused(false);
    Animated.parallel([
      Animated.timing(searchWidth, {
        toValue: 200,
        duration: 300,
        useNativeDriver: false,
      }),
      Animated.timing(paginationOpacity, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      })
    ]).start();
  };

  useFocusEffect(
    React.useCallback(() => {
      // Clear search when coming back to this screen
      setSearchQuery('');
      setIsSearchFocused(false);
      searchInputRef.current?.blur();
    }, [])
  );

  const loadCustomers = async () => {
    setRefreshing(true);
    try {
      await dispatch(fetchCustomers(providerId)).unwrap();
    } catch (error) {
      console.error('Error loading customers:', error);
      Alert.alert("Error", "Failed to load customers. Please try again.");
    } finally {
      setRefreshing(false);
    }
  };

  const filterCustomers = () => {
    if (!searchQuery.trim()) {
      setFilteredCustomers(customers);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = customers.filter(customer => 
      customer.name.toLowerCase().includes(query) ||
      customer.phone.includes(query) ||
      customer.email.toLowerCase().includes(query) || 
      (customer.area && customer.area.toLowerCase().includes(query)) ||
      customer.address.toLowerCase().includes(query)
    );
    
    setFilteredCustomers(filtered);
    setCurrentPage(1);
  };

  const deleteCustomer = async (customerId: string) => {
    Alert.alert(
      "Confirm Delete",
      "Are you sure you want to delete this customer?",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        { 
          text: "Delete", 
          onPress: async () => {
            try {
              await dispatch(deleteCustomerAction(customerId)).unwrap();
              Alert.alert("Success", "Customer deleted successfully!");
            } catch (error) {
              console.error('Error deleting customer:', error);
              Alert.alert("Error", "Failed to delete customer. Please try again.");
            }
          }
        }
      ]
    );
  };

  const toggleCustomerStatus = async (customerId: string, currentStatus: boolean) => {
    try {
      await dispatch(toggleCustomerStatusAction(customerId)).unwrap();
      Alert.alert("Success", `Customer ${!currentStatus ? 'activated' : 'deactivated'} successfully!`);
    } catch (error) {
      console.error('Error toggling customer status:', error);
      Alert.alert("Error", "Failed to update customer status. Please try again.");
    }
  };

  const handleNavigation = (screenName: string) => {
    setActiveNav(screenName);
  };

  // ✅ FIXED: Edit customer function
  const editCustomer = (customer: Customer) => {
    console.log('📝 Setting current customer in Redux for editing:', customer);
    dispatch(setCurrentCustomer(customer));
    router.push('/customer');
  };

  // ✅ NEW: Add new customer function
  const addNewCustomer = () => {
    console.log('➕ Clearing Redux for new customer');
    dispatch(setCurrentCustomer(null));
    router.push('/customer');
  };

  const generateBill = (customer: Customer) => {
    router.push({
      pathname: '/bill',
      params: { customerId: customer._id }
    });
  };

  // Pagination logic
  const totalPages = filteredCustomers.length > 0 
    ? Math.ceil(filteredCustomers.length / ITEMS_PER_PAGE) 
    : 0;

  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const endIndex = startIndex + ITEMS_PER_PAGE;
  const paginatedCustomers = filteredCustomers.slice(startIndex, endIndex);
 
  const goToNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const goToPrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const renderCustomerItem = ({ item }: { item: Customer }) => (
    <View style={styles.customerCard}>
      <View style={styles.customerHeader}>
        <View>
          <Text style={styles.customerName}>{item.name}</Text>
          <View style={[
            styles.statusBadge,
            item.isActive ? styles.statusActive : styles.statusInactive
          ]}>
            <Text style={[
              styles.statusText,
              item.isActive ? styles.statusTextActive : styles.statusTextInactive
            ]}>
              {item.isActive ? 'Active' : 'Inactive'}
            </Text>
          </View>
        </View>
        <TouchableOpacity
          onPress={() => toggleCustomerStatus(item._id, item.isActive)}
          style={styles.statusToggle}
        >
          <Icon
            name={item.isActive ? "toggle-on" : "toggle-off"}
            size={50}
            color={item.isActive ? "#10b981" : "#94a3b8"}
          />
        </TouchableOpacity>
      </View>
      
      <View style={styles.customerInfo}>
        <View style={styles.infoRow}>
          <Icon name="phone" size={16} color="#94a3b8" />
          <Text style={styles.infoText}>{item.phone}</Text>
        </View>
        <View style={styles.infoRow}>
  <Icon name="email" size={16} color="#94a3b8" />
  <Text style={styles.infoText}>{item.email}</Text>
</View>

        <View style={styles.infoRow}>
          <Icon name="location-on" size={16} color="#94a3b8" />
          <Text style={styles.infoText}>{item.area} - {item.address}</Text>
        </View>
        {item.totalDue !== undefined && item.totalDue > 0 && (
          <View style={styles.infoRow}>
            <Icon name="money-off" size={16} color="#ef4444" />
            <Text style={[styles.infoText, { color: '#ef4444' }]}>
              Due: ₹{item.totalDue}
            </Text>
          </View>
        )}
      </View>
      
      <View style={styles.preferenceInfo}>
        <View style={[
          styles.preferenceBadge,
          item.preference === 'veg' && styles.preferenceVeg,
          item.preference === 'non-veg' && styles.preferenceNonVeg,
          item.preference === 'jain' && styles.preferenceJain,
        ]}>
          <Text style={[
            styles.preferenceText,
            item.preference === 'veg' && styles.preferenceTextVeg,
            item.preference === 'non-veg' && styles.preferenceTextNonVeg,
            item.preference === 'jain' && styles.preferenceTextJain,
          ]}>
            {item.preference.charAt(0).toUpperCase() + item.preference.slice(1)}
          </Text>
        </View>
        <Text style={styles.rateInfo}>₹{item.tiffinRate}/month</Text>
      </View>
      
      <View style={styles.customerActions}>
        <TouchableOpacity 
          style={[styles.actionBtn, styles.billBtn]}
          onPress={() => generateBill(item)}
        >
          <Icon name="receipt" size={16} color="#fff" />
          <Text style={styles.billBtnText}>Generate Bill</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.actionBtn, styles.editBtn]}
          onPress={() => editCustomer(item)}
        >
          <Icon name="edit" size={16} color="#0ea5e9" />
          <Text style={styles.editBtnText}>Edit</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.actionBtn, styles.deleteBtn]}
          onPress={() => deleteCustomer(item._id)}
        >
          <Icon name="delete" size={16} color="#ef4444" />
          <Text style={styles.deleteBtnText}>Delete</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  if (loading && !refreshing) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingState}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>Loading customers...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />
      
      {/* Header */}
    

      <View style={styles.topBarContainer}>
        {/* Search Container with animated width */}
        <Animated.View style={[styles.searchContainer, { width: searchWidth }]}>
          <Icon name="search" size={20} color="#64748b" style={styles.searchIcon} />
          <TextInput
            ref={searchInputRef}
            style={styles.searchInput}
            placeholder="Search"
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
            onFocus={handleSearchFocus}
            onBlur={handleSearchBlur}
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={clearSearch}>
              <Icon name="close" size={20} color="#64748b" />
            </TouchableOpacity>
          )}
        </Animated.View>

        {/* Pagination - Animated opacity */}
        <Animated.View style={[styles.paginationContainer, { opacity: paginationOpacity }]}>
          <TouchableOpacity
            style={styles.paginationButton}
            onPress={goToPrevPage}
            disabled={currentPage === 1 || totalPages === 0}
          >
            <Icon
              name="chevron-left"
              size={20}
              color={currentPage === 1 || totalPages === 0 ? "#94a3b8" : "#3b82f6"}
            />
          </TouchableOpacity>

          <Text style={styles.paginationInfo}>
            {totalPages === 0 ? "0/0" : `${currentPage} / ${totalPages}`}
          </Text>

          <TouchableOpacity
            style={styles.paginationButton}
            onPress={goToNextPage}
            disabled={currentPage === totalPages || totalPages === 0}
          >
            <Icon
              name="chevron-right"
              size={20}
              color={currentPage === totalPages || totalPages === 0 ? "#94a3b8" : "#3b82f6"}
            />
          </TouchableOpacity>
        </Animated.View>
      </View>

      {/* Main Content - Customer List */}
      <View style={styles.mainContent}>
        <View style={styles.listHeader}>
          <View style={styles.cardTitleContainer}>
            <Text style={styles.cardTitle}>Customers</Text>
            <View style={styles.customerCount}>
              <Text style={styles.customerCountText}>{filteredCustomers.length}</Text>
            </View>
          </View>
        </View>

        {filteredCustomers.length === 0 ? (
          <View style={styles.emptyState}>
            <Icon name="people-outline" size={80} color="#cbd5e1" />
            <Text style={styles.emptyTitle}>
              {searchQuery ? 'No matching customers' : 'No Customers'}
            </Text>
            <Text style={styles.emptySubtitle}>
              {searchQuery ? 'Try a different search term' : 'Add your first customer to get started'}
            </Text>
          </View>
        ) : (
          <>
            <FlatList
              data={paginatedCustomers}
              renderItem={renderCustomerItem}
              keyExtractor={item => item._id}
              refreshing={refreshing}
              onRefresh={loadCustomers}
              refreshControl={
                <RefreshControl
                  refreshing={refreshing}
                  onRefresh={loadCustomers}
                  colors={['#3b82f6']}
                  tintColor={'#3b82f6'}
                />
              }
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.listContent}
            />
          </>
        )}
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingBottom:130,
    backgroundColor: '#f8fafcff',
  },
  headerSection: {
    backgroundColor: '#2c95f8',
    paddingHorizontal: 24,
    paddingBottom: 20,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    overflow: 'hidden',
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 1,
    marginTop: 15,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 40,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  addButton: {
    width: 40,
    height: 40,
    top: 20,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitleContainer: {
    flex: 1,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '600',
    marginTop: 40,
    color: '#fff',
  },
  headerSubtitle: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  topBarContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginHorizontal: 16,
    marginTop: 12,
  },
  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: 30,
    paddingHorizontal: 16,
    height: 45,
    marginTop:10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    marginTop:1,
    marginBottom:2,
    color: "#1e293b",
  },
  paginationContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f8fafc",
    borderRadius: 20,
    marginTop:9,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  paginationButton: {
    paddingHorizontal: 6,
  },
  paginationInfo: {
    fontSize: 14,
    color: "#64748b",
    fontWeight: "500",
    marginHorizontal: 6,
  },
  mainContent: {
    flex: 1,
    padding: 16,
    paddingTop: 0,
    paddingBottom: 0,
    marginTop:7,
  },
  listHeader: {
    marginBottom: 16,
  },
  cardTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1e293b',
  },
  customerCount: {
    backgroundColor: '#10b981',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  customerCountText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  listContent: {
    paddingBottom: 16,
  },
  customerCard: {
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 1,
  },
  customerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  customerName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e293b',
    marginBottom: 6,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  statusActive: {
    backgroundColor: '#dcfce7',
  },
  statusInactive: {
    backgroundColor: '#fee2e2',
  },
  statusText: {
    fontSize: 12,
    fontWeight: '500',
  },
  statusTextActive: {
    color: '#16a34a',
  },
  statusTextInactive: {
    color: '#dc2626',
  },
  statusToggle: {
    padding: 4,
  },
  customerInfo: {
    marginBottom: 12,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    color: '#64748b',
    marginLeft: 8,
    flex: 1,
  },
  preferenceInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  preferenceBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  preferenceVeg: {
    backgroundColor: '#dcfce7',
  },
  preferenceNonVeg: {
    backgroundColor: '#fee2e2',
  },
  preferenceJain: {
    backgroundColor: '#fef3c7',
  },
  preferenceText: {
    fontSize: 12,
    fontWeight: '500',
  },
  preferenceTextVeg: {
    color: '#16a34a',
  },
  preferenceTextNonVeg: {
    color: '#dc2626',
  },
  preferenceTextJain: {
    color: '#d97706',
  },
  rateInfo: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1e293b',
  },
  customerActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 12,
  },
  actionBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    gap: 6,
  },
  billBtn: {
    backgroundColor: '#7190fa',
    flex: 4,
    justifyContent: 'center',
  },
  editBtn: {
    backgroundColor: '#e0f2fe',
    flex: 2,
    justifyContent: 'center',
    marginHorizontal: 8,
  },
  deleteBtn: {
    backgroundColor: '#fee2e2',
    flex: 2,
    justifyContent: 'center',
  },
  billBtnText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '500',
  },
  editBtnText: {
    color: '#0ea5e9',
    fontSize: 12,
    fontWeight: '500',
  },
  deleteBtnText: {
    color: '#ef4444',
    fontSize: 12,
    fontWeight: '500',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
    flex: 1,
    marginTop:-130,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#334155',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
  },
  loadingState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  loadingText: {
    color: '#64748b',
    fontSize: 14,
    marginTop: 16,
  },
});

export default CustomerListScreen;