// AddCustomerScreen.tsx
import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Alert,
  Platform,
  SafeAreaView,
  StatusBar,
  Animated,
  Dimensions,
  Switch,
  ActivityIndicator,
} from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { StackNavigationProp } from '@react-navigation/stack';
import { RouteProp, useRoute } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons, MaterialIcons, Feather } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useAppSelector, useAppDispatch } from './store/hooks';
import { createCustomer, updateCustomer, setCurrentCustomer } from './store/slices/customerslice';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const { width, height } = Dimensions.get('window');

type RootStackParamList = {
  AddCustomer: { customer?: Customer };
  CustomerList: undefined;
  Profile: undefined;
};

type AddCustomerScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'AddCustomer'
>;

type Props = {
  navigation: AddCustomerScreenNavigationProp;
  route: RouteProp<RootStackParamList, 'AddCustomer'>;
};

type CustomerPreference = 'veg' | 'non-veg' | 'jain';

type Customer = {
  _id?: string;
  name: string;
  phone: string;
  address: string;
  area: string;
  preference: CustomerPreference;
  tiffinRate: number;
  isActive: boolean;
  providerId: string;
};

// Floating Input Component (unchanged)
const FloatingInput = ({ 
  label, 
  value, 
  onChangeText, 
  keyboardType = 'default',
  multiline = false,
  maxLength,
  prefix
}: {
  label: string;
  value: string;
  onChangeText: (text: string) => void;
  keyboardType?: any;
  multiline?: boolean;
  maxLength?: number;
  prefix?: string;
}) => {
  const [isFocused, setIsFocused] = useState(false);
  const animatedValue = useRef(new Animated.Value(value ? 1 : 0)).current;

  useEffect(() => {
    Animated.timing(animatedValue, {
      toValue: (isFocused || value) ? 1 : 0,
      duration: 150,
      useNativeDriver: false,
    }).start();
  }, [animatedValue, isFocused, value]);

  const labelStyle = {
    position: 'absolute',
    left: prefix ? 60 : 20,
    top: animatedValue.interpolate({
      inputRange: [0, 1],
      outputRange: [20, -10],
    }),
    fontSize: animatedValue.interpolate({
      inputRange: [0, 1],
      outputRange: [16, 13],
    }),
    color: animatedValue.interpolate({
      inputRange: [0, 1],
      outputRange: ['#9CA3AF', '#6366F1'],
    }),
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 6,
    fontWeight: '500',
    zIndex: 1,
  } as any;

  const containerStyle = {
    borderColor: animatedValue.interpolate({
      inputRange: [0, 1],
      outputRange: ['#E5E7EB', '#6366F1'],
    }),
  } as any;

  return (
    <View style={styles.inputContainer}>
      <Animated.View style={[styles.inputWrapper, containerStyle]}>
        <Animated.Text style={labelStyle}>
          {label}
        </Animated.Text>
        {prefix && (
          <View style={styles.prefixContainer}>
            <Text style={styles.prefixText}>{prefix}</Text>
          </View>
        )}
        <TextInput
          style={[
            styles.input,
            prefix && styles.inputWithPrefix,
            multiline && styles.multilineInput
          ]}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          onChangeText={onChangeText}
          value={value}
          keyboardType={keyboardType}
          multiline={multiline}
          maxLength={maxLength}
          textAlignVertical={multiline ? 'top' : 'center'}
        />
      </Animated.View>
    </View>
  );
};

const AddCustomerScreen: React.FC<Props> = ({ navigation, route }) => {
  const provider = useAppSelector((state) => state.provider);
  const { currentCustomer, loading } = useAppSelector((state) => state.customer);
  const providerId = provider.id;
  const dispatch = useAppDispatch();
  
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [email, setEmail]=useState('');
  const [area, setArea] = useState('');
  const [tiffinRate, setTiffinRate] = useState('');
  const [preference, setPreference] = useState<CustomerPreference>('veg');
  const [isActive, setIsActive] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  
  // ✅ Add a ref to track if we've initialized from Redux
  const hasInitializedFromRedux = useRef(false);

  const scrollViewRef = useRef<KeyboardAwareScrollView>(null);
  const tiffinRateRef = useRef<TextInput>(null);

  const nav = useNavigation();
  
  // ✅ Get safe area insets for automatic bottom spacing - JUST LIKE YOUR BOTTOM NAVBAR
  const insets = useSafeAreaInsets();
  
  useEffect(() => {
    nav.setOptions({
      headerShown: false,
    });

    // ✅ Only initialize from Redux once when component mounts
    if (currentCustomer && currentCustomer._id && !hasInitializedFromRedux.current) {
      console.log('🔄 Initializing edit form from Redux:', currentCustomer);
      setIsEditing(true);
      setName(currentCustomer.name);
      setPhone(currentCustomer.phone);
      setEmail(currentCustomer.email);
      setAddress(currentCustomer.address);
      setArea(currentCustomer.area);
      setTiffinRate(currentCustomer.tiffinRate.toString());
      setPreference(currentCustomer.preference);
      setIsActive(currentCustomer.isActive);
      hasInitializedFromRedux.current = true;
    } else if (!currentCustomer && !hasInitializedFromRedux.current) {
      // ✅ Only reset form if there's NO currentCustomer AND we haven't initialized yet
      console.log('🔄 Initializing add form');
      resetForm();
      hasInitializedFromRedux.current = true;
    }
  }, [nav, currentCustomer]);

  // ✅ Clear Redux state only when component unmounts (going back)
  useEffect(() => {
    return () => {
      // Only clear if we're not in the middle of an operation
      if (!loading) {
        console.log('🧹 Cleaning up Redux state on unmount');
        dispatch(setCurrentCustomer(null));
        hasInitializedFromRedux.current = false;
      }
    };
  }, [loading, dispatch]);

  // ✅ handleBackPress - just go back, cleanup happens in useEffect above
  const handleBackPress = () => {
    nav.goBack();
  };

  const handleSubmit = async () => {
    if (!name.trim() || !phone.trim() || !address.trim() || !tiffinRate.trim()) {
      Alert.alert('Required Fields', 'Please fill all required fields');
      return;
    }

    if (phone.length !== 10) {
      Alert.alert('Invalid Phone', 'Please enter a valid 10-digit phone number');
      return;
    }

    if (!email.trim()) {
  Alert.alert('Required Fields', 'Please enter customer email');
  return;
}

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
if (!emailRegex.test(email.trim())) {
  Alert.alert('Invalid Email', 'Please enter a valid email address');
  return;
}

    const tiffinRateValue = parseInt(tiffinRate.trim());
    if (isNaN(tiffinRateValue) || tiffinRateValue <= 0) {
      Alert.alert('Invalid Rate', 'Please enter a valid tiffin rate');
      return;
    }

    if (!providerId) {
      Alert.alert('Error', 'Provider information is missing. Please try again.');
      return;
    }

    const customerData = {
      name: name.trim(),
      phone: phone.trim(),
      email:email.trim(),
      address: address.trim(),
      area: area.trim(),
      preference,
      tiffinRate: tiffinRateValue,
      isActive,
      providerId,
    };

    console.log('Submitting customer data:', customerData);

    try {
      if (isEditing && currentCustomer?._id) {
        await dispatch(updateCustomer({
          id: currentCustomer._id,
          customerData
        })).unwrap();
        
        // ✅ Clear current customer after successful update
        dispatch(setCurrentCustomer(null));
        
        Alert.alert(
          'Success', 
          'Customer updated successfully!', 
          [{ text: 'OK', onPress: () => nav.goBack() }]
        );
      } else {
        await dispatch(createCustomer(customerData)).unwrap();
        
        Alert.alert(
          'Success', 
          'Customer added successfully!', 
          [
            { 
              text: 'Add Another', 
              onPress: () => {
                // ✅ Reset form for new entry
                resetForm();
                hasInitializedFromRedux.current = false;
              }
            },
            { 
              text: 'Done', 
              onPress: () => nav.goBack()
            }
          ]
        );
      }
    } catch (error: any) {
      console.error('Full error object:', error);
      console.error('Error response:', error.response?.data);
      
      if (error.response?.data?.error) {
        Alert.alert('Error', error.response.data.error);
      } else if (error.message && error.message.includes('Phone number already exists')) {
        Alert.alert('Error', 'This phone number is already registered for a customer');
      } else {
        Alert.alert('Error', `Failed to ${isEditing ? 'update' : 'add'} customer. Please try again.`);
      }
    }
  };

  // ✅ resetForm only clears form, not Redux
  const resetForm = () => {
    setName('');
    setPhone('');
    setEmail('');
    setAddress('');
    setArea('');
    setTiffinRate('');
    setPreference('veg');
    setIsActive(true);
    setIsEditing(false);
    // ❌ Don't clear Redux here - let the unmount effect handle it
  };

  const preferences = [
    { 
      key: 'veg', 
      label: 'Veg', 
      icon: <Ionicons name="leaf" size={20} color="#22C55E" />, 
      color: '#22C55E' 
    },
    { 
      key: 'non-veg', 
      label: 'Non-Veg', 
      icon: <MaterialIcons name="set-meal" size={20} color="#EF4444" />, 
      color: '#EF4444' 
    },
    { 
      key: 'jain', 
      label: 'Jain', 
      icon: <Feather name="feather" size={20} color="#F59E0B" />, 
      color: '#F59E0B' 
    },
  ];

  // ✅ Calculate bottom padding dynamically - JUST LIKE YOUR BOTTOM NAVBAR
  const bottomPadding = Math.max(insets.bottom, 16) + 10;

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
      
      {/* Header */}
      <View style={[styles.headerSection, { paddingTop: insets.top + 16 }]}>
        <View style={styles.headerContent}>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={handleBackPress}
            disabled={loading}
          >
            <Ionicons name="arrow-back" size={24} color="#0b0b0b" />
          </TouchableOpacity>
          
          <View style={styles.headerTitleContainer}>
            <Text style={styles.headerTitle}>
              {isEditing ? 'Edit Customer' : 'Add Customer'}
            </Text>
          </View>
          
          <View style={styles.backButton} />
        </View>
      </View>

      <KeyboardAwareScrollView
        ref={scrollViewRef}
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: bottomPadding + 100 } // Extra space for the button area
        ]}
        showsVerticalScrollIndicator={false}
        enableOnAndroid={true}
        extraScrollHeight={100}
        extraHeight={100}
        keyboardOpeningTime={0}
        enableResetScrollToCoords={false}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.form}>
          <FloatingInput
            label="Full Name"
            value={name}
            onChangeText={setName}
          />
          <FloatingInput
            label="Phone Number"
            value={phone}
            onChangeText={setPhone}
            keyboardType="phone-pad"
            maxLength={10}
            prefix="+91"
          />
          <FloatingInput
           label="Email"
           value={email}
           onChangeText={setEmail}
           keyboardType="email-address"
          />

          <FloatingInput
            label="Address"
            value={address}
            onChangeText={setAddress}
            multiline={true}
          />
          
          <FloatingInput
            label="Area / Locality (Optional)"
            value={area}
            onChangeText={setArea}
          />

          {/* Food Preference */}
          <View style={styles.preferenceSection}>
            <Text style={styles.preferenceTitle}>Food Preference</Text>
            <View style={styles.preferenceContainer}>
              {preferences.map((item) => (
                <TouchableOpacity
                  key={item.key}
                  style={[
                    styles.preferenceItem,
                    preference === item.key && {
                      backgroundColor: `${item.color}15`,
                      borderColor: item.color,
                    }
                  ]}
                  onPress={() => setPreference(item.key as CustomerPreference)}
                  activeOpacity={0.7}
                >
                  <View style={styles.preferenceContent}>
                    <View style={styles.preferenceIcon}>
                      {item.icon}
                    </View>
                    <Text style={[
                      styles.preferenceText,
                      preference === item.key && { color: item.color, fontWeight: '600' }
                    ]}>
                      {item.label}
                    </Text>
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          </View>
          
          {/* Fixed label to Tiffin Rate */}
          <FloatingInput
            label="Tiffin Rate (₹)"
            value={tiffinRate}
            onChangeText={setTiffinRate}
            keyboardType="numeric"
          />

          {/* Active Status */}
          <View style={styles.activeSection}>
            <View style={styles.activeLabelContainer}>
              <Text style={styles.activeLabel}>Active Status</Text>
              {/* <Text style={styles.activeNote}>Note: User will be active by default</Text> */}
            </View>
            <Switch
              value={isActive}
              onValueChange={setIsActive}
              trackColor={{ false: '#E5E7EB', true: '#2c44f8ff' }}
              thumbColor={isActive ? '#FFFFFF' : '#F3F4F6'}
            />
          </View>
        </View>
      </KeyboardAwareScrollView>

      {/* Submit Button - Using dynamic bottom padding like your navbar */}
      <View style={[
        styles.bottomContainer,
        { 
          paddingBottom: bottomPadding,
          paddingTop: 20,
        }
      ]}>
        <TouchableOpacity 
          style={[styles.submitButton, loading && styles.submitButtonDisabled]}
          onPress={handleSubmit}
          activeOpacity={0.9}
          disabled={loading}
        >
          <LinearGradient
            colors={['#32C0DA', '#5695edff']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.submitGradient}
          >
            {loading ? (
              <ActivityIndicator color="#FFFFFF" />
            ) : (
              <Text style={styles.submitText}>
                {isEditing ? 'Update Customer' : 'Add Customer'}
              </Text>
            )}
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    paddingBottom:40,
  },
  mainContent:{
    flex:1,
  },
  headerSection: {
    padding: 16,
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 3,
    zIndex: 10,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitleContainer: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#050000ff',
    textAlign: 'center',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 4,
    flexGrow: 1,
  },
  form: {
    paddingHorizontal: 24,
    paddingTop: 10,
    paddingBottom: 20,
  },
  inputContainer: {
    marginBottom: 18,
  },
  inputWrapper: {
    borderWidth: 1.5,
    borderRadius: 16,
    backgroundColor: '#FFFFFF',
    position: 'relative',
  },
  prefixContainer: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 50,
    alignItems: 'center',
    justifyContent: 'center',
    borderRightWidth: 1,
    borderRightColor: '#E5E7EB',
    borderTopLeftRadius: 16,
    borderBottomLeftRadius: 16,
    backgroundColor: '#F9FAFB',
  },
  prefixText: {
    fontSize: 16,
    color: '#6B7280',
    fontWeight: '600',
  },
  input: {
    fontSize: 16,
    color: '#1F2937',
    paddingHorizontal: 10,
    paddingVertical: 10,
    fontWeight: '300',
    minHeight: 58,
  },
  inputWithPrefix: {
    paddingLeft: 65,
  },
  multilineInput: {
    minHeight: 100,
    textAlignVertical: 'top',
    paddingTop: 24,
    paddingBottom: 20,
  },
  preferenceSection: {
    marginBottom: 28,
  },
  preferenceTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 16,
    marginLeft: 4,
  },
  preferenceContainer: {
    flexDirection: 'row',
    gap: 12,
  },
  preferenceItem: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderRadius: 16,
    borderWidth: 1.5,
    borderColor: '#E5E7EB',
    backgroundColor: '#FAFAFA',
  },
  preferenceContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  preferenceIcon: {
    // Icon styling is handled in the icon component itself
  },
  preferenceText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#6B7280',
  },
  activeSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 1,
    paddingHorizontal: 4,
   height:40,
    backgroundColor: '#FAFAFA',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#F3F4F6',
  },
  activeLabelContainer: {
    flex: 1,
  },
  activeLabel: {
    fontSize: 14,
    fontWeight: '600',
    left:5,
    color: '#374151',
    marginBottom: 4,
  },
  activeNote: {
    fontSize: 12,
    left:5,
    color: '#6B7280',
    fontStyle: 'italic',
  },
  bottomContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 24,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
  },
  submitButton: {
    borderRadius: 16,
    shadowColor: '#6366F1',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    marginBottom: 0,
  },
  submitGradient: {
    paddingVertical: 18,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  submitText: {
    fontSize: 17,
    fontWeight: '600',
    color: '#FFFFFF',
    letterSpacing: 0.5,
  },
  submitButtonDisabled: {
    opacity: 0.7,
  },
});

export default AddCustomerScreen;