
// CustomerListScreen.tsx
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  Alert,
  Animated,
  TextInput,
  ActivityIndicator,
  FlatList,
  Modal,
} from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RouteProp } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { useNavigation } from '@react-navigation/native';
import BottomNavBar from '@/components/navbar';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppSelector } from './store/hooks';

type RootStackParamList = {
  AddCustomer: Customer;
  CustomerList: undefined;
  Profile: undefined;
  Bill: undefined;
};

type CustomerListScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'CustomerList'
>;

type Props = {
  navigation: CustomerListScreenNavigationProp;
  route: RouteProp<RootStackParamList, 'CustomerList'>;
};

type Customer = {
  _id: string;
  name: string;
  phone: string;
  address: string;
  area: string;
  preference: 'veg' | 'non-veg' | 'jain';
  tiffinRate: string;
  isActive: boolean;
  createdAt: string;
  providerId: string;
  totalDue?: number;
};

interface HeaderProps {
  onBackPress?: () => void;
  onUserPress?: () => void; 
}

const API_BASE_URL = 'http://192.168.1.178:5000/api';

const CustomerListScreen: React.FC<Props> = ({ navigation }) => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const provider = useAppSelector((state) => state.provider)
  const providerId = provider.id;

  const [filteredCustomers, setFilteredCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeNav, setActiveNav] = useState('Menu');
  const navbarOpacity = new Animated.Value(1);
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [showRowsPerPageDropdown, setShowRowsPerPageDropdown] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const nav = useNavigation();
  useEffect(() => {
    nav.setOptions({
      headerShown: false,
    });
  }, [nav]);

  useEffect(() => {
    loadCustomers();
  }, []);

  useEffect(() => {
    filterCustomers();
  }, [searchQuery, customers]);

  const loadCustomers = async () => {
    setRefreshing(true);
    try {
      const providerId = provider.id;
      const response = await fetch(`${API_BASE_URL}/customer/provider/${providerId}`);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data.success) {
        setCustomers(data.data);
        setFilteredCustomers(data.data);
      } else {
        Alert.alert("Error", data.error || "Failed to load customers");
      }
    } catch (error) {
      console.error('Error loading customers:', error);
      Alert.alert("Error", "Failed to load customers. Please try again.");
      // Fallback to sample data if API fails
      const sampleCustomers: Customer[] = [
        {
          _id: "1",
          name: "Priya Sharma",
          phone: "9876543210",
          address: "A-201, Sunrise Apartment, Near City Mall",
          area: "Satellite",
          preference: "veg",
          tiffinRate: "2500",
          isActive: true,
          createdAt: "2024-01-15T10:30:00Z",
          providerId: "688c5d434465f78de4315962"
        },
        {
          _id: "2",
          name: "Rahul Patel",
          phone: "8765432109",
          address: "B-102, Green Valley Society, Near Bus Stand",
          area: "Navrangpura",
          preference: "non-veg",
          tiffinRate: "2800",
          isActive: true,
          createdAt: "2024-01-20T11:45:00Z",
          providerId: "688c5d434465f78de4315962"
        },
        {
          _id: "3",
          name: "Sunita Mehta",
          phone: "7654321098",
          address: "C-503, Shanti Nagar, Opp. Police Station",
          area: "Maninagar",
          preference: "jain",
          tiffinRate: "2600",
          isActive: false,
          createdAt: "2024-02-05T09:15:00Z",
          providerId: "688c5d434465f78de4315962"
        },
      ];
      setCustomers(sampleCustomers);
      setFilteredCustomers(sampleCustomers);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const filterCustomers = () => {
    if (!searchQuery.trim()) {
      setFilteredCustomers(customers);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = customers.filter(customer => 
      customer.name.toLowerCase().includes(query) ||
      customer.phone.includes(query) ||
      customer.area.toLowerCase().includes(query) ||
      customer.address.toLowerCase().includes(query)
    );
    
    setFilteredCustomers(filtered);
    setCurrentPage(1);
  };

  const deleteCustomer = async (customerId: string) => {
    Alert.alert(
      "Confirm Delete",
      "Are you sure you want to delete this customer?",
      [
        {
          text: "Cancel",
          style: "cancel"
        },
        { 
          text: "Delete", 
          onPress: async () => {
            try {
              const response = await fetch(`${API_BASE_URL}/customer/${customerId}`, {
                method: 'DELETE',
              });
              
              if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
              }
              
              const data = await response.json();
              
              if (data.success) {
                const updatedCustomers = customers.filter(c => c._id !== customerId);
                setCustomers(updatedCustomers);
                Alert.alert("Success", "Customer deleted successfully!");
              } else {
                Alert.alert("Error", data.error || "Failed to delete customer");
              }
            } catch (error) {
              console.error('Error deleting customer:', error);
              Alert.alert("Error", "Failed to delete customer. Please try again.");
            }
          }
        }
      ]
    );
  };

  const toggleCustomerStatus = async (customerId: string, currentStatus: boolean) => {
    try {
      const response = await fetch(`${API_BASE_URL}/customer/${customerId}/toggle-active`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data.success) {
        // Update local state
        const updatedCustomers = customers.map(customer =>
          customer._id === customerId
            ? { ...customer, isActive: !currentStatus }
            : customer
        );
        setCustomers(updatedCustomers);
        Alert.alert("Success", `Customer ${!currentStatus ? 'activated' : 'deactivated'} successfully!`);
      } else {
        Alert.alert("Error", data.error || "Failed to update customer status");
      }
    } catch (error) {
      console.error('Error toggling customer status:', error);
      Alert.alert("Error", "Failed to update customer status. Please try again.");
    }
  };

  const handleNavigation = (screenName: string) => {
    setActiveNav(screenName);
  };

  const editCustomer = (customer: Customer) => {
    navigation.navigate('AddCustomer', { customer });
  };

  const generateBill = (customer: Customer) => {
    router.push({
      pathname:'/bill',
      params: { customer:customer._id }
    })
  };

  // Pagination logic
  const totalPages = Math.ceil(filteredCustomers.length / rowsPerPage);
  const startIndex = (currentPage - 1) * rowsPerPage;
  const endIndex = Math.min(startIndex + rowsPerPage, filteredCustomers.length);
  const paginatedCustomers = filteredCustomers.slice(startIndex, endIndex);
  const totalRows = filteredCustomers.length;

  const goToPage = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  const goToNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const goToPrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleRowsPerPageChange = (value: number) => {
    setRowsPerPage(value);
    setCurrentPage(1);
    setShowRowsPerPageDropdown(false);
  };

  // Function to generate page number buttons with ellipsis logic
  const getPageNumbers = () => {
    const pages = [];
    const maxVisiblePages = 5;
    
    if (totalPages <= maxVisiblePages) {
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i);
      }
    } else {
      pages.push(1);
      
      let startPage = Math.max(2, currentPage - 1);
      let endPage = Math.min(totalPages - 1, currentPage + 1);
      
      if (currentPage <= 3) {
        endPage = 4;
      }
      
      if (currentPage >= totalPages - 2) {
        startPage = totalPages - 3;
      }
      
      if (startPage > 2) {
        pages.push('ellipsis-left');
      }
      
      for (let i = startPage; i <= endPage; i++) {
        pages.push(i);
      }
      
      if (endPage < totalPages - 1) {
        pages.push('ellipsis-right');
      }
      
      pages.push(totalPages);
    }
    
    return pages;
  };

  const renderCustomerItem = ({ item }: { item: Customer }) => (
    <View style={styles.customerCard}>
      <View style={styles.customerHeader}>
        <View>
          <Text style={styles.customerName}>{item.name}</Text>
          <View style={[
            styles.statusBadge,
            item.isActive ? styles.statusActive : styles.statusInactive
          ]}>
            <Text style={[
              styles.statusText,
              item.isActive ? styles.statusTextActive : styles.statusTextInactive
            ]}>
              {item.isActive ? 'Active' : 'Inactive'}
            </Text>
          </View>
        </View>
        <TouchableOpacity
          onPress={() => toggleCustomerStatus(item._id, item.isActive)}
          style={styles.statusToggle}
        >
          <Icon
            name={item.isActive ? "toggle-on" : "toggle-off"}
            size={50}
            color={item.isActive ? "#10b981" : "#94a3b8"}
          />
        </TouchableOpacity>
      </View>
      
      <View style={styles.customerInfo}>
        <View style={styles.infoRow}>
          <Icon name="phone" size={16} color="#94a3b8" />
          <Text style={styles.infoText}>{item.phone}</Text>
        </View>
        <View style={styles.infoRow}>
          <Icon name="location-on" size={16} color="#94a3b8" />
          <Text style={styles.infoText}>{item.area} - {item.address}</Text>
        </View>
        {item.totalDue !== undefined && item.totalDue > 0 && (
          <View style={styles.infoRow}>
            <Icon name="money-off" size={16} color="#ef4444" />
            <Text style={[styles.infoText, { color: '#ef4444' }]}>
              Due: ₹{item.totalDue}
            </Text>
          </View>
        )}
      </View>
      
      <View style={styles.preferenceInfo}>
        <View style={[
          styles.preferenceBadge,
          item.preference === 'veg' && styles.preferenceVeg,
          item.preference === 'non-veg' && styles.preferenceNonVeg,
          item.preference === 'jain' && styles.preferenceJain,
        ]}>
          <Text style={[
            styles.preferenceText,
            item.preference === 'veg' && styles.preferenceTextVeg,
            item.preference === 'non-veg' && styles.preferenceTextNonVeg,
            item.preference === 'jain' && styles.preferenceTextJain,
          ]}>
            {item.preference.charAt(0).toUpperCase() + item.preference.slice(1)}
          </Text>
        </View>
        <Text style={styles.rateInfo}>₹{item.tiffinRate}/month</Text>
      </View>
      
      <View style={styles.customerActions}>
        <TouchableOpacity 
          style={[styles.actionBtn, styles.billBtn]}
          onPress={() => generateBill(item)}
        >
          <Icon name="receipt" size={16} color="#fff" />
          <Text style={styles.billBtnText}>Generate Bill</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.actionBtn, styles.editBtn]}
          onPress={() => editCustomer(item)}
        >
          <Icon name="edit" size={16} color="#0ea5e9" />
          <Text style={styles.editBtnText}>Edit</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.actionBtn, styles.deleteBtn]}
          onPress={() => deleteCustomer(item._id)}
        >
          <Icon name="delete" size={16} color="#ef4444" />
          <Text style={styles.deleteBtnText}>Delete</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingState}>
          <ActivityIndicator size="large" color="#3b82f6" />
          <Text style={styles.loadingText}>Loading customers...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />
      
      {/* Header */}
      <View style={styles.headerSection}>
        <View style={styles.headerContent}>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => navigation.goBack()}
          >
            <Icon name="arrow-back" size={24} color="#fff" />
          </TouchableOpacity>
          
          <View style={styles.headerTitleContainer}>
            <Text style={styles.headerTitle}>Customer List</Text>
            <Text style={styles.headerSubtitle}>Manage Customers</Text>
          </View>
          
          <TouchableOpacity 
            style={styles.addButton}
            onPress={() => {
              router.push({
                pathname:'/customer'
              });
            }}
          >
            <Icon name="add" size={24} color="#fff" />
          </TouchableOpacity>
        </View>

        {/* Search Box */}
        <View style={styles.searchContainer}>
          <Icon name="search" size={20} color="#64748b" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search customers by name, phone, area..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#94a3b8"
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={() => setSearchQuery('')}>
              <Icon name="close" size={20} color="#64748b" />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Main Content - Customer List */}
      <View style={styles.mainContent}>
        <View style={styles.listHeader}>
          <View style={styles.cardTitleContainer}>
            <Text style={styles.cardTitle}>Customers</Text>
            <View style={styles.customerCount}>
              <Text style={styles.customerCountText}>{filteredCustomers.length}</Text>
            </View>
          </View>
        </View>

        {filteredCustomers.length === 0 ? (
          <View style={styles.emptyState}>
            <Icon name="people-outline" size={80} color="#cbd5e1" />
            <Text style={styles.emptyTitle}>
              {searchQuery ? 'No matching customers' : 'No Customers'}
            </Text>
            <Text style={styles.emptySubtitle}>
              {searchQuery ? 'Try a different search term' : 'Add your first customer to get started'}
            </Text>
          </View>
        ) : (
          <>
            <FlatList
              data={paginatedCustomers}
              renderItem={renderCustomerItem}
              keyExtractor={item => item._id}
              refreshing={refreshing}
              onRefresh={loadCustomers}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.listContent}
            />
            
            {/* Pagination Controls - Updated Design */}
            {totalPages > 0 && (
              <View style={styles.paginationContainer}>
                {/* Rows per page selector */}
                <View style={styles.rowsPerPageContainer}>
                  <Text style={styles.rowsPerPageText}>Rows per page</Text>
                  <TouchableOpacity 
                    style={styles.rowsPerPageDropdown}
                    onPress={() => setShowRowsPerPageDropdown(!showRowsPerPageDropdown)}
                  >
                    <Text style={styles.rowsPerPageValue}>{rowsPerPage}</Text>
                    <Icon 
                      name={showRowsPerPageDropdown ? "arrow-drop-up" : "arrow-drop-down"} 
                      size={20} 
                      color="#64748b" 
                    />
                  </TouchableOpacity>
                  
                  {showRowsPerPageDropdown && (
                    <View style={styles.rowsPerPageOptions}>
                      {[10, 20, 30, 50].map(option => (
                        <TouchableOpacity
                          key={option}
                          style={[
                            styles.rowsPerPageOption,
                            rowsPerPage === option && styles.rowsPerPageOptionSelected
                          ]}
                          onPress={() => handleRowsPerPageChange(option)}
                        >
                          <Text style={[
                            styles.rowsPerPageOptionText,
                            rowsPerPage === option && styles.rowsPerPageOptionTextSelected
                          ]}>
                            {option}
                          </Text>
                        </TouchableOpacity>
                      ))}
                    </View>
                  )}
                </View>
                
                {/* Page info */}
                <Text style={styles.pageInfoText}>
                  {startIndex + 1}-{endIndex} of {totalRows} rows
                </Text>
                
                {/* Page navigation */}
                <View style={styles.pageNavigation}>
                  <TouchableOpacity 
                    style={[styles.navButton, currentPage === 1 && styles.navButtonDisabled]}
                    onPress={goToPrevPage}
                    disabled={currentPage === 1}
                  >
                    <Icon name="chevron-left" size={20} color={currentPage === 1 ? "#94a3b8" : "#3b82f6"} />
                  </TouchableOpacity>
                  
                  {/* Page numbers */}
                  {getPageNumbers().map((page, index) => {
                    if (page === 'ellipsis-left' || page === 'ellipsis-right') {
                      return (
                        <Text key={index} style={styles.ellipsis}>...</Text>
                      );
                    }
                    
                    return (
                      <TouchableOpacity
                        key={index}
                        style={[
                          styles.pageButton,
                          currentPage === page && styles.pageButtonActive
                        ]}
                        onPress={() => goToPage(page as number)}
                      >
                        <Text style={[
                          styles.pageButtonText,
                          currentPage === page && styles.pageButtonTextActive
                        ]}>
                          {page}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                  
                  <TouchableOpacity 
                    style={[styles.navButton, currentPage === totalPages && styles.navButtonDisabled]}
                    onPress={goToNextPage}
                    disabled={currentPage === totalPages}
                  >
                    <Icon name="chevron-right" size={20} color={currentPage === totalPages ? "#94a3b8" : "#3b82f6"} />
                  </TouchableOpacity>
                </View>
              </View>
            )}
          </>
        )}
      </View>
      
      {/* Add bottom padding to ensure content isn't hidden by navbar */}
      <View style={{ height: insets.bottom + 63 }} />
      
      <BottomNavBar 
        activeNav={activeNav} 
        setActiveNav={handleNavigation}
        navbarOpacity={navbarOpacity}
        insets={insets}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  headerSection: {
    backgroundColor: '#2c95f8',
    paddingHorizontal: 24,
    paddingBottom: 20,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    overflow: 'hidden',
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 1,
    marginTop: 15,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 40,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  addButton: {
    width: 40,
    height: 40,
    top: 20,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitleContainer: {
    flex: 1,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '600',
    marginTop: 40,
    color: '#fff',
  },
  headerSubtitle: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    marginHorizontal: 20,
    marginTop: 15,
    borderRadius: 30,
    paddingHorizontal: 16,
    height: 50,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#1e293b',
  },
  mainContent: {
    flex: 1,
    padding: 16,
    paddingTop: 0,
    paddingBottom: 0,
  },
  listHeader: {
    marginBottom: 16,
  },
  cardTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1e293b',
  },
  customerCount: {
    backgroundColor: '#10b981',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  customerCountText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  listContent: {
    paddingBottom: 16,
  },
  customerCard: {
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 1,
  },
  customerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  customerName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e293b',
    marginBottom: 6,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  statusActive: {
    backgroundColor: '#dcfce7',
  },
  statusInactive: {
    backgroundColor: '#fee2e2',
  },
  statusText: {
    fontSize: 12,
    fontWeight: '500',
  },
  statusTextActive: {
    color: '#16a34a',
  },
  statusTextInactive: {
    color: '#dc2626',
  },
  statusToggle: {
    padding: 4,
  },
  customerInfo: {
    marginBottom: 12,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    color: '#64748b',
    marginLeft: 8,
    flex: 1,
  },
  preferenceInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
  },
  preferenceBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  preferenceVeg: {
    backgroundColor: '#dcfce7',
  },
  preferenceNonVeg: {
    backgroundColor: '#fee2e2',
  },
  preferenceJain: {
    backgroundColor: '#fef3c7',
  },
  preferenceText: {
    fontSize: 12,
    fontWeight: '500',
  },
  preferenceTextVeg: {
    color: '#16a34a',
  },
  preferenceTextNonVeg: {
    color: '#dc2626',
  },
  preferenceTextJain: {
    color: '#d97706',
  },
  rateInfo: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1e293b',
  },
  customerActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 12,
  },
  actionBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    gap: 6,
  },
  billBtn: {
    backgroundColor: '#3b82f6',
    flex: 4,
    justifyContent: 'center',
  },
  editBtn: {
    backgroundColor: '#e0f2fe',
    flex: 2,
    justifyContent: 'center',
    marginHorizontal: 8,
  },
  deleteBtn: {
    backgroundColor: '#fee2e2',
    flex: 2,
    justifyContent: 'center',
  },
  billBtnText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '500',
  },
  editBtnText: {
    color: '#0ea5e9',
    fontSize: 12,
    fontWeight: '500',
  },
  deleteBtnText: {
    color: '#ef4444',
    fontSize: 12,
    fontWeight: '500',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
    flex: 1,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#334155',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
  },
  loadingState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  loadingText: {
    color: '#64748b',
    fontSize: 14,
    marginTop: 16,
  },
  // New pagination styles
  paginationContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 16,
    padding: 12,
    backgroundColor: '#fff',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  rowsPerPageContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    position: 'relative',
  },
  rowsPerPageText: {
    fontSize: 12,
    color: '#64748b',
    marginRight: 8,
  },
  rowsPerPageDropdown: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    minWidth: 50,
  },
  rowsPerPageValue: {
    fontSize: 12,
    color: '#334155',
    marginRight: 4,
  },
  rowsPerPageOptions: {
    position: 'absolute',
    top: 30,
    left: 80,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 4,
    zIndex: 10,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  rowsPerPageOption: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    minWidth: 50,
  },
  rowsPerPageOptionSelected: {
    backgroundColor: '#f1f5f9',
  },
  rowsPerPageOptionText: {
    fontSize: 12,
    color: '#334155',
  },
  rowsPerPageOptionTextSelected: {
    color: '#3b82f6',
    fontWeight: '500',
  },
  pageInfoText: {
    fontSize: 12,
    color: '#64748b',
  },
  pageNavigation: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  navButton: {
    padding: 4,
    marginHorizontal: 2,
  },
  navButtonDisabled: {
    opacity: 0.5,
  },
  pageButton: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    marginHorizontal: 2,
    borderRadius: 4,
    minWidth: 30,
    alignItems: 'center',
  },
  pageButtonActive: {
    backgroundColor: '#3b82f6',
  },
  pageButtonText: {
    fontSize: 12,
    color: '#64748b',
  },
  pageButtonTextActive: {
    color: '#fff',
    fontWeight: '500',
  },
  ellipsis: {
    paddingHorizontal: 4,
    color: '#64748b',
  },
});

export default CustomerListScreen;