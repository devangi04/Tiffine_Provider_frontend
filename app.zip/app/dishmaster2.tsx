import React, { useState, useEffect, useRef } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  Platform,
  StyleSheet, 
  Alert,
  Animated,
  ActivityIndicator,
  Switch,
  Keyboard
} from 'react-native';

import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Plus, Edit2, Trash2, Save, X, ChevronDown, ChevronUp } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import axios from 'axios';
import BottomNavBar from '@/components/navbar';
import Header from '@/components/header';
import { useNavigation } from '@react-navigation/native';
import { useAppSelector } from './store/hooks';

const API_BASE_URL = 'http://192.168.1.178:5000/api/dish';

interface Dish {
  _id: string;
  name: string;
  category: string;
  providerId: string;
  isActive?: boolean;
}

interface DishCategory {
  id: string;
  name: string;
  emoji: string;
}

const DishMasterScreen: React.FC = () => {
  const categories: DishCategory[] = [
    { id: 'roti', name: 'Roti', emoji: '🫓' },
    { id: 'sabji', name: 'Sabji', emoji: '🥬' },
    { id: 'rice', name: 'Rice', emoji: '🍚' },
    { id: 'dal', name: 'Dal', emoji: '🍲' },
    { id: 'extra', name: 'Extras', emoji: '🍽️' },
  ];

  const [dishes, setDishes] = useState<Dish[]>([]);
  const [activeNav, setActiveNav] = useState('Menu');
  const [editingDish, setEditingDish] = useState<string | null>(null);
  const [editingName, setEditingName] = useState<string>('');
  const [editingActive, setEditingActive] = useState<boolean>(true);
  const [newDishName, setNewDishName] = useState<string>('');
  const [newDishActive, setNewDishActive] = useState<boolean>(true);
  const [showAddForm, setShowAddForm] = useState<string | null>(null);
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  
  // Refs for text inputs to prevent focus loss
  const addInputRef = useRef<TextInput>(null);
  const editInputRef = useRef<TextInput>(null);

  //redux
  const provider = useAppSelector((state) => state.provider);
  const providerId = provider.id;
  const navbarOpacity = new Animated.Value(1);
  const router = useRouter();
  const insets = useSafeAreaInsets();

  useEffect(() => {
    console.log("this is calledddd");
    
    if (!providerId) {
      console.log("inside if dishmaster");
      
      Alert.alert('Error', 'provider not Found please login again');
      router.push('/login');
      return;
    }
    
    const fetchDishes = async () => {
      try {
        setLoading(true);
        const response = await axios.get(`${API_BASE_URL}/provider/${providerId}`);
        setDishes(response.data.data);
      } catch (error) {
        Alert.alert('Error', 'Failed to fetch dishes');
        console.error('Error fetching dishes:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDishes();
  }, [providerId]);

  const nav = useNavigation();
  useEffect(() => {
    nav.setOptions({
      headerShown: false,
    });
  }, [nav]);

  const handleAddDish = async (categoryId: string) => {
    if (!newDishName.trim()) {
      Alert.alert('Error', 'Dish name cannot be empty');
      return;
    }

    try {
      setLoading(true);
      const response = await axios.post(`${API_BASE_URL}/`, {
        providerId,
        name: newDishName.trim(),
        category: categoryId,
        isActive: newDishActive
      });
      
      setDishes([...dishes, response.data.data]);
      setNewDishName('');
      setNewDishActive(true);
      setShowAddForm(null);
      Keyboard.dismiss();
    } catch (error) {
      Alert.alert('Error', 'Failed to add dish');
      console.error('Error adding dish:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEditStart = (dish: Dish) => {
    setEditingDish(dish._id);
    setEditingName(dish.name);
    setEditingActive(dish.isActive !== undefined ? dish.isActive : true);
    
    // Focus on the input after a small delay to ensure it's rendered
    setTimeout(() => {
      if (editInputRef.current) {
        editInputRef.current.focus();
      }
    }, 100);
  };

  const handleEditSave = async () => {
    if (!editingName.trim() || !editingDish) {
      Alert.alert('Error', 'Dish name cannot be empty');
      return;
    }

    try {
      setLoading(true);
      await axios.patch(`${API_BASE_URL}/${editingDish}`, {
        name: editingName.trim(),
        isActive: editingActive
      });

      setDishes(dishes.map(dish =>
        dish._id === editingDish ? { ...dish, name: editingName.trim(), isActive: editingActive } : dish
      ));
      
      setEditingDish(null);
      setEditingName('');
      setEditingActive(true);
      Keyboard.dismiss();
    } catch (error) {
      Alert.alert('Error', 'Failed to update dish');
      console.error('Error updating dish:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEditCancel = () => {
    setEditingDish(null);
    setEditingName('');
    setEditingActive(true);
    Keyboard.dismiss();
  };

  const handleDeleteDish = (dishId: string) => {
    Alert.alert(
      'Delete Dish',
      'Are you sure you want to delete this dish?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Delete',
          onPress: async () => {
            try {
              setLoading(true);
              await axios.delete(`${API_BASE_URL}/${dishId}`);
              setDishes(dishes.filter(dish => dish._id !== dishId));
            } catch (error) {
              Alert.alert('Error', 'Failed to delete dish');
              console.error('Error deleting dish:', error);
            } finally {
              setLoading(false);
            }
          },
          style: 'destructive',
        },
      ],
    );
  };

  const handleCancelAdd = (categoryId: string) => {
    if (showAddForm === categoryId) {
      setShowAddForm(null);
    } else {
      setShowAddForm(categoryId);
    }
    setNewDishName('');
    setNewDishActive(true);
    Keyboard.dismiss();
  };

  const toggleCategoryExpand = (categoryId: string) => {
    setExpandedCategory(expandedCategory === categoryId ? null : categoryId);
    setShowAddForm(null);
    setEditingDish(null);
  };

  const getCategoryCount = (categoryId: string): number => {
    return dishes.filter((dish: Dish) => dish.category === categoryId).length;
  };

  const getActiveCategoryCount = (categoryId: string): number => {
    return dishes.filter((dish: Dish) => dish.category === categoryId && dish.isActive).length;
  };

  const DishItem: React.FC<{ 
    item: Dish; 
    isEditing: boolean; 
    editingName: string;
    editingActive: boolean;
    onEditStart: (dish: Dish) => void;
    onEditSave: () => void;
    onEditCancel: () => void;
    onDelete: (dishId: string) => void;
    onEditingNameChange: (text: string) => void;
    onEditingActiveChange: (value: boolean) => void;
  }> = ({ 
    item, 
    isEditing, 
    editingName, 
    editingActive,
    onEditStart, 
    onEditSave, 
    onEditCancel, 
    onDelete, 
    onEditingNameChange,
    onEditingActiveChange
  }) => {
    return (
      <View style={styles.dishItem}>
        {isEditing ? (
          <View style={styles.editForm}>
            <TextInput
              ref={editInputRef}
              style={styles.editInput}
              value={editingName}
              onChangeText={onEditingNameChange}
              onSubmitEditing={onEditSave}
              placeholder="Enter dish name..."
              returnKeyType="done"
            />
            <View style={styles.toggleContainer}>
              <Text style={styles.toggleLabel}>Active:</Text>
              <Switch
                value={editingActive}
                onValueChange={onEditingActiveChange}
                trackColor={{ false: '#767577', true: '#81b0ff' }}
                thumbColor={editingActive ? '#2c95f8' : '#f4f3f4'}
              />
            </View>
            <View style={styles.editButtons}>
              <TouchableOpacity 
                style={[styles.actionButton, styles.saveButton]} 
                onPress={onEditSave}
                activeOpacity={0.7}
              >
                <Save size={18} color="#fff" />
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.actionButton, styles.cancelButton]} 
                onPress={onEditCancel}
                activeOpacity={0.7}
              >
                <X size={18} color="#fff" />
              </TouchableOpacity>
            </View>
          </View>
        ) : (
          <View style={styles.dishRow}>
            <View style={styles.dishInfo}>
              <Text style={[
                styles.dishName,
                !item.isActive && styles.inactiveDish
              ]}>
                {item.name}
              </Text>
              <View style={styles.dishStatus}>
                <View style={[
                  styles.statusIndicator,
                  !item.isActive && styles.statusIndicatorInactive
                ]} />
                <Text style={styles.statusText}>
                  {item.isActive ? 'Active' : 'Inactive'}
                </Text>
              </View>
            </View>
            <View style={styles.dishActions}>
              <TouchableOpacity 
                style={[styles.actionButton, styles.editButton]}
                onPress={() => onEditStart(item)}
                activeOpacity={0.7}
              >
                <Edit2 size={18} color="#3B82F6" />
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.actionButton, styles.deleteButton]}
                onPress={() => onDelete(item._id)}
                activeOpacity={0.7}
              >
                <Trash2 size={18} color="#EF4444" />
              </TouchableOpacity>
            </View>
          </View>
        )}
      </View>
    );
  };

  const CategorySection: React.FC<{ 
    category: DishCategory; 
    dishes: Dish[];
    isExpanded: boolean;
    onToggle: () => void;
  }> = ({ category, dishes, isExpanded, onToggle }) => {
    return (
      <View style={styles.categoryCard}>
        <TouchableOpacity 
          style={styles.categoryHeader} 
          onPress={onToggle}
          activeOpacity={0.8}
        >
          <View style={styles.categoryInfo}>
            <Text style={styles.categoryEmoji}>{category.emoji}</Text>
            <View style={styles.categoryDetails}>
              <Text style={styles.categoryTitle}>{category.name}</Text>
              <Text style={styles.categoryCount}>
                {getActiveCategoryCount(category.id)} active, {dishes.length} total
              </Text>
            </View>
          </View>
          <View style={styles.categoryActions}>
            <TouchableOpacity 
              style={styles.addDishButton}
              onPress={(e) => {
                e.stopPropagation();
                setShowAddForm(showAddForm === category.id ? null : category.id);
                setEditingDish(null);
                
                // Focus on the input after a small delay to ensure it's rendered
                setTimeout(() => {
                  if (addInputRef.current) {
                    addInputRef.current.focus();
                  }
                }, 100);
              }}
              activeOpacity={0.7}
            >
              <Plus size={18} color="#fff" />
            </TouchableOpacity>
            {isExpanded ? (
              <ChevronUp size={20} color="#64748B" />
            ) : (
              <ChevronDown size={20} color="#64748B" />
            )}
          </View>
        </TouchableOpacity>
        
        {isExpanded && (
          <View style={styles.dishesList}>
            {showAddForm === category.id && (
              <View style={styles.addForm}>
                <TextInput
                  ref={addInputRef}
                  style={styles.addInput}
                  placeholder="Enter dish name..."
                  value={newDishName}
                  onChangeText={setNewDishName}
                  onSubmitEditing={() => handleAddDish(category.id)}
                  returnKeyType="done"
                />
                <View style={styles.toggleContainer}>
                  <Text style={styles.toggleLabel}>Active:</Text>
                  <Switch
                    value={newDishActive}
                    onValueChange={setNewDishActive}
                    trackColor={{ false: '#767577', true: '#81b0ff' }}
                    thumbColor={newDishActive ? '#2c95f8' : '#f4f3f4'}
                  />
                </View>
                <View style={styles.addFormButtons}>
                  <TouchableOpacity 
                    style={[styles.actionButton, styles.saveButton]} 
                    onPress={() => handleAddDish(category.id)}
                    activeOpacity={0.7}
                  >
                    <Save size={18} color="#fff" />
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={[styles.actionButton, styles.cancelButton]} 
                    onPress={() => handleCancelAdd(category.id)}
                    activeOpacity={0.7}
                  >
                    <X size={18} color="#fff" />
                  </TouchableOpacity>
                </View>
              </View>
            )}
            
            {dishes.map((dish) => (
              <DishItem
                key={dish._id}
                item={dish}
                isEditing={editingDish === dish._id}
                editingName={editingName}
                editingActive={editingActive}
                onEditStart={handleEditStart}
                onEditSave={handleEditSave}
                onEditCancel={handleEditCancel}
                onDelete={handleDeleteDish}
                onEditingNameChange={setEditingName}
                onEditingActiveChange={setEditingActive}
              />
            ))}
            
            {dishes.length === 0 && showAddForm !== category.id && (
              <View style={styles.emptyCategory}>
                <Text style={styles.emptyCategoryText}>No dishes in this category</Text>
              </View>
            )}
          </View>
        )}
      </View>
    );
  };

  if (loading && dishes.length === 0) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2c95f8" />
      </View>
    );
  }

  const handleNavigation = (screenName: string) => {
    setActiveNav(screenName);
    switch(screenName) {
      case 'Home':
        router.push('/dashboard');
        break;
      case 'Menu':
        router.push('./menu')
        break;
      case 'Response':
        router.push('./response')
        break;
      case 'Profile':
        router.push('./profile')
        break;
      default:
        router.push('/dashboard');
    }
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <Header
        title="Dish Master"
        subtitle="Manage your weekly dishes" 
        backgroundColor="#2c95f8"
        onBackPress={() => router.back()}
        onUserPress={() => router.push('/profile')}
      />

      {/* Main Content */}
      <KeyboardAwareScrollView
        style={styles.mainContent}
        contentContainerStyle={styles.scrollContainer}
        enableOnAndroid={true}
        extraScrollHeight={100}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.categoriesContainer}>
          {categories.map((category) => (
            <CategorySection
              key={category.id}
              category={category}
              dishes={dishes.filter(dish => dish.category === category.id)}
              isExpanded={expandedCategory === category.id}
              onToggle={() => toggleCategoryExpand(category.id)}
            />
          ))}
        </View>
      </KeyboardAwareScrollView>

      {/* Bottom Navigation Bar */}
      <BottomNavBar 
        activeNav={activeNav} 
        setActiveNav={handleNavigation}
        navbarOpacity={navbarOpacity}
        insets={insets}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5ff',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F8FAFC',
  },
  mainContent: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  scrollContainer: {
    paddingHorizontal: 24,
    paddingBottom: 100,
  },
  categoriesContainer: {
    marginTop: 20,
  },
  categoryCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: 20,
    marginBottom: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
    shadowColor: '#fbf5f5ff',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  categoryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
  },
  categoryInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  categoryEmoji: {
    fontSize: 28,
    marginRight: 15,
  },
  categoryDetails: {
    flex: 1,
  },
  categoryTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1E293B',
    marginBottom: 6,
  },
  categoryCount: {
    fontSize: 13,
    color: '#64748B',
    fontWeight: '500',
  },
  categoryActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  addDishButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#10B981',
    alignItems: 'center',
    justifyContent: 'center',
  },
  dishesList: {
    borderTopWidth: 1,
    borderTopColor: 'rgba(0, 0, 0, 0.06)',
  },
  dishItem: {
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0, 0, 0, 0.04)',
  },
  dishRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  dishInfo: {
    flex: 1,
  },
  dishName: {
    fontSize: 16,
    fontWeight: '500',
    color: '#1E293B',
    marginBottom: 6,
  },
  inactiveDish: {
    color: '#94A3B8',
  },
  dishStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statusIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
  },
  statusIndicatorInactive: {
    backgroundColor: '#EF4444',
  },
  statusText: {
    fontSize: 12,
    color: '#64748B',
  },
  dishActions: {
    flexDirection: 'row',
    gap: 8,
  },
  actionButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  editButton: {
    backgroundColor: '#EFF6FF',
  },
  deleteButton: {
    backgroundColor: '#FEF2F2',
  },
  saveButton: {
    backgroundColor: '#10B981',
  },
  cancelButton: {
    backgroundColor: '#64748B',
  },
  editForm: {
    padding: 16,
    backgroundColor: 'rgba(239, 246, 255, 0.5)',
  },
  editInput: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    marginBottom: 12,
    color: '#1E293B',
  },
  toggleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  toggleLabel: {
    marginRight: 10,
    color: '#1E293B',
    fontWeight: '500',
  },
  editButtons: {
    flexDirection: 'row',
    gap: 8,
    justifyContent: 'flex-end',
  },
  addForm: {
    padding: 16,
    backgroundColor: 'rgba(240, 253, 244, 0.8)',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0, 0, 0, 0.04)',
  },
  addInput: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#D1FAE5',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    marginBottom: 12,
    color: '#1E293B',
  },
  addFormButtons: {
    flexDirection: 'row',
    gap: 8,
    justifyContent: 'flex-end',
  },
  emptyCategory: {
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyCategoryText: {
    color: '#94A3B8',
    fontSize: 14,
  },
});

export default DishMasterScreen;