import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  TextInput,
  Alert,
  Image,
  ActivityIndicator,
  Animated,
  Dimensions,
  KeyboardAvoidingView,
  Platform,
  ScrollView
} from 'react-native';
import { useRouter } from 'expo-router';
import { MaterialIcons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import axios from 'axios';
import { LinearGradient } from 'expo-linear-gradient';
import { useAppSelector } from '@/app/store/hooks';

const { height } = Dimensions.get('window');

// Floating Input Component (unchanged)
const FloatingInput = ({
  label,
  value,
  onChangeText,
  keyboardType = 'default',
  autoCapitalize = 'sentences',
  inputRef,
  multiline = false,
  iconName,
  onSubmitEditing,
  returnKeyType = 'next'
}: {
  label: string;
  value: string;
  onChangeText: (text: string) => void;
  keyboardType?: any;
  autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
  inputRef?: React.RefObject<TextInput>;
  multiline?: boolean;
  iconName?: string;
  onSubmitEditing?: () => void;
  returnKeyType?: 'next' | 'done';
}) => {
  const [isFocused, setIsFocused] = useState(false);
  const animatedValue = useRef(new Animated.Value(value ? 1 : 0)).current;

  useEffect(() => {
    Animated.timing(animatedValue, {
      toValue: (isFocused || value) ? 1 : 0,
      duration: 200,
      useNativeDriver: false,
    }).start();
  }, [animatedValue, isFocused, value]);

  const labelStyle = {
    position: 'absolute',
    left: 20,
    top: animatedValue.interpolate({
      inputRange: [0, 1],
      outputRange: [20, -10],
    }),
    fontSize: animatedValue.interpolate({
      inputRange: [0, 1],
      outputRange: [16, 13],
    }),
    color: animatedValue.interpolate({
      inputRange: [0, 1],
      outputRange: ['#9CA3AF', '#32C0DA'],
    }),
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 4,
    fontWeight: '500',
    zIndex: 1,
  } as any;

  const containerStyle = {
    borderColor: animatedValue.interpolate({
      inputRange: [0, 1],
      outputRange: ['#E5E7EB', '#32C0DA'],
    }),
  } as any;

  return (
    <View style={styles.floatingInputContainer}>
      <Animated.View style={[styles.floatingInputWrapper, containerStyle]}>
        <Animated.Text style={labelStyle}>
          {label}
        </Animated.Text>
        <TextInput
          ref={inputRef}
          style={[
            styles.floatingInput,
            multiline && styles.multilineInput,
            iconName && styles.floatingInputWithIcon,
          ]}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          onChangeText={onChangeText}
          value={value}
          keyboardType={keyboardType}
          autoCapitalize={autoCapitalize}
          placeholderTextColor="#9CA3AF"
          onSubmitEditing={onSubmitEditing}
          returnKeyType={returnKeyType}
          blurOnSubmit={false}
          multiline={multiline}
          numberOfLines={multiline ? 3 : 1}
          textAlignVertical={multiline ? 'top' : 'center'}
        />
        {iconName && (
          <MaterialIcons
            name={iconName}
            size={20}
            color="#9CA3AF"
            style={styles.floatingInputIcon}
          />
        )}
      </Animated.View>
    </View>
  );
};

const EditProfileScreen = () => {
  const router = useRouter();
  const reduxProvider = useAppSelector((state) => state.provider);

  const [loading, setLoading] = useState(false);
  const [image, setImage] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
  });

  // Input refs
  const nameRef = useRef<TextInput>(null);
  const emailRef = useRef<TextInput>(null);
  const phoneRef = useRef<TextInput>(null);
  const addressRef = useRef<TextInput>(null);

  useEffect(() => {
    if (reduxProvider) {
      const newFormData = {
        name: reduxProvider.name || '',
        email: reduxProvider.email || '',
        phone: reduxProvider.phone || '',
        address: reduxProvider.address || '',
      };

      setFormData(newFormData);

      if (reduxProvider.profileImage) {
        setImage(reduxProvider.profileImage);
      }
    }
  }, [reduxProvider]);

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });

    if (!result.canceled) {
      setImage(result.assets[0].uri);
    }
  };

  const handleInputChange = (field: keyof typeof formData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const focusNextField = (nextRef: React.RefObject<TextInput>) => {
    setTimeout(() => {
      nextRef.current?.focus();
    }, 50);
  };

  const handleSaveProfile = async () => {
    if (loading) return;

    setLoading(true);
    try {
      const response = await axios.put(
        `http://192.168.1.178:5000/api/providers/${reduxProvider.id}`,
        formData,
        { withCredentials: true }
      );

      if (response.data.success) {
        Alert.alert('Success', 'Profile updated successfully!');
        router.back();
      } else {
        throw new Error(response.data.error || 'Failed to update profile');
      }
    } catch (error) {
      console.error('Update error:', error);
      Alert.alert('Error', 'Failed to update profile. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const getInitials = () => {
    if (!formData.name) return 'PK';
    return formData.name.charAt(0).toUpperCase();
  };

  const renderAvatar = () => {
    if (image) {
      return <Image source={{ uri: image }} style={styles.avatarImage} />;
    }
    return (
      <View style={styles.avatarPlaceholder}>
        <Text style={styles.avatarText}>
          {getInitials()}
        </Text>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#007AFF" />

      <KeyboardAvoidingView
        style={styles.keyboardAvoid}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 0}
      >
        {/* Scrollable Content - Only form content scrolls */}
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Profile Photo Section */}
          <View style={styles.profilePhotoSection}>
            <TouchableOpacity
              style={styles.profilePhoto}
              activeOpacity={0.8}
            >
              {renderAvatar()}
            </TouchableOpacity>
            {/* <TouchableOpacity
              onPress={pickImage}
              style={styles.changePhotoButton}
              activeOpacity={0.7}
            >
              <Text style={styles.changePhotoText}>Change Photo</Text>
            </TouchableOpacity> */}
          </View>

          {/* Form Section */}
          <View style={styles.formSection}>
            <FloatingInput
              label="Business/Provider name"
              value={formData.name}
              onChangeText={(text) => handleInputChange('name', text)}
              autoCapitalize="words"
              inputRef={nameRef}
              onSubmitEditing={() => focusNextField(emailRef)}
              returnKeyType="next"
              iconName="store"
            />

            <FloatingInput
              label="Contact email"
              value={formData.email}
              onChangeText={(text) => handleInputChange('email', text)}
              keyboardType="email-address"
              autoCapitalize="none"
              inputRef={emailRef}
              onSubmitEditing={() => focusNextField(phoneRef)}
              returnKeyType="next"
              iconName="email"
            />

            <FloatingInput
              label="Contact number"
              value={formData.phone}
              onChangeText={(text) => handleInputChange('phone', text)}
              keyboardType="phone-pad"
              maxLength={10}
              inputRef={phoneRef}
              onSubmitEditing={() => focusNextField(addressRef)}
              returnKeyType="next"
              iconName="phone"
            />

            <FloatingInput
              label="Kitchen address"
              value={formData.address}
              onChangeText={(text) => handleInputChange('address', text)}
              multiline={true}
              inputRef={addressRef}
              onSubmitEditing={handleSaveProfile}
              returnKeyType="done"
              iconName="location-on"
            />
          </View>
        </ScrollView>

        {/* Fixed Save Button - Always stays at bottom */}
        <View style={styles.bottomContainer}>
          <TouchableOpacity
            style={[styles.submitButton, loading && styles.submitButtonDisabled]}
            onPress={handleSaveProfile}
            activeOpacity={0.9}
            disabled={loading}
          >
            <LinearGradient
              colors={['#32C0DA', '#5695edff']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.submitGradient}
            >
              {loading ? (
                <ActivityIndicator color="#FFFFFF" />
              ) : (
                <Text style={styles.submitText}>Save Profile</Text>
              )}
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },
  keyboardAvoid: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    // Remove paddingBottom from here since button is fixed
  },
  profilePhotoSection: {
    alignItems: 'center',
    paddingTop: 30,
    paddingBottom: 20,
  },
  profilePhoto: {
    width: 100,
    height: 100,
    borderRadius: 50,
    overflow: 'hidden',
    marginBottom: 12,
  },
  avatarPlaceholder: {
    width: '100%',
    height: '100%',
    backgroundColor: '#32C0DA',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 50,
  },
  avatarText: {
    fontSize: 32,
    fontWeight: '600',
    color: '#fff',
  },
  avatarImage: {
    width: '100%',
    height: '100%',
    borderRadius: 50,
  },
  changePhotoButton: {
    paddingVertical: 6,
    paddingHorizontal: 16,
    backgroundColor: '#F3F4F6',
    borderRadius: 16,
  },
  changePhotoText: {
    color: '#32C0DA',
    fontSize: 14,
    fontWeight: '500',
  },
  formSection: {
    paddingHorizontal: 24,
    paddingBottom: 20,
  },
  // Floating Input Styles
  floatingInputContainer: {
    marginBottom: 16,
  },
  floatingInputWrapper: {
    borderWidth: 1.5,
    borderRadius: 16,
    backgroundColor: '#FFFFFF',
    position: 'relative',
    minHeight: 58,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  floatingInput: {
    fontSize: 16,
    color: '#1F2937',
    paddingHorizontal: 20,
    paddingVertical: 20,
    fontWeight: '400',
    minHeight: 58,
  },
  multilineInput: {
    minHeight: 80,
    paddingTop: 20,
    paddingBottom: 16,
  },
  floatingInputWithIcon: {
    paddingRight: 50,
  },
  floatingInputIcon: {
    position: 'absolute',
    right: 16,
    top: 19,
  },
  bottomContainer: {
    paddingHorizontal: 24,
    paddingTop: 16,
    paddingBottom: Platform.OS === "ios" ? 32 : 16,
    backgroundColor: "#FFFFFF",
    borderTopWidth: 1,
    borderTopColor: "#F3F4F6",
    // Remove any positioning that might cause it to move with keyboard
  },
  submitButton: {
    borderRadius: 25,
    overflow: "hidden",
    shadowColor: '#32C0DA',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  submitGradient: {
    paddingVertical: 16,
    borderRadius: 25,
    alignItems: "center",
    height: 52,
    justifyContent: 'center',
  },
  submitText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#FFFFFF",
  },
  submitButtonDisabled: {
    opacity: 0.6,
  },
});

export default EditProfileScreen;