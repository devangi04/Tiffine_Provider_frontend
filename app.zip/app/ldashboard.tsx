import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  ScrollView, 
  TouchableOpacity, 
  StyleSheet, 
  StatusBar,
  TextInput,
  Dimensions,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
  Keyboard,
  Animated,
  RefreshControl,
  ActivityIndicator,
  Alert
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons, Feather, MaterialIcons, FontAwesome5 } from '@expo/vector-icons';
import { useRouter, useNavigation, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import BottomNavBar from '../components/navbar'; 
import axios from 'axios';

const { width, height } = Dimensions.get('window');
const API_BASE_URL = 'http://192.168.1.178:5000'; // Use the same URL as in your login

// Define types for the provider data
interface ProviderData {
  _id: string;
  name: string;
  email: string;
  subscription?: {
    status: string;
  };
  // Add other fields you expect from the backend
}

interface MenuItem {
  type: string;
  dish: string;
}

interface Order {
  customerName: string;
  quantity: number;
  time: string;
  status: string;
}

interface DashboardData {
  todayOrders: number;
  yesResponses: number;
  noResponses: number;
  menu: MenuItem[];
  recentOrders: Order[];
}

const TiffinDashboard = () => {
  const [activeTab, setActiveTab] = useState('All');
  const [refreshing, setRefreshing] = useState(false);
  const [keyboardVisible, setKeyboardVisible] = useState(false);
  const [activeNav, setActiveNav] = useState('Home');
  const [loading, setLoading] = useState(true);
  const [providerData, setProviderData] = useState<ProviderData | null>(null);
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  
  const navbarOpacity = new Animated.Value(1);
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams();
  const providerId = params.providerId as string;
  const providerEmail = params.providerEmail as string;

  const navigation = useNavigation();
  
  useEffect(() => {
    navigation.setOptions({
      headerShown: false,
    });
  }, [navigation]);

  useEffect(() => {
    fetchProviderData();
  }, [providerId]);

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      () => {
        setKeyboardVisible(true);
        Animated.timing(navbarOpacity, {
          toValue: 0,
          duration: 300,
          useNativeDriver: true,
        }).start();
      }
    );
    const keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      () => {
        setKeyboardVisible(false);
        Animated.timing(navbarOpacity, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }).start();
      }
    );

    return () => {
      keyboardDidHideListener.remove();
      keyboardDidShowListener.remove();
    };
  }, []);

  const fetchProviderData = async () => {
    try {
      setLoading(true);
      
      // Fetch provider details
      const providerResponse = await axios.get(
        `${API_BASE_URL}/api/providers/${providerId}`,
        {
          timeout: 10000,
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }
        }
      );

      if (providerResponse.data.success) {
        setProviderData(providerResponse.data.data);
        
        // Fetch dashboard data
        const dashboardResponse = await axios.get(
          `${API_BASE_URL}/api/providers/${providerId}/dashboard`,
          {
            timeout: 10000,
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json'
            }
          }
        );

        if (dashboardResponse.data.success) {
          setDashboardData(dashboardResponse.data.data);
        } else {
          throw new Error(dashboardResponse.data.error || 'Failed to fetch dashboard data');
        }
      } else {
        throw new Error(providerResponse.data.error || 'Failed to fetch provider data');
      }
    } catch (error: any) {
      let errorMessage = 'Failed to fetch data. Please try again.';
      
      if (error.response) {
        errorMessage = error.response.data?.error || 
                      error.response.data?.message || 
                      `Server error (${error.response.status})`;
      } else if (error.code === 'ECONNABORTED') {
        errorMessage = 'Request timeout. Check your connection.';
      } else if (error.message.includes('Network Error')) {
        errorMessage = 'Cannot connect to server. Please check your connection.';
      }

      Alert.alert('Error', errorMessage);
      console.error('Fetch error:', error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    fetchProviderData().then(() => {
      setRefreshing(false);
    });
  };

  const handleNavigation = (screenName: string) => {
    setActiveNav(screenName);
    switch(screenName) {
      case 'Home':
        router.push({
        pathname: '/dashboard',
        params: { providerId, providerEmail }
      });
        break;
      case 'Menu':
        router.push({
          pathname: '/savedmenu',
          params: { providerId }
        });
        break;
      case 'Response':
        router.push({
          pathname: '/response',
          params: { providerId }
        });
        break;
      case 'Profile':
        router.push({
          pathname: '/schedule',
          params: { providerId }
        });
        break;
      default:
        router.push('/dashboard');
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0022ff" />
        <Text style={styles.loadingText}>Loading dashboard...</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container,]}>
      <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />
      
      <KeyboardAvoidingView 
        style={styles.keyboardAvoid}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        keyboardVerticalOffset={Platform.OS === "ios" ? 0 : 10}
      >
        {/* Header Section with Gradient */}
        <LinearGradient
          colors={['#2c95f8', '#0022ff']}
          style={[styles.headerSection]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        >
          {/* Decorative Circles */}
          <View style={[styles.circle, styles.circleTop]} />
          <View style={[styles.circle, styles.circleBottom]} />
          
          <View style={styles.headerContent}>
            <View>
              <Text style={styles.greeting}>Good morning</Text>
              <Text style={styles.userName}>{providerData?.name || 'User'}!</Text>
            </View>
            <TouchableOpacity 
              style={styles.profileIcon}
              onPress={() => handleNavigation('Profile')}
            >
              <Feather name="user" size={20} color="white" />
            </TouchableOpacity>
          </View>
          
          <View style={styles.searchBar}>
            <Ionicons name="search" size={16} color="#666" style={styles.searchIcon} />
            <TextInput
              style={styles.searchInput}
              placeholder="Search document or activity"
              placeholderTextColor="#888"
            />
          </View>
        </LinearGradient>

        {/* Main Content */}
        <ScrollView 
          style={styles.scrollView}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.scrollContent,
            keyboardVisible && { paddingBottom: 20 }
          ]}
          keyboardShouldPersistTaps="handled"
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              colors={['#2c95f8']}
              tintColor={'#2c95f8'}
            />
          }
        >
          {/* Hero Card */}
          <LinearGradient
            colors={['#2c95f8', '#0022ff']}
            style={styles.heroCard}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          >
            <View style={styles.heroContent}>
              <Text style={styles.heroTitle}>Today's Orders</Text>
              <Text style={styles.heroValue}>{dashboardData?.todayOrders || 0}</Text>
            </View>
            <Text style={styles.heroIcon}>🍱</Text>
          </LinearGradient>

          {/* Stats Section */}
          <View style={styles.section}>
            <Text style={styles.sectionDate}>{new Date().getDate()}</Text>
            <Text style={styles.sectionTitle}>
              {new Date().toLocaleString('en-US', { weekday: 'long', hour: 'numeric', hour12: true })}
            </Text>
            
            <View style={styles.statsGrid}>
              <View style={styles.statCard}>
                <View style={styles.statHeader}>
                  <View style={styles.statInfo}>
                    <Text style={styles.statInfoTitle}>Response</Text>
                    <Text style={styles.statInfoSubtitle}>Yes Count</Text>
                  </View>
                  <View style={[styles.statIcon, { backgroundColor: '#10b981' }]} />
                </View>
                <Text style={styles.statValue}>{dashboardData?.yesResponses || 0}</Text>
              </View>
              
              <View style={styles.statCard}>
                <View style={styles.statHeader}>
                  <View style={styles.statInfo}>
                    <Text style={styles.statInfoTitle}>Response</Text>
                    <Text style={styles.statInfoSubtitle}>No Count</Text>
                  </View>
                  <View style={[styles.statIcon, { backgroundColor: '#eb1b1b' }]} />
                </View>
                <Text style={styles.statValue}>{dashboardData?.noResponses || 0}</Text>
              </View>
            </View>
          </View>

          {/* Action Cards */}
          <View style={styles.actionsGrid}>
            <TouchableOpacity 
              style={styles.actionCard}
              onPress={() => handleNavigation('Menu')}
            >
              <View style={styles.actionHeader}>
                <View>
                  <Text style={styles.actionTitle}>Menu</Text>
                  <Text style={styles.actionSubtitle}>Create Today's</Text>
                </View>
                <View style={[styles.actionStatus, styles.statusActive]}>
                  <Text style={styles.actionStatusText}>Ready</Text>
                </View>
              </View>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.actionCard} onPress={() => handleNavigation('WhatsApp')}>
              <View style={styles.actionHeader}>
                <View>
                  <Text style={styles.actionTitle}>WhatsApp</Text>
                  <Text style={styles.actionSubtitle}>Send Broadcast</Text>
                </View>
                <View style={[styles.actionStatus, styles.statusActive]}>
                  {/* <Text style={styles.actionStatusText}>Processing</Text> */}
                </View>
              </View>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.actionCard}>
              <View style={styles.actionHeader}>
                <View>
                  <Text style={styles.actionTitle}>Customer</Text>
                  <Text style={styles.actionSubtitle}>View All</Text>
                </View>
                <View style={[styles.actionStatus, styles.statusActive]}>
                  <Text style={styles.actionStatusText}>{dashboardData?.todayOrders || 0} new</Text>
                </View>
              </View>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.actionCard}>
              <View style={styles.actionHeader}>
                <View>
                  <Text style={styles.actionTitle}>Payment</Text>
                  <Text style={styles.actionSubtitle}>View payments</Text>
                </View>
                <View style={[styles.actionStatus, styles.statusInactive]}>
                  <Text style={styles.actionStatusText}>Pending</Text>
                </View>
              </View>
            </TouchableOpacity>
          </View>

          {/* Today's Menu */}
          <View style={styles.menuCard}>
            <View style={styles.menuHeader}>
              <Text style={styles.menuTitle}>Today's Menu</Text>
              <Text style={styles.menuSubtitle}>
                {new Date().toLocaleString('en-US', { weekday: 'long' })} Special
              </Text>
            </View>
            {dashboardData?.menu && dashboardData.menu.length > 0 ? (
              dashboardData.menu.map((item, index) => (
                <View key={index} style={styles.menuItem}>
                  <Text style={styles.menuType}>{item.type}</Text>
                  <Text style={styles.menuDish}>{item.dish}</Text>
                </View>
              ))
            ) : (
              <Text style={styles.noMenuText}>No menu available for today</Text>
            )}
          </View>

          {/* Recent Orders */}
          <View style={styles.ordersCard}>
            <View style={styles.menuHeader}>
              <Text style={styles.menuTitle}>Recent Orders</Text>
              <Text style={styles.menuSubtitle}>Latest customer orders</Text>
            </View>
            {dashboardData?.recentOrders && dashboardData.recentOrders.length > 0 ? (
              dashboardData.recentOrders.map((order, index) => (
                <View key={index} style={styles.orderItem}>
                  <View style={styles.orderInfo}>
                    <Text style={styles.orderName}>{order.customerName}</Text>
                    <Text style={styles.orderDetails}>Qty: {order.quantity} • {order.time}</Text>
                  </View>
                  <View style={[
                    styles.orderStatus, 
                    order.status === 'Confirmed' ? styles.statusConfirmed : styles.statusPending
                  ]}>
                    <Text style={styles.orderStatusText}>{order.status}</Text>
                  </View>
                </View>
              ))
            ) : (
              <Text style={styles.noOrdersText}>No recent orders</Text>
            )}
          </View>
          
          {/* Extra padding at bottom for navigation */}
          <View style={{ height: 80 + insets.bottom }} />
        </ScrollView>
      </KeyboardAvoidingView>

      {/* Bottom Navigation - Adjusted for safe area */}
      <BottomNavBar 
        activeNav={activeNav} 
        setActiveNav={handleNavigation}
        navbarOpacity={navbarOpacity}
        insets={insets}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
  keyboardAvoid: {
    flex: 1,
  },
  headerSection: {
    padding: 20,
    paddingTop: 60,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    overflow: 'hidden',
    position: 'relative',
  },
  circle: {
    position: 'absolute',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 100,
  },
  circleTop: {
    top: -50,
    right: -50,
    width: 150,
    height: 150,
  },
  circleBottom: {
    bottom: -30,
    left: -30,
    width: 100,
    height: 100,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  greeting: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.9)',
    marginBottom: 4,
  },
  userName: {
    fontSize: 24,
    fontWeight: '600',
    color: 'white',
  },
  profileIcon: {
    width: 40,
    height: 40,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 30,
    paddingHorizontal: 16,
    height: 48,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: '#333',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 15,
  },
  heroCard: {
    borderRadius: 24,
    padding: 20,
    marginTop: 20,
    marginBottom: 24,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 5,
  },
  heroContent: {
    flex: 1,
  },
  heroTitle: {
    color: 'rgba(255, 255, 255, 0.8)',
    fontSize: 14,
    marginBottom: 8,
  },
  heroValue: {
    color: 'white',
    fontSize: 36,
    fontWeight: '700',
  },
  heroIcon: {
    fontSize: 48,
  },
  section: {
    marginBottom: 24,
  },
  sectionDate: {
    color: 'black',
    fontSize: 12,
    marginBottom: 4,
  },
  sectionTitle: {
    color: 'black',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 16,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 20,
    elevation: 3,
  },
  statHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  statInfo: {
    flex: 1,
  },
  statInfoTitle: {
    fontSize: 14,
    color: '#333',
    fontWeight: '600',
    marginBottom: 4,
  },
  statInfoSubtitle: {
    fontSize: 12,
    color: '#666',
  },
  statIcon: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  statValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#333',
  },
  actionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 24,
    gap: 16,
  },
  actionCard: {
    flex: 1,
    minWidth: '47%',
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 20,
    elevation: 3,
  },
  actionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  actionTitle: {
    fontSize: 14,
    color: '#333',
    fontWeight: '600',
    marginBottom: 4,
  },
  actionSubtitle: {
    fontSize: 12,
    color: '#666',
  },
  actionStatus: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  statusActive: {
    backgroundColor: '#dcfce7',
  },
  statusInactive: {
    backgroundColor: '#fef3c7',
  },
  actionStatusText: {
    fontSize: 11,
    fontWeight: '500',
  },
  menuCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: 20,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 20,
    elevation: 3,
  },
  menuHeader: {
    marginBottom: 16,
  },
  menuTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  menuSubtitle: {
    fontSize: 12,
    color: '#666',
  },
  menuItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0, 0, 0, 0.05)',
  },
  menuType: {
    fontWeight: '600',
    color: '#3b82f6',
    fontSize: 13,
    minWidth: 60,
  },
  menuDish: {
    color: '#333',
    fontSize: 14,
    flex: 1,
    textAlign: 'right',
  },
  noMenuText: {
    textAlign: 'center',
    color: '#666',
    padding: 20,
    fontStyle: 'italic',
  },
  ordersCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: 20,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 20,
    elevation: 3,
  },
  orderItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0, 0, 0, 0.05)',
  },
  orderInfo: {
    flex: 1,
  },
  orderName: {
    fontWeight: '600',
    color: '#333',
    fontSize: 14,
    marginBottom: 4,
  },
  orderDetails: {
    fontSize: 12,
    color: '#666',
  },
  orderStatus: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  statusConfirmed: {
    backgroundColor: '#dcfce7',
  },
  statusPending: {
    backgroundColor: '#fef3c7',
  },
  orderStatusText: {
    fontSize: 11,
    fontWeight: '500',
  },
  noOrdersText: {
    textAlign: 'center',
    color: '#666',
    padding: 20,
    fontStyle: 'italic',
  },
});

export default TiffinDashboard;