import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  RefreshControl,
  TextInput,
  Modal,
} from 'react-native';
import { useLocalSearchParams, useRouter, useNavigation } from 'expo-router';
import { ChevronLeft, Download, ArrowLeft, ArrowRight, DollarSign, CheckCircle, XCircle, Clock, Calendar, Info } from 'lucide-react-native';
import axios from 'axios';
import moment from 'moment';

const API_BASE_URL = 'http://192.168.1.178:5000/api';

// ... your existing interfaces remain the same ...

interface Customer {
  id: string;
  name: string;
  phone: string;
}

interface Payment {
  amount: number;
  paidOn: string | Date;
  method: 'cash' | 'upi' | 'other';
}

interface Bill {
  id?: string;
  _id?: string;
  customer: Customer;
  period: {
    start: string;
    end: string;
    month: string;
    year: string;
  };
  stats: {
    totalDays: number;
    yesCount: number;
    noCount: number;
    pendingCount: number;
  };
  billing: {
    ratePerTiffin: number;
    totalAmount: number;
  };
  payments: Payment[];
  paidAmount: number;
  remainingAmount: number;
  isFullyPaid: boolean;
}

interface ApiErrorResponse {
  message?: string;
  success?: boolean;
  data?: any;
}

// Helper function to safely get nested values
const getSafeValue = (obj: any, path: string, defaultValue: any = 0) => {
  if (!obj) return defaultValue;
  return path.split('.').reduce((acc, part) => acc && acc[part], obj) || defaultValue;
};

const BillScreen = () => {
  const params = useLocalSearchParams();
  const { customerId } = params;
  const router = useRouter();
  
  const [bill, setBill] = useState<Bill | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [currentMonth, setCurrentMonth] = useState(moment().month() + 1);
  const [currentYear, setCurrentYear] = useState(moment().year());
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'upi' | 'other'>('upi');
  const [paymentAmount, setPaymentAmount] = useState('');
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [billNotFound, setBillNotFound] = useState(false);

  const navigation = useNavigation();
   
  useEffect(() => {
    navigation.setOptions({
      headerShown: false,
    });
  }, [navigation]);

  // Add proper type checking
  if (!customerId) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>Customer ID is required</Text>
        <TouchableOpacity
          style={styles.retryButton}
          onPress={() => router.back()}
        >
          <Text style={styles.retryButtonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

const fetchBill = async () => {
  try {
    setLoading(true);
    setError(null);
    setBillNotFound(false);
    
    const response = await axios.get(
      `${API_BASE_URL}/bills/customers/${customerId}/bills/${currentYear}/${currentMonth}`
    );

    if (response.data.success) {
      const billData = response.data.data;
      
      // ✅ Safe bill shaping with fallbacks
      const safeBillData: Bill = {
        id: billData.id || billData._id || `${customerId}-${currentYear}-${currentMonth}`,
        customer: billData.customer || { id: String(customerId), name: 'Unknown', phone: 'N/A' },
        period: billData.period || { 
          start: new Date(currentYear, currentMonth - 1, 1).toISOString(), 
          end: new Date(currentYear, currentMonth, 0).toISOString(),
          month: String(currentMonth),
          year: String(currentYear)
        },
        stats: billData.stats || { totalDays: 0, yesCount: 0, noCount: 0, pendingCount: 0 },
        billing: billData.billing || { ratePerTiffin: 0, totalAmount: 0 },
        payments: billData.payments || [],
        paidAmount: billData.paidAmount || 0,
        remainingAmount: billData.remainingAmount || (billData.billing?.totalAmount || 0),
        isFullyPaid: billData.isFullyPaid || false
      };
      
      setBill(safeBillData);
    } else {
      setError(response.data.message || 'Failed to fetch bill details');
    }
  } catch (err: any) {
    // 🚀 Only log unexpected errors
    if (err.response?.status === 404) {
      setBillNotFound(true);
      setError(`Bill not generated for ${moment().month(currentMonth - 1).format('MMMM YYYY')}`);
    } else {
      console.error('Error fetching bill:', err); // only log real errors
      setError(
        err.response?.data?.message || 
        err.message || 
        'Network error. Please try again.'
      );
    }
  } finally {
    setLoading(false);
    setRefreshing(false);
  }
};

  useEffect(() => {
    fetchBill();
  }, [currentMonth, currentYear]);

  const handleMonthChange = (direction: 'prev' | 'next') => {
    if (direction === 'prev') {
      if (currentMonth === 1) {
        setCurrentMonth(12);
        setCurrentYear(currentYear - 1);
      } else {
        setCurrentMonth(currentMonth - 1);
      }
    } else {
      if (currentMonth === 12) {
        setCurrentMonth(1);
        setCurrentYear(currentYear + 1);
      } else {
        setCurrentMonth(currentMonth + 1);
      }
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    fetchBill();
  };

  const downloadBill = async () => {
    Alert.alert('Download', 'Bill download functionality would be implemented here');
  };

  const handlePayment = async () => {
    if (!bill) {
      Alert.alert('Error', 'No bill data available');
      return;
    }

    try {
      const amount = parseFloat(paymentAmount) || bill.remainingAmount;
      
      const customerId = bill.customer.id;
      const year = bill.period.year;
      const month = bill.period.month;

      const response = await axios.post(
        `${API_BASE_URL}/bills/customers/${customerId}/bills/${year}/${month}/payments`,
        {
          amount,
          method: paymentMethod
        }
      );
      
      if (response.data.success) {
        const updatedBillData = response.data.data;
        
        const safeBillData: Bill = {
          id: updatedBillData.id || bill.id,
          customer: updatedBillData.customer || bill.customer,
          period: updatedBillData.period || bill.period,
          stats: updatedBillData.stats || bill.stats,
          billing: updatedBillData.billing || bill.billing,
          payments: updatedBillData.payments || bill.payments,
          paidAmount: updatedBillData.paidAmount || bill.paidAmount,
          remainingAmount: updatedBillData.remainingAmount || bill.remainingAmount,
          isFullyPaid: updatedBillData.isFullyPaid || bill.isFullyPaid
        };
        
        setBill(safeBillData);
        setShowPaymentModal(false);
        setPaymentAmount('');
        Alert.alert('Success', 'Payment recorded successfully');
      } else {
        throw new Error(response.data.message || 'Payment failed');
      }
    } catch (err: any) {
      console.error('Payment error:', err);
      Alert.alert(
        'Payment Error',
        err.message || 'Failed to record payment'
      );
    }
  };

  // Check if current month is in the future or bill not generated yet
  const isCurrentMonth = currentMonth === moment().month() + 1 && currentYear === moment().year();
  const isFutureMonth = moment(`${currentYear}-${currentMonth}`, 'YYYY-M').isAfter(moment(), 'month');

  // Render Bill Not Generated View
  const renderBillNotGenerated = () => {
    return (
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <ChevronLeft size={24} color="#1E293B" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Monthly Bill</Text>
          <View style={{ width: 24 }} />
        </View>

        {/* Month Selector */}
        <View style={styles.monthSelector}>
          <TouchableOpacity onPress={() => handleMonthChange('prev')}>
            <ArrowLeft size={24} color="#4F46E5" />
          </TouchableOpacity>
          
          <Text style={styles.monthText}>
            {moment().month(currentMonth - 1).format('MMMM YYYY')}
          </Text>
          
          <TouchableOpacity 
            onPress={() => handleMonthChange('next')}
            disabled={isCurrentMonth}
          >
            <ArrowRight 
              size={24} 
              color={isCurrentMonth ? '#CBD5E1' : '#4F46E5'} 
            />
          </TouchableOpacity>
        </View>

        {/* Bill Not Generated Card */}
        <View style={styles.emptyCard}>
          <Info size={48} color="#94A3B8" />
          <Text style={styles.emptyTitle}>Bill Not Generated Yet</Text>
          <Text style={styles.emptyText}>
            {isFutureMonth 
              ? "This is a future month. Bill will be generated at the end of the month."
              : "Bill for this month is not generated yet. Bills are typically generated on the last day of the month."
            }
          </Text>
          
          <View style={styles.infoCard}>
            <Text style={styles.infoTitle}>Bill Generation Schedule</Text>
            <Text style={styles.infoText}>• Bills are generated on the last day of each month</Text>
            <Text style={styles.infoText}>• You can view previous month's bills</Text>
            <Text style={styles.infoText}>• Payments can be made after bill generation</Text>
          </View>

          <TouchableOpacity 
            style={styles.viewPreviousButton}
            onPress={() => handleMonthChange('prev')}
          >
            <ArrowLeft size={18} color="#4F46E5" />
            <Text style={styles.viewPreviousButtonText}>View Previous Month Bill</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  // Render Payment Card (only when bill exists)
  const renderPaymentCard = () => {
    if (!bill || !bill.payments) return null;

    const payments = bill.payments || [];
    const lastPaymentDate = payments.length > 0 
      ? moment(payments[payments.length - 1].paidOn).format('MMM D, YYYY')
      : 'N/A';

    return (
      <View style={styles.paymentCard}>
        <Text style={styles.cardTitle}>Payment Status</Text>
        
        {bill.isFullyPaid ? (
          <View style={styles.paymentStatus}>
            <View style={[styles.statusBadge, styles.paidBadge]}>
              <Text style={[styles.statusText, styles.paidStatusText]}>Paid</Text>
            </View>
            <Text style={styles.dueDateText}>
              Paid on {lastPaymentDate}
            </Text>
          </View>
        ) : (
          <>
            <View style={styles.paymentStatus}>
              <View style={[styles.statusBadge, payments.length > 0 ? styles.partialBadge : styles.unpaidBadge]}>
                <Text style={[styles.statusText, payments.length > 0 ? styles.partialStatusText : styles.unpaidStatusText]}>
                  {payments.length > 0 ? 'Partial' : 'Unpaid'}
                </Text>
              </View>
              <Text style={styles.dueDateText}>
                Due by {moment(bill.period?.end).add(7, 'days').format('MMM D, YYYY')}
              </Text>
            </View>
            
            <View style={styles.paymentProgress}>
              <Text style={styles.paymentText}>
                Paid: ₹{(getSafeValue(bill, 'paidAmount', 0)).toFixed(2)} of ₹{(getSafeValue(bill, 'billing.totalAmount', 0)).toFixed(2)}
              </Text>
              <Text style={styles.paymentText}>
                Remaining: ₹{(getSafeValue(bill, 'remainingAmount', 0)).toFixed(2)}
              </Text>
            </View>
            
            <TouchableOpacity 
              style={styles.payButton}
              onPress={() => setShowPaymentModal(true)}
            >
              <DollarSign size={18} color="#fff" />
              <Text style={styles.payButtonText}>
                {payments.length > 0 ? 'Add Payment' : 'Mark as Paid'}
              </Text>
            </TouchableOpacity>
          </>
        )}
      </View>
    );
  };

  // Show loading
  if (loading && !bill) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#4F46E5" />
        <Text style={styles.loadingText}>Loading bill details...</Text>
      </View>
    );
  }

  // Show bill not generated view
  if (billNotFound) {
    return renderBillNotGenerated();
  }

  // Show other errors
  if (error && !billNotFound) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>{error}</Text>
        <TouchableOpacity
          style={styles.retryButton}
          onPress={fetchBill}
        >
          <Text style={styles.retryButtonText}>Retry</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // Show no bill data
  if (!bill) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>No bill data available</Text>
        <TouchableOpacity
          style={styles.retryButton}
          onPress={fetchBill}
        >
          <Text style={styles.retryButtonText}>Retry</Text>
        </TouchableOpacity>
      </View>
    );
  }

  // Render normal bill view when bill exists
  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ChevronLeft size={24} color="#1E293B" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Monthly Bill</Text>
        <TouchableOpacity onPress={downloadBill}>
          <Download size={24} color="#4F46E5" />
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={styles.contentContainer}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Month Selector */}
        <View style={styles.monthSelector}>
          <TouchableOpacity onPress={() => handleMonthChange('prev')}>
            <ArrowLeft size={24} color="#4F46E5" />
          </TouchableOpacity>
          
          <Text style={styles.monthText}>
            {moment().month(currentMonth - 1).format('MMMM YYYY')}
          </Text>
          
          <TouchableOpacity 
            onPress={() => handleMonthChange('next')}
            disabled={isCurrentMonth}
          >
            <ArrowRight 
              size={24} 
              color={isCurrentMonth ? '#CBD5E1' : '#4F46E5'} 
            />
          </TouchableOpacity>
        </View>

        {/* Customer Info */}
        <View style={styles.customerCard}>
          <Text style={styles.cardTitle}>Customer Details</Text>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Name:</Text>
            <Text style={styles.detailValue}>{getSafeValue(bill, 'customer.name', 'N/A')}</Text>
          </View>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Phone:</Text>
            <Text style={styles.detailValue}>{getSafeValue(bill, 'customer.phone', 'N/A')}</Text>
          </View>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Billing Period:</Text>
            <Text style={styles.detailValue}>
              {moment(bill.period?.start).format('MMM D')} - {moment(bill.period?.end).format('MMM D, YYYY')}
            </Text>
          </View>
        </View>

        {/* Rest of your existing bill rendering code... */}
        {/* Consumption Stats */}
        <View style={styles.statsCard}>
          <Text style={styles.cardTitle}>Meal Consumption</Text>
          
          <View style={styles.statRow}>
            <View style={styles.statItem}>
              <CheckCircle size={20} color="#10B981" />
              <Text style={[styles.statValue, styles.statYes]}>
                {getSafeValue(bill, 'stats.yesCount')}
              </Text>
              <Text style={styles.statLabel}>Days Consumed</Text>
            </View>
            
            <View style={styles.statItem}>
              <XCircle size={20} color="#EF4444" />
              <Text style={[styles.statValue, styles.statNo]}>
                {getSafeValue(bill, 'stats.noCount')}
              </Text>
              <Text style={styles.statLabel}>Days Skipped</Text>
            </View>
            
            <View style={styles.statItem}>
              <Clock size={20} color="#F59E0B" />
              <Text style={[styles.statValue, styles.statPending]}>
                {getSafeValue(bill, 'stats.pendingCount')}
              </Text>
              <Text style={styles.statLabel}>Pending</Text>
            </View>
          </View>
        </View>

        {/* Bill Summary */}
        <View style={styles.billCard}>
          <Text style={styles.cardTitle}>Bill Summary</Text>
          
          <View style={styles.billRow}>
            <Text style={styles.billLabel}>Rate per Tiffin:</Text>
            <Text style={styles.billValue}>
              ₹{(getSafeValue(bill, 'billing.ratePerTiffin', 0)).toFixed(2)}
            </Text>
          </View>
          
          <View style={styles.billRow}>
            <Text style={styles.billLabel}>Total Tiffins:</Text>
            <Text style={styles.billValue}>
              {getSafeValue(bill, 'stats.yesCount', 0)}
            </Text>
          </View>
          
          <View style={styles.divider} />
          
          <View style={[styles.billRow, styles.totalRow]}>
            <Text style={styles.totalLabel}>Total Amount:</Text>
            <Text style={styles.totalValue}>
              ₹{(getSafeValue(bill, 'billing.totalAmount', 0)).toFixed(2)}
            </Text>
          </View>
        </View>

        {/* Payment Status */}
        {renderPaymentCard()}

        {/* Payment History */}
        {bill.payments && bill.payments.length > 0 && (
          <View style={styles.paymentHistoryCard}>
            <Text style={styles.cardTitle}>Payment History</Text>
            {bill.payments.map((payment, index) => (
              <View key={index} style={styles.paymentItem}>
                <View style={styles.paymentInfo}>
                  <Text style={styles.paymentDate}>
                    {moment(payment.paidOn).format('MMM D, YYYY')}
                  </Text>
                  <Text style={styles.paymentMethod}>
                    {payment.method.toUpperCase()}
                  </Text>
                </View>
                <Text style={styles.paymentAmount}>
                  ₹{payment.amount.toFixed(2)}
                </Text>
              </View>
            ))}
          </View>
        )}
      </ScrollView>

      {/* Payment Modal */}
      <Modal
        visible={showPaymentModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowPaymentModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <Text style={styles.modalTitle}>Record Payment</Text>
            
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Amount (₹)</Text>
              <TextInput
                style={styles.input}
                keyboardType="numeric"
                value={paymentAmount}
                onChangeText={setPaymentAmount}
                placeholder={`${bill.remainingAmount?.toFixed(2) || '0.00'}`}
              />
            </View>
            
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Payment Method</Text>
              <View style={styles.methodButtons}>
                <TouchableOpacity
                  style={[
                    styles.methodButton,
                    paymentMethod === 'cash' && styles.methodButtonActive
                  ]}
                  onPress={() => setPaymentMethod('cash')}
                >
                  <Text style={[
                    styles.methodButtonText,
                    paymentMethod === 'cash' && styles.methodButtonTextActive
                  ]}>
                    Cash
                  </Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={[
                    styles.methodButton,
                    paymentMethod === 'upi' && styles.methodButtonActive
                  ]}
                  onPress={() => setPaymentMethod('upi')}
                >
                  <Text style={[
                    styles.methodButtonText,
                    paymentMethod === 'upi' && styles.methodButtonTextActive
                  ]}>
                    UPI
                  </Text>
                </TouchableOpacity>
                
                <TouchableOpacity
                  style={[
                    styles.methodButton,
                    paymentMethod === 'other' && styles.methodButtonActive
                  ]}
                  onPress={() => setPaymentMethod('other')}
                >
                  <Text style={[
                    styles.methodButtonText,
                    paymentMethod === 'other' && styles.methodButtonTextActive
                  ]}>
                    Other
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
            
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setShowPaymentModal(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[styles.modalButton, styles.confirmButton]}
                onPress={handlePayment}
              >
                <Text style={styles.confirmButtonText}>Confirm</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    paddingTop: 45,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  backButton: {
    padding: 4,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1E293B',
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 32,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#64748B',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    fontSize: 16,
    color: '#EF4444',
    marginBottom: 20,
    textAlign: 'center',
  },
  retryButton: {
    backgroundColor: '#4F46E5',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  retryButtonText: {
    color: '#fff',
    fontWeight: '600',
  },
  monthSelector: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
    paddingHorizontal: 8,
  },
  monthText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1E293B',
  },
  // Empty State Styles
  emptyCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 24,
    margin: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1E293B',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 16,
    color: '#64748B',
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 22,
  },
  infoCard: {
    backgroundColor: '#F8FAFC',
    padding: 16,
    borderRadius: 8,
    marginBottom: 24,
    width: '100%',
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1E293B',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    color: '#64748B',
    marginBottom: 4,
  },
  viewPreviousButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EEF2FF',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
  },
  viewPreviousButtonText: {
    color: '#4F46E5',
    fontWeight: '600',
    marginLeft: 8,
  },
  // ... rest of your existing styles remain the same ...
  customerCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statsCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  billCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  paymentCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  paymentHistoryCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1E293B',
    marginBottom: 16,
  },
  detailRow: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  detailLabel: {
    width: 120,
    fontSize: 14,
    color: '#64748B',
  },
  detailValue: {
    flex: 1,
    fontSize: 14,
    fontWeight: '500',
    color: '#1E293B',
  },
  statRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statItem: {
    alignItems: 'center',
    flex: 1,
  },
  statValue: {
    fontSize: 24,
    fontWeight: '600',
    marginVertical: 4,
  },
  statYes: {
    color: '#10B981',
  },
  statNo: {
    color: '#EF4444',
  },
  statPending: {
    color: '#F59E0B',
  },
  statLabel: {
    fontSize: 12,
    color: '#64748B',
    textAlign: 'center',
  },
  billRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  billLabel: {
    fontSize: 14,
    color: '#64748B',
  },
  billValue: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1E293B',
  },
  divider: {
    height: 1,
    backgroundColor: '#E2E8F0',
    marginVertical: 12,
  },
  totalRow: {
    marginTop: 8,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1E293B',
  },
  totalValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1E293B',
  },
  paymentStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    marginRight: 12,
  },
  unpaidBadge: {
    backgroundColor: '#FEE2E2',
  },
  partialBadge: {
    backgroundColor: '#FEF3C7',
  },
  paidBadge: {
    backgroundColor: '#D1FAE5',
  },
  statusText: {
    fontSize: 14,
    fontWeight: '500',
  },
  unpaidStatusText: {
    color: '#B91C1C',
  },
  partialStatusText: {
    color: '#92400E',
  },
  paidStatusText: {
    color: '#065F46',
  },
  dueDateText: {
    fontSize: 14,
    color: '#64748B',
  },
  paymentProgress: {
    marginVertical: 12,
  },
  paymentText: {
    fontSize: 14,
    color: '#64748B',
    marginBottom: 4,
  },
  payButton: {
    flexDirection: 'row',
    backgroundColor: '#4F46E5',
    padding: 12,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 8,
  },
  payButtonText: {
    color: '#fff',
    fontWeight: '600',
    marginLeft: 8,
  },
  paymentItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  paymentInfo: {
    flex: 1,
  },
  paymentDate: {
    fontSize: 14,
    color: '#64748B',
  },
  paymentMethod: {
    fontSize: 12,
    color: '#94A3B8',
  },
  paymentAmount: {
    fontSize: 16,
    fontWeight: '600',
    color: '#10B981',
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 20,
    width: '90%',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 20,
    color: '#1E293B',
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 14,
    color: '#64748B',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 8,
    padding: 12,
    fontSize: 16
  },
  methodButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  methodButton: {
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 8,
    padding: 12,
    flex: 1,
    marginHorizontal: 4,
  },
  methodButtonActive: {
    borderColor: '#4F46E5',
    backgroundColor: '#EEF2FF',
  },
  methodButtonText: {
    textAlign: 'center',
    color: '#64748B',
  },
  methodButtonTextActive: {
    color: '#4F46E5',
    fontWeight: '600',
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
  },
  modalButton: {
    flex: 1,
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  cancelButton: {
    backgroundColor: '#F1F5F9',
    marginRight: 8,
  },
  confirmButton: {
    backgroundColor: '#4F46E5',
    marginLeft: 8,
  },
  cancelButtonText: {
    color: '#64748B',
    fontWeight: '600',
  },
  confirmButtonText: {
    color: '#fff',
    fontWeight: '600',
  },
});

export default BillScreen;