import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Switch,
  ActivityIndicator
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import DateTimePicker from '@react-native-community/datetimepicker';
import { useNavigation } from '@react-navigation/native';

const MealPreferencesScreen = ({ route }) => {
  const { providerId } = route.params;
  const navigation = useNavigation();
  
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [preferences, setPreferences] = useState({
    serves: 'lunch',
    lunch: {
      serves: 'full',
      timing: {
        startTime: '11:00',
        endTime: '15:00'
      },
      cutoffTime: '10:00'
    },
    dinner: {
      serves: 'full',
      timing: {
        startTime: '19:00',
        endTime: '22:00'
      },
      cutoffTime: '18:00'
    },
    isActive: true
  });

  useEffect(() => {
    loadPreferences();
  }, []);

  const loadPreferences = async () => {
    try {
      setLoading(true);
      const response = await fetch(`http://your-api-base-url/api/providers/${providerId}/meal-preferences`);
      const result = await response.json();
      
      if (result.success && result.data) {
        setPreferences(result.data);
      }
    } catch (error) {
      console.error('Error loading preferences:', error);
      Alert.alert('Error', 'Failed to load preferences');
    } finally {
      setLoading(false);
    }
  };

  const savePreferences = async () => {
    try {
      setSaving(true);
      const response = await fetch(`http://your-api-base-url/api/providers/${providerId}/meal-preferences`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(preferences),
      });

      const result = await response.json();

      if (result.success) {
        Alert.alert('Success', 'Preferences saved successfully!');
        navigation.goBack();
      } else {
        Alert.alert('Error', result.error || 'Failed to save preferences');
      }
    } catch (error) {
      console.error('Error saving preferences:', error);
      Alert.alert('Error', 'Failed to save preferences');
    } finally {
      setSaving(false);
    }
  };

  const handleServesChange = (value) => {
    setPreferences(prev => ({
      ...prev,
      serves: value
    }));
  };

  const handleMealTypeChange = (mealType, field, value) => {
    setPreferences(prev => ({
      ...prev,
      [mealType]: {
        ...prev[mealType],
        [field]: value
      }
    }));
  };

  const handleTimingChange = (mealType, timingField, value) => {
    setPreferences(prev => ({
      ...prev,
      [mealType]: {
        ...prev[mealType],
        timing: {
          ...prev[mealType].timing,
          [timingField]: value
        }
      }
    }));
  };

  const formatTimeForDisplay = (time) => {
    const [hours, minutes] = time.split(':');
    const date = new Date();
    date.setHours(parseInt(hours), parseInt(minutes));
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true 
    });
  };

  const TimeInput = ({ label, value, onChange }) => {
    const [showPicker, setShowPicker] = useState(false);
    const [time, setTime] = useState(new Date());

    useEffect(() => {
      const [hours, minutes] = value.split(':');
      const date = new Date();
      date.setHours(parseInt(hours), parseInt(minutes));
      setTime(date);
    }, [value]);

    const onTimeChange = (event, selectedTime) => {
      setShowPicker(false);
      if (selectedTime) {
        setTime(selectedTime);
        const formattedTime = selectedTime.toTimeString().slice(0, 5);
        onChange(formattedTime);
      }
    };

    return (
      <View style={styles.timeInputContainer}>
        <Text style={styles.timeLabel}>{label}</Text>
        <TouchableOpacity 
          style={styles.timeButton}
          onPress={() => setShowPicker(true)}
        >
          <Text style={styles.timeText}>{formatTimeForDisplay(value)}</Text>
        </TouchableOpacity>
        {showPicker && (
          <DateTimePicker
            value={time}
            mode="time"
            display="default"
            onChange={onTimeChange}
          />
        )}
      </View>
    );
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#0000ff" />
        <Text>Loading preferences...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Meal Service Preferences</Text>
        <Text style={styles.subtitle}>Configure your meal service settings</Text>
      </View>

      {/* Service Activation */}
      <View style={styles.section}>
        <View style={styles.switchContainer}>
          <Text style={styles.sectionTitle}>Activate Meal Service</Text>
          <Switch
            value={preferences.isActive}
            onValueChange={(value) => 
              setPreferences(prev => ({ ...prev, isActive: value }))
            }
          />
        </View>
      </View>

      {/* Service Type Selection */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Which meals do you serve?</Text>
        <View style={styles.optionContainer}>
          {['lunch', 'dinner', 'both'].map((option) => (
            <TouchableOpacity
              key={option}
              style={[
                styles.optionButton,
                preferences.serves === option && styles.optionButtonSelected
              ]}
              onPress={() => handleServesChange(option)}
            >
              <Text style={[
                styles.optionText,
                preferences.serves === option && styles.optionTextSelected
              ]}>
                {option === 'lunch' ? 'Lunch Only' : 
                 option === 'dinner' ? 'Dinner Only' : 'Both Lunch & Dinner'}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Lunch Configuration */}
      {(preferences.serves === 'lunch' || preferences.serves === 'both') && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Lunch Service</Text>
          
          <View style={styles.mealSection}>
            <Text style={styles.label}>Tiffin Type</Text>
            <View style={styles.pickerContainer}>
              <Picker
                selectedValue={preferences.lunch.serves}
                onValueChange={(value) => handleMealTypeChange('lunch', 'serves', value)}
                style={styles.picker}
              >
                <Picker.Item label="Full Tiffin Only" value="full" />
                <Picker.Item label="Half Tiffin Only" value="half" />
                <Picker.Item label="Both Half & Full" value="both" />
              </Picker>
            </View>

            <Text style={styles.label}>Service Timings</Text>
            <View style={styles.timingRow}>
              <TimeInput
                label="Start Time"
                value={preferences.lunch.timing.startTime}
                onChange={(value) => handleTimingChange('lunch', 'startTime', value)}
              />
              <TimeInput
                label="End Time"
                value={preferences.lunch.timing.endTime}
                onChange={(value) => handleTimingChange('lunch', 'endTime', value)}
              />
            </View>

            <Text style={styles.label}>Order Cutoff Time</Text>
            <TimeInput
              label="Cutoff Time"
              value={preferences.lunch.cutoffTime}
              onChange={(value) => handleMealTypeChange('lunch', 'cutoffTime', value)}
            />
          </View>
        </View>
      )}

      {/* Dinner Configuration */}
      {(preferences.serves === 'dinner' || preferences.serves === 'both') && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Dinner Service</Text>
          
          <View style={styles.mealSection}>
            <Text style={styles.label}>Tiffin Type</Text>
            <View style={styles.pickerContainer}>
              <Picker
                selectedValue={preferences.dinner.serves}
                onValueChange={(value) => handleMealTypeChange('dinner', 'serves', value)}
                style={styles.picker}
              >
                <Picker.Item label="Full Tiffin Only" value="full" />
                <Picker.Item label="Half Tiffin Only" value="half" />
                <Picker.Item label="Both Half & Full" value="both" />
              </Picker>
            </View>

            <Text style={styles.label}>Service Timings</Text>
            <View style={styles.timingRow}>
              <TimeInput
                label="Start Time"
                value={preferences.dinner.timing.startTime}
                onChange={(value) => handleTimingChange('dinner', 'startTime', value)}
              />
              <TimeInput
                label="End Time"
                value={preferences.dinner.timing.endTime}
                onChange={(value) => handleTimingChange('dinner', 'endTime', value)}
              />
            </View>

            <Text style={styles.label}>Order Cutoff Time</Text>
            <TimeInput
              label="Cutoff Time"
              value={preferences.dinner.cutoffTime}
              onChange={(value) => handleMealTypeChange('dinner', 'cutoffTime', value)}
            />
          </View>
        </View>
      )}

      {/* Info Box */}
      <View style={styles.infoBox}>
        <Text style={styles.infoTitle}>How it works:</Text>
        <Text style={styles.infoText}>• Menus become visible to customers after 8 PM for the next day</Text>
        <Text style={styles.infoText}>• Cutoff time is when customers can no longer place orders</Text>
        <Text style={styles.infoText}>• You can schedule menus in advance for upcoming days</Text>
      </View>

      {/* Save Button */}
      <TouchableOpacity 
        style={[styles.saveButton, saving && styles.saveButtonDisabled]}
        onPress={savePreferences}
        disabled={saving}
      >
        {saving ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={styles.saveButtonText}>Save Preferences</Text>
        )}
      </TouchableOpacity>

      <View style={styles.spacer} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    padding: 16,
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 24,
    paddingTop: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginTop: 8,
  },
  section: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 16,
  },
  switchContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  optionContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  optionButton: {
    flex: 1,
    padding: 12,
    marginHorizontal: 4,
    borderRadius: 8,
    backgroundColor: '#f0f0f0',
    alignItems: 'center',
  },
  optionButtonSelected: {
    backgroundColor: '#007AFF',
  },
  optionText: {
    fontSize: 14,
    color: '#666',
    fontWeight: '500',
  },
  optionTextSelected: {
    color: '#fff',
  },
  mealSection: {
    marginTop: 8,
  },
  label: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
    marginBottom: 8,
    marginTop: 12,
  },
  pickerContainer: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    backgroundColor: '#fff',
  },
  picker: {
    height: 50,
  },
  timingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  timeInputContainer: {
    flex: 1,
    marginHorizontal: 4,
  },
  timeLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  timeButton: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    backgroundColor: '#fff',
  },
  timeText: {
    fontSize: 16,
    color: '#333',
  },
  infoBox: {
    backgroundColor: '#e3f2fd',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1976d2',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    color: '#1976d2',
    marginBottom: 4,
  },
  saveButton: {
    backgroundColor: '#007AFF',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginTop: 16,
  },
  saveButtonDisabled: {
    backgroundColor: '#ccc',
  },
  saveButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
  spacer: {
    height: 20,
  },
});

export default MealPreferencesScreen;