import axios from 'axios';
import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  Alert,
  TextInput,
  Image,
  Platform,
  FlatList,
  Modal
} from 'react-native';
import { Check, Plus, ChevronDown, ChevronUp, X, History, Calendar, Clock } from 'lucide-react-native';
import { useNavigation, useRouter, useLocalSearchParams } from 'expo-router';
import Header from '@/components/header';
import { useAppSelector } from './store/hooks';
import { KeyboardAwareScrollView } from '@/components/scrollable/KeyboardAwareScrollView';
import { LinearGradient } from 'expo-linear-gradient';
import PastHistory from '@/components/pasthistory';

const API_BASE_URL = 'http://192.168.1.178:5000/api';
const DISH_API_URL = 'http://192.168.1.178:5000/api/dish';
const CATEGORY_API_URL = 'http://192.168.1.178:5000/api/category';
const MENU_API_URL = 'http://192.168.1.178:5000/api/menu';
const PROVIDER_API_URL = 'http://192.168.1.178:5000/api/provider';

interface Dish {
  _id: string;
  name: string;
  categoryId: string;
  description?: string;
  isActive?: boolean;
}

interface DishCategory {
  _id: string;
  name: string;
  image: string;
  isActive: boolean;
  order?: number;
}

interface MenuItem {
  categoryId: string;
  dishIds: string[];
}

interface Menu {
  _id: string;
  day: string;
  items: MenuItem[];
  note: string;
  isSent: boolean;
  providerId: string;
  name: string;
  isActive: boolean;
  createdAt: string;
}

interface SelectedDishes {
  [categoryId: string]: string[];
}

interface MenuWithDishes extends Menu {
  dishNames: string[];
}

interface ResponseSettings {
  cutoffTime: string;
  timezone: string;
  isActive: boolean;
}

const DAYS = [
  { id: 'monday', name: 'Mon' },
  { id: 'tuesday', name: 'Tue' },
  { id: 'wednesday', name: 'Wed' },
  { id: 'thursday', name: 'Thu' },
  { id: 'friday', name: 'Fri' },
  { id: 'saturday', name: 'Sat' },
  { id: 'sunday', name: 'Sun' }
];

const DailyMenuScreen: React.FC = () => {
  const provider = useAppSelector((state) => state.provider);
  const providerId = provider.id;

  const router = useRouter();
  const { day } = useLocalSearchParams(); 
  const todayIndex = new Date().getDay();
  const today = DAYS[todayIndex === 0 ? 6 : todayIndex - 1].id;
  
  const [dishes, setDishes] = useState<Dish[]>([]);
  const [categories, setCategories] = useState<DishCategory[]>([]);
  const [selectedDishes, setSelectedDishes] = useState<SelectedDishes>({});
  const [menuName, setMenuName] = useState<string>('Daily Menu');
  const [note, setNote] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [existingMenus, setExistingMenus] = useState<MenuWithDishes[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [selectedDay, setSelectedDay] = useState<string>(today);
  const [showPastMenus, setShowPastMenus] = useState<boolean>(false);
  const [isNoteFocused, setIsNoteFocused] = useState<boolean>(false);
  
  // Time settings states
  const [showTimeModal, setShowTimeModal] = useState<boolean>(false);
  const [selectedTime, setSelectedTime] = useState<Date>(new Date());
  const [responseSettings, setResponseSettings] = useState<ResponseSettings>({
    cutoffTime: '12:00',
    timezone: 'Asia/Kolkata',
    isActive: true
  });
  const [savingTime, setSavingTime] = useState<boolean>(false);
  const [tempHours, setTempHours] = useState<string>('12');
  const [tempMinutes, setTempMinutes] = useState<string>('00');
  const [isAM, setIsAM] = useState<boolean>(true);

  const scrollViewRef = useRef<ScrollView>(null);
  const noteInputRef = useRef<TextInput>(null);
  const navigation = useNavigation();

  useEffect(() => {
    navigation.setOptions({
      headerShown: false,
    });
  }, [navigation]);

  useEffect(() => {
    if (!providerId) {
      Alert.alert('Error', 'Provider not found. Please login again.');
      router.push('/login');
      return;
    }

    fetchData();
    fetchResponseSettings();
  }, [providerId, selectedDay]);

  // Fetch response settings from backend
  const fetchResponseSettings = async () => {
    try {
      console.log('Fetching response settings for provider:', providerId);
      
      const response = await axios.get(`${PROVIDER_API_URL}/${providerId}/response-settings`);
      
      if (response.data.success) {
        const settings = response.data.data.responseSettings;
        setResponseSettings(settings);
        
        // Convert cutoff time string to Date object and update temp states
        const [hours, minutes] = settings.cutoffTime.split(':').map(Number);
        const timeDate = new Date();
        timeDate.setHours(hours, minutes, 0, 0);
        setSelectedTime(timeDate);
        
        // Update temp states for the input fields
        setTempHours(hours > 12 ? (hours - 12).toString() : hours.toString());
        setTempMinutes(minutes.toString().padStart(2, '0'));
        setIsAM(hours < 12);
        
        console.log('Response settings loaded:', settings);
      }
    } catch (error) {
      console.log('Error fetching response settings:', error);
      // Use defaults if settings don't exist
      console.log('Using default response settings');
    }
  };

  // Save response settings to backend
  const saveResponseSettings = async () => {
    try {
      setSavingTime(true);
      
      // Convert to 24-hour format
      let hourNum = parseInt(tempHours) || 12;
      const minuteNum = parseInt(tempMinutes) || 0;

      if (isAM && hourNum === 12) {
        hourNum = 0;
      } else if (!isAM && hourNum < 12) {
        hourNum += 12;
      }

      const timeString = `${hourNum.toString().padStart(2, '0')}:${tempMinutes.padStart(2, '0')}`;
      
      const settingsData = {
        cutoffTime: timeString,
        timezone: responseSettings.timezone,
        isActive: responseSettings.isActive
      };

      console.log('Saving response settings:', settingsData);

      const response = await axios.put(
        `${PROVIDER_API_URL}/${providerId}/response-settings`,
        settingsData
      );

      if (response.data.success) {
        setResponseSettings(settingsData);
        setShowTimeModal(false);
        Alert.alert('Success', `Response time updated to ${formatTime(timeString)}`);
        console.log('Response settings saved successfully');
      } else {
        throw new Error(response.data.message);
      }
    } catch (error) {
      console.error('Error saving response settings:', error);
      const errorMessage = axios.isAxiosError(error) 
        ? error.response?.data?.message || error.message 
        : 'Failed to save response time';
      Alert.alert('Error', errorMessage);
    } finally {
      setSavingTime(false);
    }
  };

  const handleDayChange = (day: string) => {
    setSelectedDay(day);
    clearSelectedDishes();
    setShowPastMenus(false);
  };

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      console.log('Fetching data for provider:', providerId);
      
      // Fetch categories first
      const categoriesResponse = await axios.get(`${CATEGORY_API_URL}/provider/${providerId}`);
      const activeCategories = categoriesResponse.data.data.filter((cat: DishCategory) => cat.isActive);
      
      // Sort categories by order if available, otherwise alphabetically
      activeCategories.sort((a: DishCategory, b: DishCategory) => {
        if (a.order !== undefined && b.order !== undefined) {
          return a.order - b.order;
        }
        return a.name.localeCompare(b.name);
      });
      
      setCategories(activeCategories);
      
      // Initialize selected dishes with empty arrays for each category
      const initialSelectedDishes: SelectedDishes = {};
      activeCategories.forEach((cat: DishCategory) => {
        initialSelectedDishes[cat._id] = [];
      });
      setSelectedDishes(initialSelectedDishes);
      
      // Fetch dishes with better error handling
      let activeDishes: Dish[] = [];
      
      try {
        console.log('Fetching dishes from:', `${DISH_API_URL}/provider/${providerId}`);
        const dishesResponse = await axios.get(`${DISH_API_URL}/provider/${providerId}`);
        
        console.log('Complete dishes response:', JSON.stringify(dishesResponse.data, null, 2));

        if (dishesResponse.data.success && dishesResponse.data.data) {
          dishesResponse.data.data.forEach((categoryGroup: any) => {
            if (categoryGroup.dishes && Array.isArray(categoryGroup.dishes)) {
              categoryGroup.dishes.forEach((dish: any) => {
                // Extract category ID properly
                let categoryId: string;
                if (typeof categoryGroup.categoryId === 'object' && categoryGroup.categoryId !== null) {
                  categoryId = categoryGroup.categoryId._id || categoryGroup.categoryId.toString();
                } else {
                  categoryId = categoryGroup.categoryId.toString();
                }

                const dishData: Dish = {
                  _id: dish._id?.toString() || Math.random().toString(),
                  name: dish.name || 'Unnamed Dish',
                  categoryId: categoryId,
                  description: dish.description || '',
                  isActive: dish.isActive !== false
                };
                
                if (dishData.isActive) {
                  activeDishes.push(dishData);
                }
              });
            }
          });
        }
      } catch (dishError) {
        console.log('No dishes found or error fetching dishes:', dishError);
        // Continue with empty dishes array - categories will still display
      }

      console.log('Final processed dishes:', activeDishes);
      setDishes(activeDishes);
      
      // Check for existing menus for selected day
      try {
        const menuResponse = await axios.get(`${MENU_API_URL}`, {
          params: { providerId, day: selectedDay }
        });
        
        if (menuResponse.data.success && menuResponse.data.menus && menuResponse.data.menus.length > 0) {
          const menusWithDishes = menuResponse.data.menus.map((menu: Menu) => {
            const dishNames: string[] = [];
            
            if (menu.items && Array.isArray(menu.items)) {
              menu.items.forEach(item => {
                if (item.dishIds && Array.isArray(item.dishIds)) {
                  item.dishIds.forEach(dishId => {
                    const dish = activeDishes.find(d => d._id === dishId);
                    if (dish) {
                      dishNames.push(dish.name);
                    }
                  });
                }
              });
            }
            
            return {
              ...menu,
              dishNames: dishNames.slice(0, 3)
            };
          });
          
          setExistingMenus(menusWithDishes);
        } else {
          setExistingMenus([]);
        }
      } catch (menuError) {
        console.log('No menu found for this day:', menuError);
        setExistingMenus([]);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      setError('Failed to load data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Helper function to get dishes by category ID
  const getDishesByCategoryId = (categoryId: string): Dish[] => {
    return dishes.filter(dish => dish.categoryId === categoryId);
  };

  const toggleDishSelection = (categoryId: string, dishId: string) => {
    setSelectedDishes(prev => {
      const currentSelection = [...(prev[categoryId] || [])];
      const index = currentSelection.indexOf(dishId);

      if (index === -1) {
        currentSelection.push(dishId);
      } else {
        currentSelection.splice(index, 1);
      }

      return {
        ...prev,
        [categoryId]: currentSelection
      };
    });
  };

  const isDishSelected = (categoryId: string, dishId: string) => {
    return selectedDishes[categoryId]?.includes(dishId) || false;
  };

  const clearSelectedDishes = () => {
    const clearedSelectedDishes: SelectedDishes = {};
    categories.forEach((cat: DishCategory) => {
      clearedSelectedDishes[cat._id] = [];
    });
    setSelectedDishes(clearedSelectedDishes);
    setNote('');
    setMenuName('Daily Menu');
    setShowPastMenus(false);
  };

  const saveMenu = async () => {
    try {
      setSaving(true);
      setError(null);
      
      const formattedItems = Object.keys(selectedDishes)
        .filter(categoryId => selectedDishes[categoryId].length > 0)
        .map(categoryId => ({
          categoryId,
          dishIds: selectedDishes[categoryId]
        }));

      const menuData = {
        providerId,
        day: selectedDay,
        items: formattedItems,
        note: note.trim() || undefined,
        name: menuName.trim() || 'Daily Menu'
      };

      let response;
      
      // Always create a new menu - no update functionality
      response = await axios.post(`${MENU_API_URL}`, menuData);
      
      if (response.data.success) {
        fetchData();
        clearSelectedDishes(); // Clear all fields after saving
        Alert.alert('Success', 'Menu saved successfully!');
      } else {
        throw new Error(response.data.message);
      }
    } catch (error) {
      console.error('Error saving menu:', error);
      const errorMessage = axios.isAxiosError(error) 
        ? error.response?.data?.message || error.message 
        : 'Failed to save menu';
      setError(errorMessage);
      Alert.alert('Error', errorMessage);
    } finally {
      setSaving(false);
    }
  };

  // Focus on note input and scroll to it
  const focusNoteInput = () => {
    setIsNoteFocused(true);
    setTimeout(() => {
      noteInputRef.current?.focus();
      scrollViewRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };

  // Format time for display
  const formatTime = (timeString: string) => {
    const [hours, minutes] = timeString.split(':').map(Number);
    const date = new Date();
    date.setHours(hours, minutes);
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  // Get emoji for category based on name
  const getCategoryEmoji = (categoryName: string): string => {
    const emojiMap: Record<string, string> = {
      'roti': '🫓', 'sabji': '🥬', 'vegetable': '🥬', 'rice': '🍚', 
      'dal': '🍲', 'extra': '🍽️', 'dessert': '🍰', 'salad': '🥗', 
      'drink': '🥤', 'soup': '🍵'
    };
    return emojiMap[categoryName.toLowerCase()] || '🍽️';
  };

  // Get gradient colors for category based on name
  const getCategoryGradient = (categoryName: string): string[] => {
    const gradientMap: Record<string, string[]> = {
      'roti': ['#f59e0b', '#fbbf24'], 'sabji': ['#10b981', '#34d399'], 
      'vegetable': ['#10b981', '#34d399'], 'rice': ['#2c95f8', '#60a5fa'], 
      'dal': ['#ef4444', '#f87171'], 'extra': ['#8b5cf6', '#a78bfa'], 
      'dessert': ['#ec4899', '#f472b6'], 'salad': ['#84cc16', '#a3e635'], 
      'drink': ['#06b6d4', '#22d3ee'], 'soup': ['#f97316', '#fb923c']
    };
    return gradientMap[categoryName.toLowerCase()] || ['#4f46e5', '#818cf8'];
  };

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Open time modal and initialize with current settings
  const openTimeModal = () => {
    // Initialize temp states with current response settings
    const [hours, minutes] = responseSettings.cutoffTime.split(':').map(Number);
    setTempHours(hours > 12 ? (hours - 12).toString() : hours.toString());
    setTempMinutes(minutes.toString().padStart(2, '0'));
    setIsAM(hours < 12);
    setShowTimeModal(true);
  };

  // Validate time inputs
  const validateTimeInputs = () => {
    const hours = parseInt(tempHours);
    const minutes = parseInt(tempMinutes);

    if (isNaN(hours) || hours < 1 || hours > 12) {
      Alert.alert('Invalid Time', 'Please enter a valid hour (1-12)');
      return false;
    }

    if (isNaN(minutes) || minutes < 0 || minutes > 59) {
      Alert.alert('Invalid Time', 'Please enter valid minutes (0-59)');
      return false;
    }

    return true;
  };

  // Get current preview time
  const getPreviewTime = () => {
    if (!validateTimeInputs()) return 'Invalid Time';
    
    let hourNum = parseInt(tempHours) || 12;
    const minuteNum = parseInt(tempMinutes) || 0;

    if (isAM && hourNum === 12) {
      hourNum = 0;
    } else if (!isAM && hourNum < 12) {
      hourNum += 12;
    }

    const timeString = `${hourNum.toString().padStart(2, '0')}:${tempMinutes.padStart(2, '0')}`;
    return formatTime(timeString);
  };

  // Render Day Selector
  const renderDaySelector = () => {
    return (
      <View style={styles.daysContainer}>
        <View style={styles.daysGrid}>
          {DAYS.map((day) => {
            const isActive = day.id === selectedDay;
            const dayMenus = existingMenus.filter(menu => menu.day === day.id);
            
            return (
              <LinearGradient
                key={day.id}
                colors={isActive ? ['#32C0DA', '#1a71ecff'] : ['transparent', 'transparent']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={[styles.dayTab, isActive && styles.activeDayTab]}
              >
                <TouchableOpacity
                  style={styles.dayTabContent}
                  onPress={() => handleDayChange(day.id)}
                  activeOpacity={0.9}
                >
                  <Text style={[styles.dayText, isActive && styles.activeDayText]}>
                    {day.name}
                  </Text>
                </TouchableOpacity>

                {dayMenus.length > 0 && (
                  <View
                    style={[
                      styles.menuCountBadge,
                      isActive ? styles.activeMenuCountBadge : styles.inactiveMenuCountBadge,
                    ]}
                  >
                    <Text
                      style={[
                        styles.menuCountText,
                        isActive ? styles.activeMenuCountText : styles.inactiveMenuCountText,
                      ]}
                    >
                      {dayMenus.length}
                    </Text>
                  </View>
                )}
              </LinearGradient>
            );
          })}
        </View>
      </View>
    );
  };

  // Render Past Menus Trigger
  const renderPastMenusTrigger = () => {
    if (existingMenus.length === 0) return null;

    return (
      <View style={styles.pastMenusContainer}>
        <TouchableOpacity
          style={styles.pastMenusTrigger}
          onPress={() => setShowPastMenus(!showPastMenus)}
        >
          <View style={styles.pastMenusTriggerContent}>
            <View style={styles.pastMenusHeader}>
              <History size={18} color="#2c95f8" />
              <Text style={styles.pastMenusTriggerText}>
                {showPastMenus ? 'Hide Past Menus' : `Show Past Menus (${existingMenus.length})`}
              </Text>
            </View>
            <Text style={styles.pastMenusTriggerSubtext}>
              {showPastMenus ? 'Tap to collapse' : 'Tap to view previous menus for this day'}
            </Text>
          </View>
          {showPastMenus ? (
            <ChevronUp size={20} color="#2c95f8" />
          ) : (
            <ChevronDown size={20} color="#2c95f8" />
          )}
        </TouchableOpacity>
      </View>
    );
  };

  // Render Past Menus Accordion
  const renderPastMenusAccordion = () => {
    if (!showPastMenus) return null;

    return (
      <PastHistory
        history={existingMenus.map(menu => ({
          _id: menu._id,
          providerId: menu.providerId,
          menuId: menu._id,
          menuName: menu.name,
          day: menu.day,
          items: menu.items.map(item => ({
            categoryId: item.categoryId,
            categoryName: categories.find(cat => cat._id === item.categoryId)?.name || 'Category',
            dishes: item.dishIds.map(dishId => ({
              dishId,
              dishName: dishes.find(d => d._id === dishId)?.name || 'Unknown Dish'
            }))
          })),
          note: menu.note,
          sentAt: menu.createdAt
        }))}
        loading={false}
        isExpanded={showPastMenus}
        onToggle={() => setShowPastMenus(!showPastMenus)}
        day={selectedDay}
        getDishName={(dishId) => dishes.find(d => d._id === dishId)?.name || 'Unknown Dish'}
        formatDate={formatDate}
      />
    );
  };

  // Render Category
  const renderCategory = (category: DishCategory) => {
    const categoryDishes = getDishesByCategoryId(category._id);
    const emoji = getCategoryEmoji(category.name);
    const gradientColors = getCategoryGradient(category.name);

    const selectedDishNames = dishes
      .filter(dish => selectedDishes[category._id]?.includes(dish._id))
      .map(dish => dish.name);

    return (
      <View key={category._id} style={[styles.categorySection]}>
        <View style={[styles.categoryBorder, { backgroundColor: gradientColors[0] }]} />
        
        <View style={styles.categoryContent}>
          <View style={styles.categoryHeader}>
            <View style={styles.categoryTitleContainer}>
              {category.image ? (
                <Image source={{ uri: category.image }} style={styles.categoryImage} />
              ) : (
                <Text style={styles.categoryEmoji}>{emoji}</Text>
              )}
              <Text style={styles.categoryTitle}>
                {category.name} ({categoryDishes.length} dishes)
              </Text>
            </View>
          </View>
          
          {selectedDishNames.length > 0 && (
            <View style={styles.selectedItemsContainer}>
              <Text style={styles.selectedItemsText}>
                Selected: {selectedDishNames.join(', ')}
              </Text>
            </View>
          )}
          
          {categoryDishes.length === 0 ? (
            <Text style={styles.emptyCategory}>No dishes available in this category</Text>
          ) : (
            <View style={styles.dishesContainer}>
              {categoryDishes.map(dish => (
                <TouchableOpacity
                  key={dish._id}
                  style={[
                    styles.dishButton,
                    isDishSelected(category._id, dish._id) && [styles.selectedDishButton, { backgroundColor: gradientColors[0] }],
                  ]}
                  onPress={() => toggleDishSelection(category._id, dish._id)}
                >
                  <Text style={[
                    styles.dishText,
                    isDishSelected(category._id, dish._id) && styles.selectedDishText,
                  ]}>
                    {dish.name}
                  </Text>
                  {isDishSelected(category._id, dish._id) && (
                    <Check size={16} color="#fff" style={styles.checkIcon} />
                  )}
                </TouchableOpacity>
              ))}
            </View>
          )}
        </View>
      </View>
    );
  };

  // Render Time Settings Modal
  const renderTimeModal = () => {
    return (
      <Modal
        visible={showTimeModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowTimeModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Set Response Cutoff Time</Text>
              <TouchableOpacity
                onPress={() => setShowTimeModal(false)}
                style={styles.closeButton}
              >
                <X size={24} color="#64748B" />
              </TouchableOpacity>
            </View>
            
            <Text style={styles.modalDescription}>
              Set the time by which customers must respond for each day's menu. After this time, pending responses will be automatically set to "Yes".
            </Text>
            
            <View style={styles.timeInputContainer}>
              <Text style={styles.timeInputLabel}>Select Time:</Text>
              
              <View style={styles.timeInputRow}>
                <View style={styles.timeInputGroup}>
                  <Text style={styles.inputLabelSmall}>Hours</Text>
                  <TextInput
                    style={styles.timeInput}
                    value={tempHours}
                    onChangeText={setTempHours}
                    keyboardType="numeric"
                    maxLength={2}
                    placeholder="12"
                  />
                </View>
                
                <Text style={styles.timeSeparator}>:</Text>
                
                <View style={styles.timeInputGroup}>
                  <Text style={styles.inputLabelSmall}>Minutes</Text>
                  <TextInput
                    style={styles.timeInput}
                    value={tempMinutes}
                    onChangeText={setTempMinutes}
                    keyboardType="numeric"
                    maxLength={2}
                    placeholder="00"
                  />
                </View>
                
                <View style={styles.ampmContainer}>
                  <TouchableOpacity
                    style={[styles.ampmButton, isAM && styles.ampmButtonActive]}
                    onPress={() => setIsAM(true)}
                  >
                    <Text style={[styles.ampmText, isAM && styles.ampmTextActive]}>AM</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.ampmButton, !isAM && styles.ampmButtonActive]}
                    onPress={() => setIsAM(false)}
                  >
                    <Text style={[styles.ampmText, !isAM && styles.ampmTextActive]}>PM</Text>
                  </TouchableOpacity>
                </View>
              </View>
              
              <View style={styles.timePreview}>
                <Text style={styles.timePreviewText}>
                  Selected: {getPreviewTime()}
                </Text>
              </View>
            </View>
            
            <View style={styles.currentSetting}>
              <Text style={styles.currentSettingLabel}>Current Setting:</Text>
              <Text style={styles.currentSettingValue}>
                {formatTime(responseSettings.cutoffTime)}
              </Text>
            </View>
            
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setShowTimeModal(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[styles.modalButton, styles.saveTimeButton]}
                onPress={() => {
                  if (validateTimeInputs()) {
                    saveResponseSettings();
                  }
                }}
                disabled={savingTime}
              >
                {savingTime ? (
                  <ActivityIndicator size="small" color="#fff" />
                ) : (
                  <Text style={styles.saveButtonText}>Save Time</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    );
  };

  // Render Set Time Button
  const renderSetTimeButton = () => {
    return (
      <View style={styles.setTimeContainer}>
        <TouchableOpacity
          style={styles.setTimeButton}
          onPress={openTimeModal}
        >
          <Clock size={20} color="#2c95f8" />
          <Text style={styles.setTimeButtonText}>
            Set Response Time: {formatTime(responseSettings.cutoffTime)}
          </Text>
          <ChevronDown size={16} color="#2c95f8" />
        </TouchableOpacity>
        
        <Text style={styles.setTimeDescription}>
          Customers can respond until this time each day
        </Text>
      </View>
    );
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2c95f8" />
        <Text style={styles.loadingText}>Loading menus...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>{error}</Text>
        <TouchableOpacity
          style={styles.retryButton}
          onPress={fetchData}
        >
          <Text style={styles.retryButtonText}>Retry</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <KeyboardAwareScrollView
        ref={scrollViewRef}
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContainer}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {renderDaySelector()}
        
        {/* Add Set Time Button here */}
        {renderSetTimeButton()}
        
        {renderPastMenusTrigger()}
        {renderPastMenusAccordion()}
        
        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Menu Name</Text>
          <TextInput
            style={styles.textInput}
            placeholder="Enter menu name"
            value={menuName}
            onChangeText={setMenuName}
          />
        </View>
        
        {categories.map(category => renderCategory(category))}
        
        <View style={styles.notesContainer}>
          <Text style={styles.notesTitle}>📝 Notes (Optional)</Text>
          <TouchableOpacity 
            style={styles.notesInputTouchable}
            onPress={focusNoteInput}
            activeOpacity={0.7}
          >
            <TextInput
              ref={noteInputRef}
              style={styles.notesInput}
              placeholder="E.g., 'Special paneer today!'"
              value={note}
              onChangeText={setNote}
              multiline
              numberOfLines={4}
              onFocus={() => setIsNoteFocused(true)}
              onBlur={() => setIsNoteFocused(false)}
            />
          </TouchableOpacity>
        </View>

        <View style={styles.bottomSpacer} />
      </KeyboardAwareScrollView>
      
      {/* Render Time Modal */}
      {renderTimeModal()}
      
      <View style={styles.fixedButtonContainer}>
        <TouchableOpacity
          style={[styles.actionButton, styles.saveButton, saving && styles.disabledButton]}
          onPress={saveMenu}
          disabled={saving}
        >
          {saving ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.buttonText}>
              Save Menu
            </Text>
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#64748B',
    fontWeight: '500',
    marginTop: 12,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    fontSize: 16,
    color: '#EF4444',
    marginBottom: 20,
    textAlign: 'center',
  },
  retryButton: {
    backgroundColor: '#2c95f8',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
  },
  retryButtonText: {
    color: '#fff',
    fontWeight: '600',
  },
  scrollContainer: {
    paddingHorizontal: 4,
    flexGrow: 1,
    paddingBottom: 100,
  },
  scrollView: {
    flex: 1,
  },
  // Past Menus Accordion Styles
  pastMenusContainer: {
    marginHorizontal: 16,
    marginTop: 16,
    marginBottom: 8,
  },
  pastMenusTrigger: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 20,
    elevation: 3,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  pastMenusTriggerContent: {
    flex: 1,
    marginRight: 8,
  },
  pastMenusHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  pastMenusTriggerText: {
    fontSize: 16,
    color: '#1E293B',
    fontWeight: '600',
    marginLeft: 8,
  },
  pastMenusTriggerSubtext: {
    fontSize: 12,
    color: '#64748B',
    marginLeft: 26,
  },
  // Day selector styles
  daysContainer: {
    backgroundColor: '#F8FAFC',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(226, 232, 240, 0.5)',
    paddingHorizontal: 12,
    marginTop: 4,
    paddingBottom: 10,
    paddingTop: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 1,
  },
  daysGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  dayTab: {
    flex: 1,
    borderRadius: 12,
    marginHorizontal: 2,
    minHeight: 50,
    overflow: 'hidden',
  },
  dayTabContent: {
    flex: 1,
    padding: 6,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 12,
    position: 'relative',
  },
  activeDayTab: {
    shadowColor: '#2c95f8',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 3,
    transform: [{ translateY: -2 }],
  },
  dayText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748B',
  },
  activeDayText: {
    color: '#fff',
  },
  menuCountBadge: {
    position: 'absolute',
    top: -1,
    right: 4,
    borderRadius: 12,
    paddingHorizontal: 6,
    paddingVertical: 2,
    minWidth: 20,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 10,
  },
  inactiveMenuCountBadge: {
    backgroundColor: 'rgba(44, 149, 248, 0.15)',
  },
  inactiveMenuCountText: {
    color: '#2c95f8',
    fontSize: 10,
    fontWeight: '600',
  },
  activeMenuCountBadge: {
    backgroundColor: '#fff',
    top: 1,
    right: 1,
  },
  activeMenuCountText: {
    color: '#2c95f8',
    fontSize: 10,
    fontWeight: '700',
  },
  // Input styles
  inputContainer: {
    marginBottom: 16,
    marginTop: 17,
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1E293B',
    marginBottom: 8,
  },
  inputLabelSmall: {
    fontSize: 12,
    color: '#64748B',
    marginBottom: 8,
    textAlign: 'center',
  },
  textInput: {
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
  },
  // Category section styles
  categorySection: {
    backgroundColor: '#F8FAFC',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 20,
    elevation: 3,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
    position: 'relative',
    overflow: 'hidden',
  },
  categoryBorder: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: 4,
    height: '140%',
    borderTopLeftRadius: 0,
    borderBottomLeftRadius: 0,
  },
  categoryContent: {
    marginLeft: 8,
  },
  categoryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  categoryTitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  categoryImage: {
    width: 24,
    height: 24,
    marginRight: 8,
    borderRadius: 4,
  },
  categoryEmoji: {
    fontSize: 20,
    marginRight: 8,
  },
  categoryTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1E293B',
  },
  selectedItemsContainer: {
    backgroundColor: '#effeffff',
    padding: 8,
    borderRadius: 8,
    marginBottom: 12,
  },
  selectedItemsText: {
    color: '#32C0DA',
    fontSize: 16,
    fontWeight: '600',
  },
  emptyCategory: {
    color: '#94A3B8',
    fontStyle: 'italic',
    textAlign: 'center',
    padding: 16,
  },
  dishesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  dishButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F1F5F9',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
  },
  selectedDishButton: {
    backgroundColor: '#4F46E5',
  },
  dishText: {
    color: '#475569',
    fontWeight: '500',
  },
  selectedDishText: {
    color: '#fff',
  },
  checkIcon: {
    marginLeft: 6,
  },
  notesContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
    marginBottom: 20,
  },
  notesTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1E293B',
    marginBottom: 12,
  },
  notesInputTouchable: {
    // Makes the entire area tappable
  },
  notesInput: {
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 8,
    padding: 12,
    minHeight: 100,
    textAlignVertical: 'top',
    fontSize: 16,
  },
  bottomSpacer: {
    height: 50,
  },
  fixedButtonContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: Platform.OS === 'ios' ? 40 : 24,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
  },
  actionButton: {
    flex: 1,
    padding: 12,
    borderRadius: 12,
    bottom: 20,
    marginTop: 20,
    alignItems: 'center',
    justifyContent: 'center',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 6,
  },
  saveButton: {
    backgroundColor: '#06864bff',
  },
  disabledButton: {
    backgroundColor: '#94A3B8',
  },
  buttonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 16,
  },
  // Set Time Button styles
  setTimeContainer: {
    marginHorizontal: 16,
    marginTop: 16,
    marginBottom: 8,
  },
  setTimeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 20,
    elevation: 3,
    borderWidth: 2,
    borderColor: 'rgba(44, 149, 248, 0.2)',
  },
  setTimeButtonText: {
    flex: 1,
    fontSize: 16,
    color: '#1E293B',
    fontWeight: '600',
    marginLeft: 12,
    marginRight: 8,
  },
  setTimeDescription: {
    fontSize: 12,
    color: '#64748B',
    marginTop: 8,
    marginLeft: 4,
    textAlign: 'center',
  },
  // Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 24,
    width: '100%',
    maxWidth: 400,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 10,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1E293B',
    flex: 1,
  },
  closeButton: {
    padding: 4,
  },
  modalDescription: {
    fontSize: 14,
    color: '#64748B',
    lineHeight: 20,
    marginBottom: 24,
  },
  // Time input styles
  timeInputContainer: {
    marginBottom: 20,
  },
  timeInputLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1E293B',
    marginBottom: 16,
  },
  timeInputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  timeInputGroup: {
    alignItems: 'center',
  },
  timeInput: {
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 8,
    padding: 12,
    width: 60,
    textAlign: 'center',
    fontSize: 18,
    fontWeight: '600',
    color: '#1E293B',
  },
  timeSeparator: {
    fontSize: 24,
    fontWeight: '600',
    color: '#1E293B',
    marginHorizontal: 8,
    marginTop: 20,
  },
  ampmContainer: {
    marginLeft: 16,
  },
  ampmButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: '#F1F5F9',
    marginVertical: 2,
  },
  ampmButtonActive: {
    backgroundColor: '#32C0DA',
  },
  ampmText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748B',
  },
  ampmTextActive: {
    color: '#fff',
  },
  timePreview: {
    backgroundColor: '#effeffff',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  timePreviewText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#32C0DA',
  },
  currentSetting: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#F8FAFC',
    padding: 16,
    borderRadius: 12,
    marginBottom: 24,
  },
  currentSettingLabel: {
    fontSize: 14,
    color: '#64748B',
    fontWeight: '500',
  },
  currentSettingValue: {
    fontSize: 16,
    color: '#1E293B',
    fontWeight: '600',
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  modalButton: {
    flex: 1,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cancelButton: {
    backgroundColor: '#F1F5F9',
  },
  saveTimeButton: {
    backgroundColor: '#32C0DA',
  },
  cancelButtonText: {
    color: '#64748B',
    fontWeight: '600',
    fontSize: 16,
  },
  saveButtonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 16,
  },
});

export default DailyMenuScreen;