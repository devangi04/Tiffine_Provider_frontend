import axios from 'axios';
import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  Alert,
  TextInput,
  Animated,
  Keyboard,
  SafeAreaView,
  Pressable,
  Dimensions,
} from 'react-native';
import { Check, Send, ChevronLeft } from 'lucide-react-native';
import { useLocalSearchParams, useNavigation, useRouter } from 'expo-router';
import Header from '@/components/header';
import BottomNavBar from '@/components/navbar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient'
import { useAppSelector } from './store/hooks';
import { KeyboardAwareScrollView } from '@/components/scrollable/KeyboardAwareScrollView';

const API_BASE_URL = 'http://192.168.1.178:5000/api';
const { width } = Dimensions.get('window');

interface Dish {
  _id: string;
  name: string;
  category: string;
  isActive?: boolean;
}

interface MenuItem {
  roti: Dish[];
  sabji: Dish[];
  rice: Dish[];
  dal: Dish[];
  extra: Dish[];
}

interface Menu {
  _id: string;
  day: string;
  items: MenuItem;
  note: string;
  isSent: boolean;
  providerId: string;
  name: string;
  isActive: boolean;
  createdAt: string;
}

interface SelectedDishes {
  roti: string[];
  sabji: string[];
  rice: string[];
  dal: string[];
  extra: string[];
}

// Updated DAYS array with abbreviated names like in ScheduleScreen
const DAYS = [
  { id: 'monday', name: 'Mon' },
  { id: 'tuesday', name: 'Tue' },
  { id: 'wednesday', name: 'Wed' },
  { id: 'thursday', name: 'Thu' },
  { id: 'friday', name: 'Fri' },
  { id: 'saturday', name: 'Sat' },
  { id: 'sunday', name: 'Sun' }
];

const DailyMenuScreen: React.FC = () => {
  const params = useLocalSearchParams();
  const provider = useAppSelector((state) => state.provider);
  const providerId = provider.id;

  const router = useRouter();
  
  const todayIndex = new Date().getDay();
  const today = DAYS[todayIndex === 0 ? 6 : todayIndex - 1].id;
  
  const [dishes, setDishes] = useState<Dish[]>([]);
  const [selectedDishes, setSelectedDishes] = useState<SelectedDishes>({
    roti: [],
    sabji: [],
    rice: [],
    dal: [],
    extra: []
  });
  const [menuName, setMenuName] = useState<string>('Daily Menu');
  const [note, setNote] = useState<string>('');
  const [activeNav, setActiveNav] = useState('Menu');
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [existingMenu, setExistingMenu] = useState<Menu | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [selectedDay, setSelectedDay] = useState<string>(today);
  const navbarOpacity = new Animated.Value(1);
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const scrollViewRef = useRef();
   
  useEffect(() => {
    navigation.setOptions({
      headerShown: false,
    })
  }, [navigation]);

  useEffect(() => {
    if (!providerId) {
      Alert.alert('Error', 'provider not Found please login again');
      router.push('/login');
      return;
    }
    
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        // Fetch active dishes
        const dishesResponse = await axios.get(`${API_BASE_URL}/dish/provider/${providerId}`);
        const activeDishes = dishesResponse.data.data.filter((dish: Dish) => dish.isActive);
        setDishes(activeDishes);
        
        // Check for existing menus for selected day
        const menuResponse = await axios.get(`${API_BASE_URL}/menu?providerId=${providerId}&day=${selectedDay}`);
        if (menuResponse.data.success && menuResponse.data.menus.length > 0) {
          const mostRecentMenu = menuResponse.data.menus[0];
          setExistingMenu(mostRecentMenu);
          setSelectedDishes({
            roti: mostRecentMenu.items.roti.map((d: Dish) => d._id),
            sabji: mostRecentMenu.items.sabji.map((d: Dish) => d._id),
            rice: mostRecentMenu.items.rice.map((d: Dish) => d._id),
            dal: mostRecentMenu.items.dal.map((d: Dish) => d._id),
            extra: mostRecentMenu.items.extra.map((d: Dish) => d._id)
          });
          setNote(mostRecentMenu.note || '');
          setMenuName(mostRecentMenu.name || 'Daily Menu');
        } else {
          // No menu exists for this day - reset to defaults
          setExistingMenu(null);
          setSelectedDishes({ roti: [], sabji: [], rice: [], dal: [], extra: [] });
          setNote('');
          setMenuName('Daily Menu');
        }
      } catch (error) {
        console.error('Error fetching data:', error);
        setError('Failed to load data. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [providerId, selectedDay]);

  const handleDayChange = (day: string) => {
    setSelectedDay(day);
  };

  const handleNavigation = (screenName: string) => {
    setActiveNav(screenName);
  };

  const toggleDishSelection = (category: keyof SelectedDishes, dishId: string) => {
    setSelectedDishes(prev => {
      const currentSelection = [...prev[category]];
      const index = currentSelection.indexOf(dishId);

      const maxSelections = {
        roti: 2,
        sabji: 2,
        rice: 1,
        dal: 1,
        extra: Infinity
      };

      if (index === -1) {
        if (currentSelection.length < maxSelections[category]) {
          currentSelection.push(dishId);
        } else {
          Alert.alert('Limit reached', `You can select maximum ${maxSelections[category]} ${category} items`);
          return prev;
        }
      } else {
        currentSelection.splice(index, 1);
      }

      return {
        ...prev,
        [category]: currentSelection
      };
    });
  };

  const isDishSelected = (category: keyof SelectedDishes, dishId: string) => {
    return selectedDishes[category].includes(dishId);
  };

  const saveMenu = async () => {
    if (!selectedDishes.roti.length || !selectedDishes.sabji.length || 
        !selectedDishes.rice.length || !selectedDishes.dal.length) {
      Alert.alert('Incomplete Menu', 'Please select at least one item from each category (Roti, Sabji, Rice, Dal)');
      return;
    }

    try {
      setSaving(true);
      setError(null);
      
      const menuData = {
        id: existingMenu?._id || undefined,
        providerId,
        day: selectedDay,
        items: selectedDishes,
        note: note.trim() || undefined,
        name: menuName.trim() || 'Daily Menu',
        isActive: true
      };

      // Use upsert endpoint
      const response = await axios.put(`${API_BASE_URL}/menu`, menuData);
      
      setExistingMenu(response.data.menu);
      Alert.alert('Success', `Menu ${existingMenu?._id ? 'updated' : 'saved'} successfully!`);
    } catch (error) {
      console.error('Error saving menu:', error);
      const errorMessage = axios.isAxiosError(error) 
        ? error.response?.data?.message || error.message 
        : 'Failed to save menu';
      setError(errorMessage);
      Alert.alert('Error', errorMessage);
    } finally {
      setSaving(false);
    }
  };

  const markMenuAsSent = async () => {
    if (!existingMenu?._id) {
      Alert.alert('Error', 'Please save the menu before marking as sent');
      return;
    }

    try {
      setSaving(true);
      const response = await axios.patch(`${API_BASE_URL}/menu/${existingMenu._id}/mark-sent`);
      setExistingMenu(response.data.data);
      Alert.alert('Success', 'Menu marked as sent to customers!');
    } catch (error) {
      console.error('Error marking menu as sent:', error);
      const errorMessage = axios.isAxiosError(error) 
        ? error.response?.data?.error || error.message 
        : 'Failed to mark menu as sent';
      Alert.alert('Error', errorMessage);
    } finally {
      setSaving(false);
    }
  };

  const renderCategory = (category: keyof SelectedDishes, title: string, emoji: string) => {
    const categoryDishes = dishes.filter(dish => dish.category === category);
    const maxSelect = category === 'roti' || category === 'sabji' ? 2 : 
                     (category === 'rice' || category === 'dal' ? 1 : Infinity);

    const selectedDishNames = dishes
      .filter(dish => selectedDishes[category].includes(dish._id))
      .map(dish => dish.name);

    // Get the appropriate style for each category
    const categoryStyle = styles[`${category}Category`] || styles.defaultCategory;
    const borderStyle = styles[`${category}Border`] || styles.defaultBorder;

    return (
      <View style={[styles.categorySection, categoryStyle]}>
        {/* Gradient side border */}
        <View style={[styles.categoryBorder, borderStyle]} />
        
        <View style={styles.categoryContent}>
          <View style={styles.categoryHeader}>
            <Text style={styles.categoryTitle}>
              {emoji} {title} (Select {maxSelect === 1 ? '1' : '1-2'})
            </Text>
          </View>
          
          {selectedDishNames.length > 0 && (
            <View style={styles.selectedItemsContainer}>
              <Text style={styles.selectedItemsText}>
                Selected: {selectedDishNames.join(', ')}
              </Text>
            </View>
          )}
          
          {categoryDishes.length === 0 ? (
            <Text style={styles.emptyCategory}>No dishes available in this category</Text>
          ) : (
            <View style={styles.dishesContainer}>
              {categoryDishes.map(dish => (
                <TouchableOpacity
                  key={dish._id}
                  style={[
                    styles.dishButton,
                    isDishSelected(category, dish._id) && styles.selectedDishButton,
                    !isDishSelected(category, dish._id) && 
                      selectedDishes[category].length >= maxSelect && styles.disabledDishButton
                  ]}
                  onPress={() => toggleDishSelection(category, dish._id)}
                >
                  <Text style={[
                    styles.dishText,
                    isDishSelected(category, dish._id) && styles.selectedDishText,
                  ]}>
                    {dish.name}
                  </Text>
                  {isDishSelected(category, dish._id) && (
                    <Check size={16} color="#fff" style={styles.checkIcon} />
                  )}
                </TouchableOpacity>
              ))}
            </View>
          )}
        </View>
      </View>
    );
  };

  // Render day selector like in ScheduleScreen
  const renderDaySelector = () => {
    return (
      <View style={styles.daysContainer}>
        <View style={styles.daysGrid}>
          {DAYS.map((day) => {
            const isActive = day.id === selectedDay;
            
            if (isActive) {
              return (
                <LinearGradient
                  key={day.id}
                  colors={['#2c95f8', '#0022ff']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={[styles.dayTab, styles.activeDayTab]}
                >
                  <TouchableOpacity 
                    onPress={() => handleDayChange(day.id)}
                  >
                    <Text style={[styles.dayText, styles.activeDayText]}>
                      {day.name}
                    </Text>
                  </TouchableOpacity>
                </LinearGradient>
              );
            } else {
              return (
                <TouchableOpacity
                  key={day.id}
                  style={styles.dayTab}
                  onPress={() => handleDayChange(day.id)}
                >
                  <Text style={styles.dayText}>
                    {day.name}
                  </Text>
                </TouchableOpacity>
              );
            }
          })}
        </View>
      </View>
    );
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#4F46E5" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>{error}</Text>
        <TouchableOpacity
          style={styles.retryButton}
          onPress={() => window.location.reload()}
        >
          <Text style={styles.retryButtonText}>Retry</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      
      <Header
        title={`${selectedDay.charAt(0).toUpperCase() + selectedDay.slice(1)}'s Menu`}
        subtitle="Manage Weekly Menus" 
        backgroundColor="#2c95f8"
        onBackPress={() => router.back()}
        onUserPress={() => router.push('/profile')}
      />

      <KeyboardAwareScrollView
        ref={scrollViewRef}
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContainer}
        showsVerticalScrollIndicator={false}
        enableOnAndroid={true}
        extraScrollHeight={100}
        extraHeight={100}
        keyboardOpeningTime={0}
        enableResetScrollToCoords={false}
        keyboardShouldPersistTaps="handled"
        automaticallyAdjustContentInsets={false}
      >
        {/* Use the new day selector */}
        {renderDaySelector()}
        
        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Menu Name</Text>
          <TextInput
            style={styles.textInput}
            placeholder="Enter menu name"
            value={menuName}
            onChangeText={setMenuName}
          />
        </View>
        
        {/* Render categories with new design */}
        {renderCategory('roti', 'Roti', '🫓')}
        {renderCategory('sabji', 'Sabji', '🥬')}
        {renderCategory('rice', 'Rice', '🍚')}
        {renderCategory('dal', 'Dal', '🍲')}
        {renderCategory('extra', 'Extras', '🍽️')}
        
        <View style={styles.notesContainer}>
          <Text style={styles.notesTitle}>📝 Notes (Optional)</Text>
          <TextInput
            style={styles.notesInput}
            placeholder="E.g., 'Special paneer today!'"
            value={note}
            onChangeText={setNote}
            multiline
            numberOfLines={4}
          />
        </View>
      </KeyboardAwareScrollView>
      
      <View style={styles.fixedButtonContainer}>
        <TouchableOpacity
          style={[
            styles.actionButton, 
            styles.saveButton,
            saving && styles.disabledButton
          ]}
          onPress={saveMenu}
          disabled={saving}
        >
          {saving ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.buttonText}>
              {existingMenu ? 'Update Menu' : 'Save Menu'}
            </Text>
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    fontSize: 16,
    color: '#EF4444',
    marginBottom: 20,
    textAlign: 'center',
  },
  retryButton: {
    backgroundColor: '#4F46E5',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  retryButtonText: {
    color: '#fff',
    fontWeight: '600',
  },
  scrollContainer: {
    paddingHorizontal: 4,
    flexGrow: 1,
    paddingBottom: 70,
  },
  scrollView: {
    flex: 1,
    paddingBottom: 100,
  },
  // Day selector styles
  daysContainer: {
    backgroundColor: '#F8FAFC',
    paddingHorizontal: 5,
    marginTop: 3,
    paddingBottom: 10,
    paddingTop: 10,
  },
  daysGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  dayTab: {
    padding: 6,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 12,
    flex: 1,
    marginHorizontal: 2,
    minHeight: 50,
  },
  activeDayTab: {
    backgroundColor: '#2c95f8',
    shadowColor: '#2c95f8',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 3,
  },
  dayText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748B',
  },
  activeDayText: {
    color: '#fff',
  },
  inputContainer: {
    marginBottom: 16,
    marginTop: 17,
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1E293B',
    marginBottom: 8,
  },
  textInput: {
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
  },
  // Enhanced category section styles
  categorySection: {
    backgroundColor: '#F8FAFC',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 20,
    elevation: 3,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
    position: 'relative',
    overflow: 'hidden',
  },
  categoryBorder: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: 4,
    height: 220,
    borderTopLeftRadius: 0,
    borderBottomLeftRadius: 0,
  },
  rotiCategory: {},
  sabjiCategory: {},
  riceCategory: {},
  dalCategory: {},
  extraCategory: {},
  defaultCategory: {},
  // Category-specific border colors
  rotiBorder: {
    backgroundColor: '#f59e0b',
  },
  sabjiBorder: {
    backgroundColor: '#10b981',
  },
  riceBorder: {
    backgroundColor: '#2c95f8',
  },
  dalBorder: {
    backgroundColor: '#ef4444',
  },
  extraBorder: {
    backgroundColor: '#8b5cf6',
  },
  defaultBorder: {
    backgroundColor: '#4f46e5',
  },
  categoryContent: {
    marginLeft: 8, // Add space for the border
  },
  categoryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  categoryTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1E293B',
  },
  selectedItemsContainer: {
    backgroundColor: '#EFF6FF',
    padding: 8,
    borderRadius: 8,
    marginBottom: 12,
  },
  selectedItemsText: {
    color: '#1E40AF',
    fontSize: 14,
  },
  emptyCategory: {
    color: '#94A3B8',
    fontStyle: 'italic',
  },
  dishesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  dishButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F1F5F9',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
  },
  selectedDishButton: {
    backgroundColor: '#4F46E5',
  },
  disabledDishButton: {
    opacity: 0.6,
  },
  dishText: {
    color: '#475569',
    fontWeight: '500',
  },
  selectedDishText: {
    color: '#fff',
  },
  checkIcon: {
    marginLeft: 6,
  },
  notesContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  notesTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1E293B',
    marginBottom: 12,
  },
  notesInput: {
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 8,
    padding: 12,
    minHeight: 100,
    textAlignVertical: 'top',
  },
  fixedButtonContainer: {
    position: 'absolute',
    bottom: 16,
    left: 5,
    right: 5,
    marginHorizontal: 20,
    flexDirection: 'row',
    gap: 20,
  },
  actionButton: {
    flex: 1,
    padding: 12,
    borderRadius: 12,
    bottom: 20,
    alignItems: 'center',
    justifyContent: 'center',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 6,
  },
  saveButton: {
    backgroundColor: '#4F46E5',
  },
  disabledButton: {
    backgroundColor: '#94A3B8',
  },
  buttonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 16,
  },
});

export default DailyMenuScreen;