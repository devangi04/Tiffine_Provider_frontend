import axios from 'axios';
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  FlatList,
  Alert,
  Modal,
  TextInput,
  ScrollView,
  Animated,
  RefreshControl,
  Dimensions
} from 'react-native';
import { useLocalSearchParams, useRouter, useNavigation } from 'expo-router';
import { Plus, Copy, Edit, Trash2, Send, ChevronLeft, ChevronDown, ChevronUp, Home, List, CheckCircle, Clock, User } from 'lucide-react-native';
import Header from '@/components/header';
import BottomNavBar from '@/components/navbar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { useAppSelector } from './store/hooks';

const API_BASE_URL = 'http://192.168.1.178:5000/api';
const DAYS = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
const DAY_NAMES = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

interface DishItem {
  _id: string;
  name: string;
  description: string;
  categoryId: string;
  isActive: boolean;
}

interface CategoryItem {
  _id: string;
  name: string;
  isDefault: boolean;
}

interface MenuItem {
  categoryId: string;
  dishIds: string[];
}

interface Menu {
  _id: string;
  day: string;
  items: MenuItem[];
  note: string;
  name: string;
  isActive: boolean;
  providerId: string;
  createdAt: string;
  updatedAt: string;
}

interface MenuWithPopulatedData extends Omit<Menu, 'items'> {
  items: {
    categoryId: CategoryItem;
    dishIds: DishItem[];
  }[];
}

interface MenuItemWithIds {
  categoryId: string;
  dishIds: string[];
}

const SavedMenusScreen: React.FC = () => {
  const params = useLocalSearchParams();
  const provider = useAppSelector((state) => state.provider);
  const providerId = provider.id;
  const router = useRouter();
  const navigation = useNavigation();
  
  const [menus, setMenus] = useState<MenuWithPopulatedData[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [activeNav, setActiveNav] = useState('Profile');
  const [error, setError] = useState<string | null>(null);
  const [selectedMenu, setSelectedMenu] = useState<MenuWithPopulatedData | null>(null);
  const [isDeleteModalVisible, setIsDeleteModalVisible] = useState(false);
  const [isDuplicateModalVisible, setIsDuplicateModalVisible] = useState(false);
  const [isEditModalVisible, setIsEditModalVisible] = useState(false);
  const [isPreviewModalVisible, setIsPreviewModalVisible] = useState(false);
  const [newDay, setNewDay] = useState('');
  const [specialNotes, setSpecialNotes] = useState('');
  const [refreshing, setRefreshing] = useState(false);
  const [editItems, setEditItems] = useState<MenuItemWithIds[]>([]);
  const [allDishes, setAllDishes] = useState<DishItem[]>([]);
  const [allCategories, setAllCategories] = useState<CategoryItem[]>([]);
  const [isDishLoading, setIsDishLoading] = useState(false);
  const [expandedDays, setExpandedDays] = useState<Record<string, boolean>>({});
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [editMenuName, setEditMenuName] = useState('');
  const navbarOpacity = new Animated.Value(1);
  const insets = useSafeAreaInsets();

  useEffect(() => {
    navigation.setOptions({
      headerShown: false,
    });
  }, [navigation]);

  useEffect(() => {
    if (!providerId) {
      router.push('/login');
      return;
    }

    fetchSavedMenus();
    fetchDishes();
    fetchCategories();
  }, [providerId]);

  const fetchCategories = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/category/provider/${providerId}`);
      if (response.data.success) {
        setAllCategories(response.data.data || []);
      } else {
        setAllCategories([]);
      }
    } catch (error) {
      console.error('Error fetching categories:', error);
      setAllCategories([]);
    }
  };

  const fetchDishes = async () => {
    try {
      setIsDishLoading(true);
      const response = await axios.get(`${API_BASE_URL}/dish/provider/${providerId}`);
      
      if (response.data.success) {
        const flatDishes: DishItem[] = [];
        
        if (response.data.data && Array.isArray(response.data.data)) {
          response.data.data.forEach((categoryGroup: any) => {
            if (categoryGroup?.dishes && Array.isArray(categoryGroup.dishes)) {
              categoryGroup.dishes.forEach((dish: any) => {
                if (dish && dish._id) {
                  flatDishes.push({
                    _id: dish._id,
                    name: dish.name || 'Unnamed Dish',
                    description: dish.description || '',
                    categoryId: categoryGroup.categoryId || '',
                    isActive: dish.isActive !== false
                  });
                }
              });
            }
          });
        }
        
        setAllDishes(flatDishes);
      } else {
        setAllDishes([]);
      }
    } catch (error) {
      console.error('Error fetching dishes:', error);
      if (axios.isAxiosError(error) && error.response?.status === 500) {
        setAllDishes([]);
      } else {
        Alert.alert('Error', 'Failed to load dishes');
      }
    } finally {
      setIsDishLoading(false);
    }
  };
 
  const fetchSavedMenus = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await axios.get(`${API_BASE_URL}/menu?providerId=${providerId}&isActive=true`);
      
      if (response.data.success) {
        const activeMenus = response.data.menus ? 
          response.data.menus.filter((menu: Menu) => menu && menu.isActive) : [];
        
        const menusWithPopulatedData = activeMenus.map((menu: Menu) => {
          if (!menu) return null;
          
          const populatedItems = (menu.items || []).map(item => ({
            categoryId: item?.categoryId || '',
            dishIds: item?.dishIds || [],
          })).filter(item => item.categoryId);
          
          return {
            ...menu,
            items: populatedItems,
            name: menu.name || 'Unnamed Menu',
            note: menu.note || ''
          };
        }).filter(menu => menu !== null) as MenuWithPopulatedData[];
        
        const sortedMenus = menusWithPopulatedData.sort((a: MenuWithPopulatedData, b: MenuWithPopulatedData) => 
          DAYS.indexOf(a.day) - DAYS.indexOf(b.day) || 
          new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
        );
        
        setMenus(sortedMenus);
        
        const initialExpanded: Record<string, boolean> = {};
        if (sortedMenus.length > 0) {
          initialExpanded[sortedMenus[0].day] = true;
        }
        setExpandedDays(initialExpanded);
      } else {
        setMenus([]);
      }
    } catch (error) {
      console.error('Error fetching menus:', error);
      if (axios.isAxiosError(error) && error.response?.status === 500) {
        setMenus([]);
        setError('No menus found');
      } else {
        setError('Failed to load menus. Please try again.');
      }
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const getDishName = (dishId: string): string => {
    if (!dishId || !allDishes || allDishes.length === 0) return 'Unknown Dish';
    
    const dish = allDishes.find(d => d._id === dishId);
    return dish ? dish.name : 'Unknown Dish';
  };

  const getCategoryName = (categoryId: string) => {
    if (!categoryId || !allCategories || allCategories.length === 0) return 'Unknown Category';
    
    const category = allCategories.find(cat => cat._id === categoryId);
    return category ? category.name : 'Unknown Category';
  };

  const handleRefresh = () => {
    setRefreshing(true);
    fetchSavedMenus();
  };

  const toggleDay = (day: string) => {
    setExpandedDays(prev => ({
      ...prev,
      [day]: !prev[day]
    }));
  };

  const markAsSent = async (menuId: string) => {
    try {
      await axios.patch(`${API_BASE_URL}/menu/${menuId}/mark-sent`);
      fetchSavedMenus();
      Alert.alert('Success', 'Menu marked as sent successfully');
    } catch (error) {
      console.error('Error marking menu as sent:', error);
      Alert.alert('Error', 'Failed to mark menu as sent');
    }
  };

  const deleteMenu = async () => {
    if (!selectedMenu) return;
    try {
      await axios.delete(`${API_BASE_URL}/menu/${selectedMenu._id}`);
      setIsDeleteModalVisible(false);
      fetchSavedMenus();
      Alert.alert('Success', 'Menu deleted successfully');
    } catch (error) {
      console.error('Error deleting menu:', error);
      Alert.alert('Error', 'Failed to delete menu');
    }
  };

  const handleDuplicatePreview = async (day: string) => {
    if (!selectedMenu) return;
    
    try {
      const response = await axios.post(
        `${API_BASE_URL}/menu/${selectedMenu._id}/duplicate`, 
        { 
          day: day,
          name: `Copy of ${editMenuName || selectedMenu.name || 'Menu'}`
        }
      );
      
      if (response.data.success) {
        setNewDay(day);
        setIsDuplicateModalVisible(false);
        fetchSavedMenus();
        Alert.alert('Success', 'Menu duplicated successfully!');
      }
    } catch (error) {
      console.error('Error duplicating menu:', error);
      Alert.alert('Error', 'Failed to duplicate menu');
    }
  };

  const groupMenusByDay = (menus: MenuWithPopulatedData[]) => {
    return menus.reduce((acc, menu) => {
      if (!menu || !menu.day) return acc;
      
      if (!acc[menu.day]) {
        acc[menu.day] = [];
      }
      acc[menu.day].push(menu);
      return acc;
    }, {} as Record<string, MenuWithPopulatedData[]>);
  };

  const setupEditModal = (menu: MenuWithPopulatedData) => {
    if (!menu) return;
    
    setSelectedMenu(menu);
    setEditMenuName(menu.name || '');
    setSpecialNotes(menu.note || '');
    
    const editItemsData: MenuItemWithIds[] = (menu.items || []).map(item => {
      if (!item) return null;
      
      return {
        categoryId: typeof item.categoryId === 'string' 
          ? item.categoryId 
          : (item.categoryId as any)?._id || item.categoryId,
        dishIds: (item.dishIds || []).map(dish => 
          typeof dish === 'string' ? dish : dish?._id
        ).filter(dishId => dishId)
      };
    }).filter(item => item !== null && item.categoryId) as MenuItemWithIds[];
    
    setEditItems(editItemsData);
    setIsEditModalVisible(true);
  };

  const updateMenu = async () => {
    if (!selectedMenu) return;
    try {
      await axios.put(`${API_BASE_URL}/menu`, {
        id: selectedMenu._id,
        items: editItems,
        note: specialNotes,
        name: editMenuName,
        providerId: selectedMenu.providerId,
        day: selectedMenu.day
      });
      setIsEditModalVisible(false);
      fetchSavedMenus();
      Alert.alert('Success', 'Menu updated successfully');
    } catch (error) {
      console.error('Error updating menu:', error);
      Alert.alert('Error', 'Failed to update menu');
    }
  };

  const getDishesForCategory = (categoryId: string) => {
    if (!categoryId || !allDishes || allDishes.length === 0) return [];
    return allDishes.filter(dish => dish.categoryId === categoryId && dish.isActive);
  };

  const renderDishSelection = (categoryId: string, title: string) => {
    const categoryDishes = getDishesForCategory(categoryId);
    const categoryEditItems = editItems.find(item => item.categoryId === categoryId);
    const selectedDishIds = categoryEditItems ? categoryEditItems.dishIds : [];
    
    return (
      <View style={styles.dishCategoryContainer}>
        <Text style={styles.dishCategoryTitle}>{title}</Text>
        <View style={styles.dishList}>
          {categoryDishes.map(dish => (
            <TouchableOpacity
              key={dish._id}
              style={[
                styles.dishItem,
                selectedDishIds.includes(dish._id) && styles.selectedDishItem
              ]}
              onPress={() => {
                const newEditItems = [...editItems];
                const categoryIndex = newEditItems.findIndex(item => item.categoryId === categoryId);
                
                if (categoryIndex === -1) {
                  newEditItems.push({
                    categoryId,
                    dishIds: [dish._id]
                  });
                } else {
                  if (newEditItems[categoryIndex].dishIds.includes(dish._id)) {
                    newEditItems[categoryIndex].dishIds = newEditItems[categoryIndex].dishIds.filter(id => id !== dish._id);
                  } else {
                    newEditItems[categoryIndex].dishIds = [...newEditItems[categoryIndex].dishIds, dish._id];
                  }
                  
                  if (newEditItems[categoryIndex].dishIds.length === 0) {
                    newEditItems.splice(categoryIndex, 1);
                  }
                }
                
                setEditItems(newEditItems);
              }}
            >
              <Text style={[
                styles.dishText,
                selectedDishIds.includes(dish._id) && styles.selectedDishText
              ]}>
                {dish.name}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    );
  };

  const handleNavigation = (screenName: string) => {
    setActiveNav(screenName);
  };

  const getMenuCountForDay = (day: string) => {
    const grouped = groupMenusByDay(menus);
    return grouped[day] ? grouped[day].length : 0;
  };

  const renderMenuCard = ({ item }: { item: MenuWithPopulatedData }) => {
    if (!item) return null;
    
    const dayName = item.day ? item.day.charAt(0).toUpperCase() + item.day.slice(1) : 'Unknown Day';
    
    return (
      <TouchableOpacity style={[styles.menuCard]}>
        <View style={styles.menuHeader}>
          <View style={styles.menuInfo}>
            <Text style={styles.menuName}>{item.name || 'Unnamed Menu'}</Text>
            <Text style={styles.menuTime}>
              {item.createdAt ? new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Unknown time'}
            </Text>
          </View>
        </View>
        
        <View style={styles.menuItems}>
          {item.items && item.items.map((categoryItem, index) => {
            if (!categoryItem) return null;
            
            const categoryId = typeof categoryItem.categoryId === 'string' 
              ? categoryItem.categoryId 
              : (categoryItem.categoryId as any)?._id || categoryItem.categoryId;
            
            if (!categoryId) return null;
            
            const categoryName = getCategoryName(categoryId);
            
            const dishNames = (categoryItem.dishIds || []).map(dish => {
              if (typeof dish === 'string') {
                return getDishName(dish) || 'Unknown Dish';
              } else {
                return dish?.name || 'Unknown Dish';
              }
            }).filter(name => name);
            
            return (
              <View key={`${item._id}-category-${index}`} style={styles.menuCategory}>
                <Text style={styles.categoryLabel}>
                  {categoryName.toUpperCase()}:
                </Text>
                <Text style={styles.categoryItems}>
                  {dishNames.length > 0 ? dishNames.join(', ') : 'None'}
                </Text>
              </View>
            );
          })}
        </View>
        
        {item.note && (
          <View style={styles.specialNotes}>
            <Text style={styles.specialNotesText}>📝 {item.note}</Text>
          </View>
        )}

        <View style={styles.menuActions}>
          <TouchableOpacity 
            style={[styles.actionBtn, styles.duplicateBtn]} 
            onPress={(e) => {
              e.stopPropagation();
              setSelectedMenu(item);
              setIsDuplicateModalVisible(true);
            }}
          >
            <Copy size={16} color="#10B981" />
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.actionBtn, styles.editBtn]} 
            onPress={(e) => {
              e.stopPropagation();
              setupEditModal(item);
            }}
          >
            <Edit size={16} color="#F59E0B" />
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.actionBtn, styles.deleteBtn]} 
            onPress={(e) => {
              e.stopPropagation();
              setSelectedMenu(item);
              setIsDeleteModalVisible(true);
            }}
          >
            <Trash2 size={16} color="#EF4444" />
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    );
  };

  const renderDayAccordion = (day: string, dayMenus: MenuWithPopulatedData[]) => {
    const isExpanded = expandedDays[day] || false;
    const dayName = day ? day.charAt(0).toUpperCase() + day.slice(1) : 'Unknown Day';
    const menuCount = dayMenus.length;
    
    return (
      <View key={day} style={styles.dayAccordion}>
        <TouchableOpacity 
          style={[styles.dayHeader, isExpanded && styles.dayHeaderExpanded]}
          onPress={() => toggleDay(day)}
          activeOpacity={0.7}
        >
          <View>
            <Text style={styles.dayTitle}>{dayName}</Text>
            <Text style={styles.dayMeta}>{menuCount} menus</Text>
          </View>
          {isExpanded ? (
            <ChevronUp size={20} color="#64748B" />
          ) : (
            <ChevronDown size={20} color="#64748B" />
          )}
        </TouchableOpacity>
        
        {isExpanded && (
          <ScrollView 
            style={[styles.dayContent, isExpanded && styles.dayContentExpanded]}
            nestedScrollEnabled={true}
            showsVerticalScrollIndicator={true}
          >
            {dayMenus.map(menu => (
              <View key={menu._id}>
                {renderMenuCard({ item: menu })}
              </View>
            ))}
          </ScrollView>
        )}
      </View>
    );
  };

  const renderEditModal = () => (
    <Modal
      visible={isEditModalVisible}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setIsEditModalVisible(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.editModalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Edit Menu</Text>
            <TouchableOpacity 
              onPress={() => setIsEditModalVisible(false)}
              style={styles.closeButton}
            >
              <Icon name="close" size={24} color="#64748B" />
            </TouchableOpacity>
          </View>

          <ScrollView 
            style={styles.editModalScroll}
            showsVerticalScrollIndicator={false}
          >
            {isDishLoading ? (
              <ActivityIndicator size="large" color="#4F46E5" style={styles.loader} />
            ) : (
              <>
                <View style={styles.nameSection}>
                  <Text style={styles.sectionTitle}>Menu Name</Text>
                  <TextInput
                    style={styles.nameInput}
                    value={editMenuName}
                    onChangeText={setEditMenuName}
                    placeholder="Enter menu name..."
                    maxLength={50}
                  />
                </View>

                <Text style={styles.sectionTitle}>Dish Selection</Text>
                <View style={styles.dishCategoriesContainer}>
                  {allCategories.map(category => (
                    <View key={category._id} style={styles.categorySection}>
                      <Text style={styles.categoryTitle}>{category.name}</Text>
                      <View style={styles.dishSelectionGrid}>
                        {getDishesForCategory(category._id).map(dish => {
                          const categoryEditItems = editItems.find(item => item.categoryId === category._id);
                          const isSelected = categoryEditItems ? categoryEditItems.dishIds.includes(dish._id) : false;
                          
                          return (
                            <TouchableOpacity
                              key={dish._id}
                              style={[
                                styles.dishOption,
                                isSelected && styles.selectedDishOption
                              ]}
                              onPress={() => {
                                const newEditItems = [...editItems];
                                const categoryIndex = newEditItems.findIndex(item => item.categoryId === category._id);
                                
                                if (categoryIndex === -1) {
                                  newEditItems.push({
                                    categoryId: category._id,
                                    dishIds: [dish._id]
                                  });
                                } else {
                                  if (newEditItems[categoryIndex].dishIds.includes(dish._id)) {
                                    newEditItems[categoryIndex].dishIds = newEditItems[categoryIndex].dishIds.filter(id => id !== dish._id);
                                  } else {
                                    newEditItems[categoryIndex].dishIds = [...newEditItems[categoryIndex].dishIds, dish._id];
                                  }
                                  
                                  if (newEditItems[categoryIndex].dishIds.length === 0) {
                                    newEditItems.splice(categoryIndex, 1);
                                  }
                                }
                                
                                setEditItems(newEditItems);
                              }}
                            >
                              <Text 
                                style={[
                                  styles.dishOptionText,
                                  isSelected && styles.selectedDishOptionText
                                ]}
                                numberOfLines={1}
                              >
                                {dish.name}
                              </Text>
                            </TouchableOpacity>
                          );
                        })}
                      </View>
                    </View>
                  ))}
                </View>

                <View style={styles.notesSection}>
                  <Text style={styles.sectionTitle}>Special Notes</Text>
                  <TextInput
                    style={styles.notesInput}
                    value={specialNotes}
                    onChangeText={setSpecialNotes}
                    placeholder="Add any special notes or instructions..."
                    multiline
                    numberOfLines={3}
                  />
                </View>
              </>
            )}
          </ScrollView>

          <View style={styles.modalActions}>
            <TouchableOpacity
              style={[styles.modalButton, styles.cancelButton]}
              onPress={() => setIsEditModalVisible(false)}
            >
              <Text style={styles.buttonText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.modalButton, styles.saveButton]}
              onPress={updateMenu}
            >
              <Text style={styles.buttonText}>Save</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );

  const renderDuplicateModal = () => (
    <Modal
      visible={isDuplicateModalVisible}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setIsDuplicateModalVisible(false)}
    >
      <View style={styles.modalContainer}>
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>Select Day to Duplicate To</Text>
          
          <View style={styles.dayPicker}>
            {DAYS.map((day, index) => (
              <TouchableOpacity
                key={day}
                style={[
                  styles.dayOption,
                  newDay === day && styles.selectedDayOption
                ]}
                onPress={() => handleDuplicatePreview(day)}
              >
                <Text style={[
                  styles.dayOptionText,
                  newDay === day && styles.selectedDayOptionText
                ]}>
                  {DAY_NAMES[index]}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
          
          <View style={styles.modalButtons}>
            <TouchableOpacity
              style={[styles.modalButton, styles.cancelButton]}
              onPress={() => setIsDuplicateModalVisible(false)}
            >
              <Text style={styles.buttonText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#4F46E5" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>{error}</Text>
        <TouchableOpacity
          style={styles.retryButton}
          onPress={fetchSavedMenus}
        >
          <Text style={styles.retryButtonText}>Retry</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const groupedMenus = groupMenusByDay(menus);
  const totalMenus = menus.length;

  return (
    <View style={styles.container}>
      <View style={styles.dropdownContainer}>
        <TouchableOpacity 
          style={styles.dropdownToggle}
          onPress={() => setIsDropdownOpen(!isDropdownOpen)}
        >
          <View style={styles.dropdownToggleInner}>
            <Text style={styles.dropdownToggleText}>
              {selectedFilter === 'all' ? 'All Days' : DAY_NAMES[DAYS.indexOf(selectedFilter)]}
            </Text>
            <Text style={styles.dayCount}>{selectedFilter === 'all' ? totalMenus : getMenuCountForDay(selectedFilter)}</Text>
          </View>
        </TouchableOpacity>
        
        {isDropdownOpen && (
          <View style={styles.dropdownMenu}>
            <TouchableOpacity
              style={[styles.dropdownItem, selectedFilter === 'all' && styles.activeDropdownItem]}
              onPress={() => {
                setSelectedFilter('all');
                setIsDropdownOpen(false);
              }}
            >
              <Text style={styles.dropdownItemText}>All Days</Text>
              <Text style={styles.dayCount}>{totalMenus}</Text>
            </TouchableOpacity>
            
            {DAYS.map((day, index) => {
              const count = getMenuCountForDay(day);
              if (count > 0) {
                return (
                  <TouchableOpacity
                    key={day}
                    style={[styles.dropdownItem, selectedFilter === day && styles.activeDropdownItem]}
                    onPress={() => {
                      setSelectedFilter(day);
                      setIsDropdownOpen(false);
                    }}
                  >
                    <Text style={styles.dropdownItemText}>{DAY_NAMES[index]}</Text>
                    <Text style={styles.dayCount}>{count}</Text>
                  </TouchableOpacity>
                );
              }
              return null;
            })}
          </View>
        )}
      </View>
      
      <ScrollView
        contentContainerStyle={styles.scrollContainer}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
            colors={['#4F46E5']}
          />
        }
      >
        {menus.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyIcon}>🍽️</Text>
            <Text style={styles.emptyTitle}>No Menus Found</Text>
            <Text style={styles.emptySubtitle}>Create your first weekly menu to get started</Text>
            <TouchableOpacity
              style={styles.createMenuBtn}
              onPress={() => router.push('/menu')}
            >
              <Plus size={18} color="#fff" />
              <Text style={styles.createMenuBtnText}>Create New Menu</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.menuSection}>
            {selectedFilter === 'all' ? (
              DAYS.map(day => {
                const dayMenus = groupedMenus[day] || [];
                if (dayMenus.length > 0) {
                  return renderDayAccordion(day, dayMenus);
                }
                return null;
              })
            ) : (
              groupedMenus[selectedFilter] && renderDayAccordion(selectedFilter, groupedMenus[selectedFilter])
            )}
          </View>
        )}
      </ScrollView>

      <Modal
        visible={isDeleteModalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setIsDeleteModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Delete Menu</Text>
            <Text style={styles.modalText}>
              Are you sure you want to delete this menu? This action cannot be undone.
            </Text>
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setIsDeleteModalVisible(false)}
              >
                <Text style={styles.buttonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.deleteButton]}
                onPress={deleteMenu}
              >
                <Text style={styles.buttonText}>Delete</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {renderEditModal()}
      {renderDuplicateModal()}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  scrollContainer: {
    paddingBottom: 140,
  },
  headerSection: {
    backgroundColor: '#2c95f8',
    paddingHorizontal: 24,
    paddingBottom: 20,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    overflow: 'hidden',
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 1,
    marginTop: 15,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop:40,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  addButton: {
    width: 40,
    height: 40,
    top:20,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitleContainer: {
    flex: 1,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '600',
    marginTop:40,
    color: '#fff',
  },
  headerSubtitle: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  dropdownContainer: {
    paddingHorizontal: 24,
    paddingVertical: 15,
    paddingTop: 10,
    marginTop: 3,
    marginBottom: 16,
    zIndex: 10,
    backgroundColor: '#F8FAFC',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  dropdownToggle: {
    backgroundColor: 'rgba(120, 142, 253, 0.11)',
    borderRadius: 14,
    padding: 14,
  },
  dropdownToggleInner: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  dropdownToggleText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
  },
  dayCount: {
    backgroundColor: 'rgba(0, 0, 0, 0.05)',
    borderRadius: 10,
    paddingHorizontal: 8,
    paddingVertical: 2,
    fontSize: 12,
    fontWeight: '500',
    color: '#555',
  },
  dropdownMenu: {
    backgroundColor: 'rgba(255, 255, 255, 0.98)',
    borderRadius: 14,
    marginTop: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 14,
    elevation: 5,
    maxHeight: 300,
  },
  dropdownItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
  },
  activeDropdownItem: {
    backgroundColor: 'rgba(85, 95, 184, 0.1)',
    borderRadius:14,
  },
  dropdownItemText: {
    fontSize: 15,
    color: '#333',
  },
  menuSection: {
    padding: 15,
  },
  dayAccordion: {
    marginBottom: 16,
  },
  dayHeader: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: 'rgba(0, 0, 0, 0.05)',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  dayHeaderExpanded: {
    borderBottomLeftRadius: 0,
    borderBottomRightRadius: 0,
  },
  dayTitle: {
    fontSize: 17,
    fontWeight: '600',
    color: '#333',
  },
  dayMeta: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  dayContent: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: 'rgba(0, 0, 0, 0.05)',
    borderTopWidth: 0,
    borderBottomLeftRadius: 16,
    borderBottomRightRadius: 16,
    maxHeight: 0,
    overflow: 'hidden',
  },
  dayContentExpanded: {
    maxHeight: 400,
    paddingHorizontal: 18,
    paddingBottom: 18,
  },
  menuCard: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 18,
    marginVertical: 14,
    borderWidth: 1,
    borderColor: 'rgba(0, 0, 0, 0.04)',
    position: 'relative',
    overflow: 'hidden',
  },
  sentMenuCard: {
    borderLeftWidth: 4,
    borderLeftColor: '#2c95f8',
  },
  menuHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 14,
  },
  menuInfo: {
    flex: 1,
  },
  menuName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e293b',
    marginBottom: 4,
  },
  menuTime: {
    fontSize: 12,
    color: '#64748b',
  },
  sentBadge: {
    backgroundColor: '#10B981',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    gap: 4,
  },
  sentBadgeText: {
    color: '#fff',
    fontSize: 11,
    fontWeight: '600',
  },
  menuItems: {
    marginBottom: 14,
  },
  menuCategory: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  categoryLabel: {
    fontWeight: '600',
    color: '#32C0DA',
    fontSize: 12,
    minWidth: 60,
    textTransform: 'uppercase',
  },
  categoryItems: {
    color: '#475569',
    fontSize: 14,
    flex: 1,
  },
  specialNotes: {
    backgroundColor: 'rgba(245, 158, 11, 0.08)',
    padding: 12,
    borderRadius: 10,
    marginBottom: 14,
    borderLeftWidth: 3,
    borderLeftColor: '#f59e0b',
  },
  specialNotesText: {
    color: '#d97706',
    fontSize: 13,
  },
  menuActions: {
    flexDirection: 'row',
    gap: 8,
    justifyContent: 'flex-end',
  },
  actionBtn: {
    width: 32,
    height: 32,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 1,
  },
  sendBtn: {
    borderWidth: 1,
    borderColor: 'rgba(59, 130, 246, 0.3)',
  },
  duplicateBtn: {
    borderWidth: 1,
    borderColor: 'rgba(16, 185, 129, 0.3)',
  },
  editBtn: {
    borderWidth: 1,
    borderColor: 'rgba(245, 158, 11, 0.3)',
  },
  deleteBtn: {
    borderWidth: 1,
    borderColor: 'rgba(239, 68, 68, 0.3)',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    padding: 20,
  },
  modalContent: {
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 20,
    width: '90%',
    flex:0,
  },
  modalScrollContent: {
    flexGrow:1,
    paddingBottom: 20,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#1e293b',
  },
  modalText: {
    fontSize: 16,
    marginBottom: 20,
    textAlign: 'center',
    color: '#64748b',
  },
  modalLabel: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
    color: '#374151',
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    padding: 20,
  },
  editModalContainer: {
    backgroundColor: 'white',
    borderRadius: 16,
    width: '90%',
    maxHeight: '80%',
    overflow: 'hidden',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  closeButton: {
    padding: 4,
  },
  editModalScroll: {
    maxHeight: '70%',
    paddingHorizontal: 16,
  },
  loader: {
    padding: 30,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginTop: 16,
    marginBottom: 12,
  },
  dishCategoriesContainer: {
    marginBottom: 16,
  },
  categorySection: {
    marginBottom: 16,
  },
  categoryTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: '#4B5563',
    marginBottom: 8,
  },
  dishSelectionGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  dishOption: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  selectedDishOption: {
    backgroundColor: '#32C0DA',
    borderColor: '#32C0DA',
  },
  dishOptionText: {
    fontSize: 14,
    color: '#64748B',
    maxWidth: 120,
  },
  selectedDishOptionText: {
    color: 'white',
    fontWeight: '500',
  },
  notesSection: {
    marginBottom: 16,
  },
  notesInput: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 12,
    padding: 12,
    minHeight: 100,
    textAlignVertical: 'top',
    backgroundColor: '#F9FAFB',
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#E2E8F0',
    gap: 12,
  },
  modalButton: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    minWidth: 100,
    alignItems: 'center',
  },
  cancelButton: {
    backgroundColor: '#F3F4F6',
  },
  saveButton: {
    backgroundColor: '#32C0DA',
  },
  buttonText: {
    fontWeight: '600',
    fontSize: 14,
  },
  cancelButtonText: {
    color: '#374151',
  },
  saveButtonText: {
    color: 'white',
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#d1d5db',
    borderRadius: 12,
    padding: 12,
    marginBottom: 20,
    minHeight: 80,
    textAlignVertical: 'top',
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  deleteButton: {
    backgroundColor: '#EF4444',
  },
  dishCategoryContainer: {
    marginBottom: 20,
  },
  dishCategoryTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 10,
    color: '#374151',
  },
  dishList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  dishItem: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  selectedDishItem: {
    backgroundColor: '#4F46E5',
    borderColor: '#4F46E5',
  },
  dishText: {
    fontSize: 14,
    color: '#64748b',
  },
  selectedDishText: {
    color: 'white',
    fontWeight: '500',
  },
  dayPicker: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    marginBottom: 20,
    gap: 8,
  },
  dayOption: {
    padding: 12,
    borderRadius: 12,
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    minWidth: 100,
    alignItems: 'center',
  },
  selectedDayOption: {
    backgroundColor: '#4F46E5',
    borderColor: '#4F46E5',
  },
  dayOptionText: {
    color: '#64748b',
    fontWeight: '500',
  },
  selectedDayOptionText: {
    color: 'white',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    fontSize: 16,
    color: '#EF4444',
    textAlign: 'center',
    marginBottom: 20,
  },
  retryButton: {
    backgroundColor: '#4F46E5',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
  },
  retryButtonText: {
    color: 'white',
    fontWeight: '600',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
    marginTop: 50,
  },
  emptyIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
    marginBottom: 24,
  },
  createMenuBtn: {
    backgroundColor: '#4F46E5',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
    gap: 8,
  },
  createMenuBtnText: {
    color: 'white',
    fontWeight: '600',
    fontSize: 16,
  },
  floatingBtn: {
    position: 'absolute',
    bottom: 110,
    right: 20,
    backgroundColor: '#4F46E5',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 30,
    gap: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
  btnText: {
    color: 'white',
    fontWeight: '600',
    fontSize: 16,
  },
  bottomNavbar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
    paddingVertical: 12,
    paddingHorizontal: 20,
    justifyContent: 'space-around',
  },
  navItem: {
    alignItems: 'center',
    padding: 8,
  },
  activeNavItem: {
    backgroundColor: 'rgba(79, 70, 229, 0.1)',
    borderRadius: 12,
  },
  navLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
  },
  activeNavLabel: {
    color: '#4F46E5',
    fontWeight: '600',
  },
  nameSection: {
    marginBottom: 16,
  },
  nameInput: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 12,
    padding: 12,
    backgroundColor: '#F9FAFB',
    fontSize: 16,
  },
});

export default SavedMenusScreen;