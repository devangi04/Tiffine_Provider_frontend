// ProfileScreen.tsx - Updated useEffect and state logic
import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  ActivityIndicator,
  Alert,
  ScrollView,
  SafeAreaView
} from 'react-native';
import { useRouter, useNavigation } from 'expo-router';
import axios from 'axios';
import { AntDesign, Feather, MaterialIcons, Ionicons, FontAwesome6, MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppSelector, useAppDispatch } from './store/hooks';
import { clearProvider } from './store/slices/providerslice';
import { persistor } from './store/index';

interface Subscription {
  isActive: boolean;
  plan?: string;
}

interface Provider {
  id: string;
  name: string;
  email: string;
  phone: string;
  subscription?: Subscription | null;
}

const ProfileScreen = () => {
  const router = useRouter();
  const navigation = useNavigation();
  const insets = useSafeAreaInsets();
  const dispatch = useAppDispatch();

  // Get provider data from Redux store
  const reduxProvider = useAppSelector((state) => state.provider);
  
  const [provider, setProvider] = useState<Provider | null>(null);
  const [loading, setLoading] = useState(true);
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  useEffect(() => {
    navigation.setOptions({
      headerShown: false,
    });
  }, [navigation]);

  // Fixed useEffect with better state handling
  useEffect(() => {
    const initializeProfile = async () => {
      try {
        setLoading(true);
        
        // Check if user is logged out or has invalid data
        if (!reduxProvider || !reduxProvider.id || reduxProvider.id === '') {
          console.log('No valid provider data - user likely logged out');
          setProvider(null);
          setLoading(false);
          return;
        }

        // If we have valid provider data in Redux, use it
        if (reduxProvider.id && reduxProvider.email) {
          console.log('Using Redux provider data');
          setProvider({
            id: reduxProvider.id,
            name: reduxProvider.name || 'Provider',
            email: reduxProvider.email || '',
            phone: reduxProvider.phone || '',
            subscription: reduxProvider.subscription || null,
          });
        } else {
          // Fallback to API call if Redux data is incomplete
          await fetchProviderProfile();
        }
      } catch (error) {
        console.error('Error initializing profile:', error);
        setProvider(null);
      } finally {
        setLoading(false);
      }
    };

    initializeProfile();
  }, [reduxProvider]);

  const fetchProviderProfile = async () => {
    try {
      setLoading(true);
      
      // Additional safety check
      if (!reduxProvider || !reduxProvider.id) {
        console.log('Skipping profile fetch - no valid provider in Redux');
        setLoading(false);
        return;
      }
      
      const response = await axios.get<{
        success: boolean;
        data?: Provider;
        error?: string;
      }>('http://192.168.1.178:5000/api/providers/me', {
        withCredentials: true
      });
      
      if (response.data.success && response.data.data) {
        setProvider(response.data.data);
      } else {
        throw new Error(response.data.error || 'Failed to fetch profile');
      }
    } catch (error) {
      console.error('Profile fetch error:', error);
      
      // If we get a 401 error, clear provider and redirect to login
      if (error.response?.status === 401) {
        console.log('Session expired, redirecting to login');
        dispatch(clearProvider());
        router.replace('/login');
        return;
      }
      
      // Don't show alert for network errors during logout
      if (!isLoggingOut && error.response?.status !== 401) {
        Alert.alert('Error', 'Failed to load profile. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  // Improved logout function
  const handleLogout = async () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to log out?',
      [
        {
          text: 'Cancel',
          style: 'cancel'
        },
        {
          text: 'Logout',
          onPress: async () => {
            try {
              setIsLoggingOut(true);
              setLoading(true);
              
              // 1. Clear local state immediately
              setProvider(null);
              
              // 2. Clear Redux store
              dispatch(clearProvider());
              
              // 3. Try to call logout API (but don't block on it)
              try {
                await axios.post('http://192.168.1.178:5000/api/auth/logout', {}, {
                  withCredentials: true,
                  timeout: 3000
                });
              } catch (apiError) {
                console.log('Logout API call optional:', apiError);
                // Continue with cleanup even if API fails
              }
              
              // 4. Clear persisted storage
              await persistor.purge();
              
              // 5. Redirect to login with logout flag
              router.replace({
                pathname: '/login',
                params: { logout: 'true', timestamp: Date.now() }
              });
              
            } catch (error) {
              console.error('Logout error:', error);
              // Force redirect even if there's an error
              router.replace({
                pathname: '/login',
                params: { logout: 'true', timestamp: Date.now() }
              });
            } finally {
              setIsLoggingOut(false);
              setLoading(false);
            }
          }
        }
      ]
    );
  };

  // Navigation functions with safety checks
  const navigateToMenu = () => {
    if (!provider?.id && !reduxProvider?.id) {
      Alert.alert('Error', 'Please login again');
      router.replace('/login');
      return;
    }
    
    router.push({
      pathname: '/menu',
      params: { providerId: provider?.id || reduxProvider?.id }
    });
  };

  const navigateToDishMaster = () => {
    if (!provider?.id && !reduxProvider?.id) {
      Alert.alert('Error', 'Please login again');
      router.replace('/login');
      return;
    }
    
    router.push({
      pathname: '/dishmaster',
      params: { providerId: provider?.id || reduxProvider?.id }
    });
  };

  const navigateToCustomer = () => {
    if (!provider?.id && !reduxProvider?.id) {
      Alert.alert('Error', 'Please login again');
      router.replace('/login');
      return;
    }
    
    router.push({
      pathname: '/customer',
      params: { providerId: provider?.id || reduxProvider?.id }
    });
  };

  const navigateToSavedMenu = () => {
    if (!provider?.id && !reduxProvider?.id) {
      Alert.alert('Error', 'Please login again');
      router.replace('/login');
      return;
    }
    
    router.push({
      pathname: '/savedmenu',
      params: { providerId: provider?.id || reduxProvider?.id }
    });
  };

  // Show loading during logout
  if (loading || isLoggingOut) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2c95f8" />
        {isLoggingOut && <Text style={styles.loggingOutText}>Logging out...</Text>}
      </View>
    );
  }

  // Show login prompt if no provider data
  if (!provider) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>Please login to continue</Text>
        <TouchableOpacity
          style={styles.retryButton}
          onPress={() => router.replace('/login')}
        >
          <Text style={styles.retryButtonText}>Go to Login</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <ScrollView contentContainerStyle={styles.scrollContent}>
          {/* Profile Card */}
          <View style={styles.profileCard}>
            <View style={styles.profileInfo}>
              <View style={styles.profileAvatar}>
                <Text style={styles.avatarText}>
                  {provider.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                </Text>
              </View>
              <View style={styles.profileDetails}>
                <Text style={styles.profileName}>{provider.name}</Text>
                <Text style={styles.profileEmail}>{provider.email}</Text>
              </View>
            </View>
            <TouchableOpacity 
              style={styles.editButton}
              onPress={() => router.push('/edit')}
            >
              <MaterialIcons name="edit" size={20} color="#fff" />
            </TouchableOpacity>
          </View>

          {/* Menu Items */}
          <View style={styles.menuList}>
            <TouchableOpacity 
              style={styles.menuItem}
              onPress={navigateToMenu}
            >
              <View style={[styles.menuIcon, { backgroundColor: '#34c759' }]}>
                <FontAwesome6 name="bowl-food" size={24} color="white" />
              </View>
              <Text style={styles.menuText}>Create Menu</Text>
              <Feather name="chevron-right" size={20} color="#c7c7cc" />
            </TouchableOpacity>

            {/* ... other menu items ... */}

               <TouchableOpacity 
              style={styles.menuItem}
              onPress={navigateToDishMaster}
            >
              <View style={[styles.menuIcon, { backgroundColor: '#ff9500' }]}>
                <Ionicons name="stats-chart" size={20} color="#fff" />
              </View>
              <Text style={styles.menuText}>Dish Management</Text>
              <Feather name="chevron-right" size={20} color="#c7c7cc" />
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.menuItem}
              onPress={navigateToCustomer}
            >
              <View style={[styles.menuIcon, { backgroundColor: '#007aff' }]}>
                <MaterialCommunityIcons name="card-account-details-outline" size={24} color="white" />
              </View>
              <Text style={styles.menuText}>Clients Details</Text>
              <Feather name="chevron-right" size={20} color="#c7c7cc" />
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.menuItem}
              onPress={navigateToSavedMenu}
            >
              <View style={[styles.menuIcon, { backgroundColor: '#af52de' }]}>
                <FontAwesome6 name="save" size={24} color="white" />
              </View>
              <Text style={styles.menuText}>Saved Menu</Text>
              <Feather name="chevron-right" size={20} color="#c7c7cc" />
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.menuItem}
              onPress={() => router.push('/payment')}
            >
              <View style={[styles.menuIcon, { backgroundColor: '#5856d6' }]}>
                <MaterialIcons name="payment" size={24} color="white" />
              </View>
              <Text style={styles.menuText}>Payment</Text>
              <Feather name="chevron-right" size={20} color="#c7c7cc" />
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.menuItem}
              onPress={() => router.push('/subscriptionmanagement')}
            >
              <View style={[styles.menuIcon, { backgroundColor: '#5856d6' }]}>
                <MaterialIcons name="subscription" size={24} color="white" />
              </View>
              <Text style={styles.menuText}>Subscription details</Text>
              <Feather name="chevron-right" size={20} color="#c7c7cc" />
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.menuItem}
              onPress={handleLogout}
              disabled={isLoggingOut}
            >
              <View style={[styles.menuIcon, { backgroundColor: '#ff3b30' }]}>
                <AntDesign name="logout" size={20} color="#fff" />
              </View>
              <Text style={[styles.menuText, { color: '#ff3b30' }]}>
                {isLoggingOut ? 'Logging out...' : 'Log out'}
              </Text>
              <Feather name="chevron-right" size={20} color="#ff3b30" />
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
};

// Add new styles
const styles = StyleSheet.create({
  // ... your existing styles ...
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loggingOutText: {
    marginTop: 10,
    color: '#666',
    fontSize: 16,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    fontSize: 16,
    color: '#EF4444',
    marginBottom: 20,
  },
  retryButton: {
    backgroundColor: '#2c95f8',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  retryButtonText: {
    color: '#fff',
    fontWeight: '600',
  },
  retryButtonText: {
    color: '#fff',
    fontWeight: '600',
  },
  scrollContent: {
    paddingBottom: 80,
  },
  profileCard: {
    margin: 20,
    backgroundColor: '#2c95f8',
    borderRadius: 12,
    padding: 20,
    overflow: 'hidden',
    position: 'relative',
  },
  profileInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  profileAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  avatarText: {
    fontSize: 20,
    fontWeight: '600',
    color: '#2c95f8',
  },
  profileDetails: {
    flex: 1,
  },
  profileName: {
    fontSize: 22,
    fontWeight: '600',
    color: '#fff',
    marginBottom: 2,
  },
  profileEmail: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.9)',
    marginBottom: 2,
  },
  editButton: {
    position: 'absolute',
    top: 20,
    right: 20,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  menuList: {
    marginHorizontal: 20,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomWidth: 0.5,
    borderBottomColor: '#e5e5ea',
  },
  menuIcon: {
    width: 32,
    height: 32,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  menuText: {
    flex: 1,
    fontSize: 17,
    color: '#000',
  },
});

export default ProfileScreen;