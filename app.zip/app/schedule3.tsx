import axios from 'axios';
import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  Alert,
  ActivityIndicator,
  RefreshControl,
  Modal,
  Dimensions,
  Animated,
  Pressable,
  Platform,
  ScrollView
} from 'react-native';
import { useLocalSearchParams, useNavigation, useRouter } from 'expo-router';
import { Plus, Calendar, Copy, Edit, Trash2, Send, Check, X, ChevronDown, ChevronUp, History, ArrowBigRight } from 'lucide-react-native';
import BottomNavBar from '@/components/navbar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Header from '@/components/header';
import { LinearGradient } from 'expo-linear-gradient';
import { useAppSelector } from './store/hooks';
import { duration } from 'moment';
import PastHistory from '@/components/pasthistory';
const API_BASE_URL = 'http://192.168.1.178:5000/api';
const CATEGORY_API_URL = 'http://192.168.1.178:5000/api/category';
const DISH_API_URL = 'http://192.168.1.178:5000/api/dish';
const SENT_MENU_URL = 'http://192.168.1.178:5000/api/sentmenu';
const { width, height } = Dimensions.get('window');

interface DishItem {
  _id: string;
  name: string;
  description?: string;
  categoryId?: string | { _id: string; name: string };
  isActive?: boolean;
}

interface CategoryItem {
  _id: string;
  name: string;
  isDefault?: boolean;
}

interface MenuItem {
  categoryId: string | CategoryItem;
  dishIds: string[];
  _id: string;
}

interface Menu {
  _id: string;
  day: string;
  items: MenuItem[];
  note?: string;
  providerId: string;
  name: string;
  createdAt: string;
  isActive?: boolean;
}

interface DishCategory {
  _id: string;
  name: string;
  isActive: boolean;
  order?: number;
}

interface SentMenu {
  _id: string;
  providerId: string;
  menuId: string;
  menuName: string;
  day: string;
  items: {
    categoryId: string;
    categoryName: string;
    dishes: {
      dishId: string;
      dishName: string;
    }[];
  }[];
  note?: string;
  sentAt: string;
}

const DAYS = [
  { id: 'monday', name: 'Mon' },
  { id: 'tuesday', name: 'Tue' },
  { id: 'wednesday', name: 'Wed' },
  { id: 'thursday', name: 'Thu' },
  { id: 'friday', name: 'Fri' },
  { id: 'saturday', name: 'Sat' },
  { id: 'sunday', name: 'Sun' }
];

const ScheduleScreen: React.FC = () => {
  const params = useLocalSearchParams();
  const provider = useAppSelector((state) => state.provider);
  const providerId = provider.id;
  const router = useRouter();

  const [menus, setMenus] = useState<Menu[]>([]);
  const [categories, setCategories] = useState<DishCategory[]>([]);
  const [allDishes, setAllDishes] = useState<DishItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedDay, setSelectedDay] = useState<string>(DAYS[new Date().getDay() === 0 ? 6 : new Date().getDay() - 1].id);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedMenu, setSelectedMenu] = useState<Menu | null>(null);
  const [isDeleteModalVisible, setIsDeleteModalVisible] = useState(false);
  const [isDuplicateModalVisible, setIsDuplicateModalVisible] = useState(false);
  const [selectedMenuId, setSelectedMenuId] = useState<string | null>(null);
  const [activeNav, setActiveNav] = useState('schedule');
  const [historyLoading, setHistoryLoading] = useState<boolean>(false);
  const [menuHistory, setMenuHistory] = useState<{[key: string]: SentMenu[]}>({});
  const [expandedHistoryDays, setExpandedHistoryDays] = useState<{[key: string]: boolean}>({});
  const [sendingMenu, setSendingMenu] = useState<string | null>(null);
  
  const navbarOpacity = useRef(new Animated.Value(1)).current;
  const navbarTranslateY = useRef(new Animated.Value(0)).current;

  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  
  useEffect(() => {
    navigation.setOptions({
      headerShown: false,
    });
  }, [navigation]);
  
  useEffect(() => {
    if(!providerId){
      Alert.alert('Error','Provider not found. Please login again');
      router.push('/login');
      return;
    }
    fetchCategories();
    fetchAllDishes();
    fetchMenus();
  }, [providerId]);

  //for hide navbar when menu is selected 
  // useEffect(() => {
  //   if (selectedMenuId) {
  //     Animated.parallel([
  //       Animated.spring(navbarOpacity, {
  //         toValue: 0,
  //         useNativeDriver: true,
  //       }),
  //       Animated.spring(navbarTranslateY, {
  //         toValue: 100, // push it down out of screen
  //         useNativeDriver: true,
  //       }),
  //     ]).start();
  //   } else {
  //     Animated.parallel([
  //       Animated.spring(navbarOpacity, {
  //         toValue: 1,
  //         useNativeDriver: true,
  //       }),
  //       Animated.spring(navbarTranslateY, {
  //         toValue: 0, // bring back up
  //         useNativeDriver: true,
  //       }),
  //     ]).start();
  //   }
  // }, [selectedMenuId]);

  const transformDishesData = (data: any): DishItem[] => {
    const dishes: DishItem[] = [];
    
    if (data && Array.isArray(data)) {
      data.forEach((categoryGroup: any) => {
        if (categoryGroup.dishes && Array.isArray(categoryGroup.dishes)) {
          categoryGroup.dishes.forEach((dish: any) => {
            dishes.push({
              _id: dish._id,
              name: dish.name,
              description: dish.description,
              categoryId: categoryGroup.categoryId,
              isActive: dish.isActive !== false
            });
          });
        }
      });
    }
    
    return dishes;
  };

  const fetchCategories = async () => {
    try {
      const response = await axios.get(`${CATEGORY_API_URL}/provider/${providerId}`);
      if (response.data.success) {
        setCategories(response.data.data);
      }
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchAllDishes = async () => {
    try {
      const response = await axios.get(`${DISH_API_URL}/provider/${providerId}`);
      if (response.data.success) {
        const transformedDishes = transformDishesData(response.data.data);
        setAllDishes(transformedDishes);
      }
    } catch (error) {
      console.error('Error fetching dishes:', error);
    }
  };

  const fetchMenus = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await axios.get(`${API_BASE_URL}/menu?providerId=${providerId}`);
      
      if (response.data.success) {
        const menusData = response.data.menus || response.data.data || [];
        
        if (Array.isArray(menusData)) {
          const sortedMenus = menusData.sort((a: Menu, b: Menu) => 
            DAYS.findIndex(d => d.id === a.day) - DAYS.findIndex(d => d.id === b.day));
          setMenus(sortedMenus);
        } else {
          setError('Unexpected data format received');
        }
      } else {
        setError(response.data.message || 'Failed to load menus');
      }
    } catch (error) {
      console.error('Error fetching menus:', error);
      setError('Failed to load menus. Please check your connection.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const fetchMenuHistory = async (day: string) => {
    try {
      setHistoryLoading(true);
      const response = await axios.get(`${SENT_MENU_URL}?providerId=${providerId}&weeks=12`);
      
      if (response.data.success) {
        const sentMenus = response.data.data || [];
        
        const dayHistory = sentMenus
          .filter((menu: SentMenu) => menu.day === day)
          .sort((a: SentMenu, b: SentMenu) => 
            new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime()
          );
        
        setMenuHistory(prev => ({
          ...prev,
          [day]: dayHistory
        }));
      }
    } catch (error) {
      console.error('Error fetching menu history:', error);
      Alert.alert('Error', 'Failed to load menu history');
    } finally {
      setHistoryLoading(false);
    }
  };

  const sendMenu = async (menuId: string) => {
    try {
      setSendingMenu(menuId);
      const response = await axios.post(SENT_MENU_URL, {
        providerId,
        menuId
      });
      
      if (response.data.success) {
        showToast('Menu sent successfully!');
        setSelectedMenuId(null);
      } else {
        throw new Error(response.data.error || 'Failed to send menu');
      }
    } catch (error) {
      console.error('Error sending menu:', error);
      Alert.alert('Error', 'Failed to send menu. Please try again.');
    } finally {
      setSendingMenu(null);
    }
  };

  const toggleHistory = async (day: string) => {
    const isExpanded = expandedHistoryDays[day];
    
    if (!isExpanded && !menuHistory[day]) {
      await fetchMenuHistory(day);
    }
    
    setExpandedHistoryDays(prev => ({
      ...prev,
      [day]: !isExpanded
    }));
  };

  const handleRefresh = () => {
    setRefreshing(true);
    fetchMenus();
    fetchCategories();
    fetchAllDishes();
  };

  const getMenusForDay = (dayId: string) => {
    return menus.filter(menu => menu.day === dayId);
  };

  const toggleMenuSelection = (menuId: string) => {
    setSelectedMenuId(selectedMenuId === menuId ? null : menuId);
  };

  const deleteMenu = async () => {
    if (!selectedMenu) return;
    try {
      await axios.delete(`${API_BASE_URL}/menu/${selectedMenu._id}`);
      setIsDeleteModalVisible(false);
      fetchMenus();
      showToast('Menu deleted successfully!');
    } catch (error) {
      console.error('Error deleting menu:', error);
      Alert.alert('Error', 'Failed to delete menu');
    }
  };

  const handleNavigation = (screenName: string) => {
    setActiveNav(screenName);
  };

  const duplicateMenu = async (day: string) => {
    if (!selectedMenu) return;
    try {
      await axios.post(`${API_BASE_URL}/menu/${selectedMenu._id}/duplicate`, {
        day: day,
        name: `Copy of ${selectedMenu.name}`
      });
      setIsDuplicateModalVisible(false);
      fetchMenus();
      showToast('Menu duplicated successfully!');
    } catch (error) {
      console.error('Error duplicating menu:', error);
      Alert.alert('Error', 'Failed to duplicate menu');
    }
  };

  const showToast = (message: string) => {
    Alert.alert('Success', message);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getCategoryName = (categoryId: string | CategoryItem): string => {
    if (typeof categoryId === 'object' && categoryId !== null && categoryId.name) {
      return categoryId.name;
    }
    
    if (typeof categoryId === 'string') {
      const category = categories.find(cat => cat._id === categoryId);
      return category ? category.name : 'Unknown Category';
    }
    
    return 'Unknown Category';
  };

  const getDishName = (dishId: string): string => {
    if (!dishId) return 'Unknown Dish';
    
    const dish = allDishes.find(d => d._id === dishId);
    return dish ? dish.name : 'Unknown Dish';
  };

  const getDishNamesForCategory = (dishIds: string[]): string => {
    if (!dishIds || !Array.isArray(dishIds)) return 'No dishes';
    
    return dishIds.map(dishId => getDishName(dishId))
      .filter(name => name !== 'Unknown Dish')
      .join(', ') || 'No dishes';
  };

  const renderHistorySection = (day: string) => {
    if (!expandedHistoryDays[day]) return null;

    const history = menuHistory[day] || [];
    
    if (historyLoading) {
      return (
        <View style={styles.historyContainer}>
          <ActivityIndicator size="small" color="#2c95f8" />
          <Text style={styles.historyLoadingText}>Loading history...</Text>
        </View>
      );
    }

    if (history.length === 0) {
      return (
        <View style={styles.historyContainer}>
          <Text style={styles.noHistoryText}>No sent menus history available</Text>
        </View>
      );
    }

    return (
      <View style={styles.historyContainer}>
        <Text style={styles.historyTitle}>Sent Menu History</Text>
        {history.map((sentMenu, index) => (
          <View key={sentMenu._id || index} style={styles.historyItem}>
            <View style={styles.historyItemHeader}>
              <Text style={styles.historyMenuName} numberOfLines={1}>
                {sentMenu.menuName}
              </Text>
              <Text style={styles.historyDate}>
                {formatDate(sentMenu.sentAt)}
              </Text>
            </View>
            
            <View style={styles.historyContent}>
              {sentMenu.items && sentMenu.items.map((item, itemIndex) => (
                <Text key={itemIndex} style={styles.historyLine} numberOfLines={1}>
                  <Text style={styles.historyCategoryName}>
                    {item.categoryName}:
                  </Text>
                  <Text style={styles.historyDishNames}>
                    {item.dishes && item.dishes.length > 0 
                      ? item.dishes.map(d => getDishName(d.dishId)).join(', ')
                      : 'No dishes'
                    }
                  </Text>
                </Text>
              ))}
            </View>
            
            {sentMenu.note && (
              <Text style={styles.historyNote} numberOfLines={1}>
                📝 {sentMenu.note}
              </Text>
            )}
          </View>
        ))}
      </View>
    );
  };

  const renderDayTab = (day: typeof DAYS[0]) => {
    const isActive = day.id === selectedDay;
    const dayMenus = getMenusForDay(day.id);

    return (
     <LinearGradient
  key={day.id}
  colors={isActive ? ['#2c95f8', '#0022ff'] : ['transparent', 'transparent']}
  start={{ x: 0, y: 0 }}
  end={{ x: 1, y: 1 }}
  style={[styles.dayTab, isActive && styles.activeDayTab]}
>
  <TouchableOpacity
    style={styles.dayTabContent}
    onPress={() => {
      setSelectedDay(day.id);
      setSelectedMenuId(null);
    }}
    activeOpacity={0.9}
  >
    <Text style={[styles.dayText, isActive && styles.activeDayText]}>
      {day.name}
    </Text>
  </TouchableOpacity>

  {dayMenus.length > 0 && (
    <View
      style={[
        styles.menuCountBadge,
        isActive ? styles.activeMenuCountBadge : styles.inactiveMenuCountBadge,
      ]}
    >
      <Text
        style={[
          styles.menuCountText,
          isActive ? styles.activeMenuCountText : styles.inactiveMenuCountText,
        ]}
      >
        {dayMenus.length}
      </Text>
    </View>
  )}
</LinearGradient>

    );
  };

  const ActionButton = ({
    icon: Icon,
    onPress,
    color,
  }: {
    icon: React.ComponentType<{ size: number; color: string }>;
    onPress: () => void;
    color: string;
  }) => (
    <TouchableOpacity 
      style={[styles.actionButton, { backgroundColor: `${color}15`, borderColor: `${color}30` }]} 
      onPress={(e) => {
        e.stopPropagation();
        onPress();
      }}
    >
      <Icon size={18} color={color} />
    </TouchableOpacity>
  );

  const renderMenuCard = ({ item }: { item: Menu }) => {
    const isSelected = selectedMenuId === item._id;
    const hasDishes = item.items && item.items.some(menuItem => 
      menuItem.dishIds && menuItem.dishIds.length > 0
    );

    return (
      <Pressable 
        style={[styles.menuCard, isSelected && styles.selectedMenuCard]}
        onLongPress={() => {
          router.push({
            pathname: '/dishmaster',
            params: { menuId: item._id }
          });
        }}
        onPress={() => toggleMenuSelection(item._id)}
      >
        {isSelected && (
          <View style={styles.selectionIndicator}>
            <Check size={18} color="#fff" />
          </View>
        )}
        
        <View style={styles.menuHeader}>
          <View style={styles.menuTitleContainer}>
            <Text style={styles.menuName} numberOfLines={1}>{item.name}</Text>
            <Text style={styles.menuDay}>
              {item.day.charAt(0).toUpperCase() + item.day.slice(1)}
            </Text>
          </View>
          {/* <View style={styles.menuStatus}>
            <Text style={[styles.statusText, item.isActive ? styles.activeStatus : styles.inactiveStatus]}>
              {item.isActive ? 'Active' : 'Inactive'}
            </Text>
          </View> */}
        </View>
        
        <View style={styles.menuItemsContainer}>
          {item.items && item.items.map((menuItem, index) => (
            <View key={`${item._id}-${index}`} style={styles.menuItemRow}>
              <Text style={styles.menuItemCategory}>
                {getCategoryName(menuItem.categoryId).toUpperCase()}:
              </Text>
              <Text style={styles.dishNames} numberOfLines={1}>
                {getDishNamesForCategory(menuItem.dishIds)}
              </Text>
            </View>
          ))}
          
          {!hasDishes && (
            <View style={styles.noDishesContainer}>
              <Text style={styles.noDishesText}>No dishes added yet</Text>
            </View>
          )}
        </View>
        
        {item.note && (
          <View style={styles.specialNotes}>
            <Text style={styles.specialNotesText}>📝 {item.note}</Text>
          </View>
        )}

        <View style={styles.actionButtons}>
          <ActionButton icon={Copy} onPress={() => { setSelectedMenu(item); setIsDuplicateModalVisible(true); }} color="#10B981" />
          <ActionButton icon={Trash2} onPress={() => { setSelectedMenu(item); setIsDeleteModalVisible(true); }} color="#EF4444" />
        </View>
      </Pressable>
    );
  };

  const renderEmptyState = () => (
    <View style={styles.emptyContainer}>
      <Calendar size={48} color="#94A3B8" />
      <Text style={styles.emptyText}>
        No menus scheduled for {DAYS.find(d => d.id === selectedDay)?.name}
      </Text>
      <Text style={styles.emptySubtext}>
        Create a menu and add dishes to get started
      </Text>
      
      <TouchableOpacity 
        style={styles.historyToggleEmpty}
        onPress={() => toggleHistory(selectedDay)}
      >
        <History size={16} color="#64748B" />
        <Text style={styles.historyToggleText}>
          {expandedHistoryDays[selectedDay] ? 'Hide History' : 'Show Sent History'}
        </Text>
        {expandedHistoryDays[selectedDay] ? (
          <ChevronUp size={16} color="#64748B" />
        ) : (
          <ChevronDown size={16} color="#64748B" />
        )}
      </TouchableOpacity>
      
      {expandedHistoryDays[selectedDay] && renderHistorySection(selectedDay)}
      
      <TouchableOpacity
        style={styles.addButton}
        onPress={() => router.push({
          pathname: '/menu',
          params: { 
            providerId,
            defaultDay: selectedDay
          }
        })}
      >
        <Plus size={20} color="#fff" />
        <Text style={styles.addButtonText}>Create Menu</Text>
      </TouchableOpacity>
    </View>
  );

 const renderSelectionActions = () => {
  if (!selectedMenuId) return null;
  
  const menu = menus.find(m => m._id === selectedMenuId);
  if (!menu) return null;
  
  return (
    <Animated.View 
      style={[
        styles.selectionActionsContainer,
        {
          opacity: navbarOpacity,
          transform: [{ translateY: navbarTranslateY }],
          paddingBottom: Platform.OS === 'ios' ? Math.max(insets.bottom, 16) : 16,
        }
      ]}
    >
      <View style={styles.selectionActionsContent}>
        {/* Cancel Button */}
        <TouchableOpacity 
          style={[styles.selectionButton, styles.cancelSelectionButton]}
          onPress={() => setSelectedMenuId(null)}
          activeOpacity={0.8}
        >
          <X size={20} color="#64748B" />
          <Text style={styles.cancelSelectionText}>Cancel</Text>
        </TouchableOpacity>

        {/* Next Button */}
        <TouchableOpacity 
          style={[styles.selectionButton, styles.nextSelectionButton]}
          onPress={() => {
            router.push({
              pathname: '/menupreview',
              params: { 
                menuId: menu._id,
                providerId: providerId
              }
            });
          }}
          activeOpacity={0.8}
        >
          <Text style={styles.nextSelectionText}>Preview & Send</Text>
          <ArrowBigRight size={20} color="#fff" />
        </TouchableOpacity>
      </View>
    </Animated.View>
  );
};

  const renderContent = () => {
    const dayMenus = getMenusForDay(selectedDay);
    
    return (
      <View style={styles.contentContainer}>
        <FlatList
          data={dayMenus}
          renderItem={renderMenuCard}
          keyExtractor={(item) => item._id}
          contentContainerStyle={[
            styles.listContainer,
            dayMenus.length === 0 && styles.emptyListContainer
          ]}
          ListEmptyComponent={renderEmptyState}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={handleRefresh}
              colors={['#2c95f8']}
            />
          }
          ListHeaderComponent={
            <>
              {/* History Toggle Button - Now part of the scrollable content */}
              {dayMenus.length > 0 && (
                <TouchableOpacity 
                  style={styles.historyToggle}
                  onPress={() => toggleHistory(selectedDay)}
                >
                  <History size={16} color="#64748B" />
                  <Text style={styles.historyToggleText}>
                    {expandedHistoryDays[selectedDay] ? 'Hide History' : 'Show Sent History'}
                  </Text>
                  {expandedHistoryDays[selectedDay] ? (
                    <ChevronUp size={16} color="#64748B" />
                  ) : (
                    <ChevronDown size={16} color="#64748B" />
                  )}
                </TouchableOpacity>
              )}

              {/* History Section - Now part of the scrollable content */}
              {expandedHistoryDays[selectedDay] && renderHistorySection(selectedDay)}
            </>
          }
        />

        {renderSelectionActions()}
      </View>
    );
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2c95f8" />
        <Text style={styles.loadingText}>Loading menus...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>{error}</Text>
        <TouchableOpacity
          style={styles.retryButton}
          onPress={fetchMenus}
        >
          <Text style={styles.retryButtonText}>Retry</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* <Header
        title="Weekly Schedule"
        subtitle="Manage your schedule" 
        backgroundColor="#2c95f8"
        onBackPress={() => router.back()}
        onUserPress={() => router.push('/profile')}
      /> */}

      <View style={styles.daysContainer}>
        <View style={styles.daysGrid}>
          {DAYS.map(renderDayTab)}
        </View>
      </View>

      {renderContent()}

      {selectedMenuId && renderSelectionActions()}
      
      <Modal
        visible={isDeleteModalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setIsDeleteModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Delete Menu</Text>
            <Text style={styles.modalText}>
              Are you sure you want to delete "{selectedMenu?.name}"? This action cannot be undone.
            </Text>
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setIsDeleteModalVisible(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.deleteButton]}
                onPress={deleteMenu}
              >
                <Text style={styles.deleteButtonText}>Delete</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <Modal
        visible={isDuplicateModalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setIsDuplicateModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Duplicate "{selectedMenu?.name}"</Text>
            <Text style={styles.modalText}>
              Select a day to duplicate this menu to:
            </Text>
            
            <View style={styles.dayPicker}>
              {DAYS.filter(day => day.id !== selectedMenu?.day).map(day => (
                <TouchableOpacity
                  key={day.id}
                  style={styles.dayOption}
                  onPress={() => duplicateMenu(day.id)}
                >
                  <Text style={styles.dayOptionText}>{day.name}</Text>
                </TouchableOpacity>
              ))}
            </View>
            
            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setIsDuplicateModalVisible(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
      
      {/* {!selectedMenuId && (
        <BottomNavBar 
          activeNav={activeNav} 
          setActiveNav={handleNavigation}
          insets={insets}
        />
      )} */}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  contentContainer: {
    flex: 1,
  },
 selectionActionsContainer: {
    position: 'sticky',
    bottom: 25,
    left: 0,
//  paddingBottom:60,

    right: 0,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#E2E8F0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 8,
  },
  selectionActionsContent: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingTop: 16,
    gap: 12,
  },
  selectionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 12,
    gap: 8,
  },
  cancelSelectionButton: {
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    
  },
  nextSelectionButton: {
    backgroundColor: '#2c95f8',
    shadowColor: '#2c95f8',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  cancelSelectionText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#64748B',
  },
  nextSelectionText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },

  // Update listContainer to add padding for the action buttons
  listContainer: {
    paddingVertical: 12,
    paddingBottom: 100, // Increased padding to account for action buttons
  },
  buttonIcon: {
    marginLeft: 32,
  },
  daysContainer: {
    backgroundColor: '#F8FAFC',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(226, 232, 240, 0.5)',
    paddingHorizontal: 12,
    marginTop: 4,
    paddingBottom: 10,
    paddingTop: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 1,
  },
  daysGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  dayTab: {
    flex: 1,
    borderRadius: 12,
    marginHorizontal: 2,
    minHeight: 50,
    overflow: 'hidden',
  },
  dayTabContent: {
    flex: 1,
    padding: 6,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 12,
    position: 'relative',
  },
  activeDayTab: {
    shadowColor: '#2c95f8',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 3,
    transform: [{ translateY: -2 }],
  },
  dayText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748B',
  },
  activeDayText: {
    color: '#fff',
  },
menuCountBadge: {
  position: 'absolute',
  top: -1,       // inside from top
  right: 4,     // inside from right
  borderRadius: 12,
  paddingHorizontal: 6,
  paddingVertical: 2,
  minWidth: 20,
  alignItems: 'center',
  justifyContent: 'center',
  zIndex: 10,
},
inactiveMenuCountBadge: {
  backgroundColor: 'rgba(44, 149, 248, 0.15)',
},
inactiveMenuCountText: {
  color: '#2c95f8',
  fontSize: 10,
  fontWeight: '600',
},
activeMenuCountBadge: {
  backgroundColor: '#fff', 
  top: 1,   // keep it aligned inside
  right: 1,
},
activeMenuCountText: {
  color: '#2c95f8',
  fontSize: 10,
  fontWeight: '700',
},

  menuCountText: {
    fontSize: 10,
    fontWeight: '600',
    color: '#2c95f8',
    textAlign: 'center',  
  },
  listContainer: {
    paddingVertical: 12,
    paddingBottom: 100,
  },
  emptyListContainer: {
    flexGrow: 1,
    justifyContent: 'center',
  },
  menuCard: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    marginBottom: 16,
    marginHorizontal: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 20,
    elevation: 3,
    position: 'relative',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  selectedMenuCard: {
    borderColor: '#2c95f8',
    backgroundColor: '#F5F3FF',
    shadowColor: '#2c95f8',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 6,
  },
  selectionIndicator: {
    position: 'absolute',
    top: 12,
    right: 12,
    backgroundColor: '#2c95f8',
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1,
    borderWidth: 2,
    borderColor: '#fff',
  },
  menuHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  menuTitleContainer: {
    flex: 1,
    marginRight: 8,
  },
  menuName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1E293B',
    marginBottom: 4,
  },
  menuDay: {
    fontSize: 12,
    color: '#64748B',
  },
  menuStatus: {
    marginLeft: 8,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  activeStatus: {
    backgroundColor: '#D1FAE5',
    color: '#065F46',
  },
  inactiveStatus: {
    backgroundColor: '#FEE2E2',
    color: '#B91C1C',
  },
  menuItemsContainer: {
    marginBottom: 8,
  },
  menuItemRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
    paddingVertical: 4,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0, 0, 0, 0.05)',
  },
  menuItemCategory: {
    fontWeight: '600',
    color: '#2c95f8',
    fontSize: 13,
    flex: 1,
    textAlign: 'left',
  },
  dishNames: {
    fontSize: 14,
    color: '#475569',
    flex: 1,
    textAlign: 'right',
  },
  noDishesContainer: {
    padding: 12,
    backgroundColor: '#F1F5F9',
    borderRadius: 8,
    marginVertical: 8,
    alignItems: 'center',
  },
  noDishesText: {
    color: '#64748B',
    fontStyle: 'italic',
    fontSize: 14,
  },
  specialNotes: {
    marginTop: 12,
    padding: 8,
    backgroundColor: 'rgba(44, 149, 248, 0.05)',
    borderRadius: 8,
    borderLeftWidth: 3,
    borderLeftColor: '#2c95f8',
  },
  specialNotesText: {
    fontSize: 13,
    color: '#64748B',
    fontStyle: 'italic',
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 10,
    marginTop: 16,
  },
  actionButton: {
    padding: 8,
    borderRadius: 10,
    borderWidth: 1,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  emptyText: {
    fontSize: 18,
    color: '#64748B',
    marginBottom: 8,
    fontWeight: '500',
  },
  emptySubtext: {
    fontSize: 14,
    color: '#94A3B8',
    marginBottom: 16,
    textAlign: 'center',
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2c95f8',
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderRadius: 16,
    shadowColor: '#2c95f8',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
  addButtonText: {
    color: '#fff',
    marginLeft: 8,
    fontWeight: '600',
    fontSize: 16,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#64748B',
    fontWeight: '500',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    fontSize: 16,
    color: '#EF4444',
    marginBottom: 20,
    textAlign: 'center',
  },
  retryButton: {
    backgroundColor: '#2c95f8',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 8,
  },
  retryButtonText: {
    color: '#fff',
    fontWeight: '600',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    padding: 20,
  },
  modalContent: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 24,
    width: '100%',
    maxWidth: 400,
  },
  modalTitle: {
    fontSize: 22,
    fontWeight: '600',
    color: '#1E293B',
    marginBottom: 16,
  },
  modalText: {
    fontSize: 16,
    color: '#475569',
    marginBottom: 24,
    lineHeight: 24,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 12,
  },
  modalButton: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 12,
    alignItems: 'center',
  },
  cancelButton: {
    backgroundColor: '#E2E8F0',
  },
  deleteButton: {
    backgroundColor: '#EF4444',
  },
  cancelButtonText: {
    color: '#475569',
    fontWeight: '600',
    fontSize: 16,
  },
  deleteButtonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 16,
  },
  dayPicker: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: 12,
    marginBottom: 24,
  },
  dayOption: {
    padding: 16,
    borderRadius: 12,
    backgroundColor: 'rgba(44, 149, 248, 0.05)',
    alignItems: 'center',
    minWidth: 100,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  dayOptionText: {
    color: '#475569',
    fontWeight: '600',
  },
 historyToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 10,
     
    backgroundColor: '#F8FAFC',
    borderBottomLeftRadius: 12,
    borderBottomRightRadius: 12,
    marginHorizontal: 16,
    marginTop: 8,
  },
  historyToggleEmpty: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    backgroundColor: '#F8FAFC',
    borderRadius: 12,
    marginVertical: 12,
  },
  historyToggleText: {
    marginLeft: 8,
    marginRight: 4,
    color: '#64748B',
    fontSize: 14,
    fontWeight: '500',
  },
 historyContainer: {
    backgroundColor: '#F1F5F9',
    padding: 10,
    marginHorizontal: 16,
    marginBottom: 12,
    borderRadius: 8,
    borderTopLeftRadius: 0,
    borderTopRightRadius: 0,
  },
  historyItem: {
    backgroundColor: '#fff',
    padding: 8,
    borderRadius: 6,
    marginBottom: 6,
    borderLeftWidth: 2,
    borderLeftColor: '#2c95f8',
  },
  historyItemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  historyMenuName: {
    fontSize: 12,
    fontWeight: '600',
    color: '#1E293B',
    flex: 1,
  },
  historyDate: {
    fontSize: 10,
    color: '#64748B',
    fontWeight: '500',
    marginLeft: 8,
  },
  historyContent: {
    marginBottom: 4,
  },
  historyLine: {
    fontSize: 11,
    lineHeight: 14,
    marginBottom: 2,
  },
  historyCategoryName: {
    fontWeight: '600',
    color: '#2c95f8',
    marginRight: 4,
  },
  historyDishNames: {
    color: '#475569',
  },
  historyNote: {
    fontSize: 10,
    color: '#64748B',
    fontStyle: 'italic',
    paddingTop: 2,
    borderTopWidth: 1,
    borderTopColor: '#E2E8F0',
  },
  historyLoadingText: {
    fontSize: 12,
    color: '#64748B',
    textAlign: 'center',
    marginTop: 4,
  },
  noHistoryText: {
    fontSize: 12,
    color: '#64748B',
    textAlign: 'center',
    fontStyle: 'italic',
  },
 
});
// ... (keep the same styles as before)

export default ScheduleScreen;