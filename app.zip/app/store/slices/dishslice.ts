import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const API_BASE_URL = 'http://192.168.1.178:5000/api';
const DISH_API_URL = `${API_BASE_URL}/dish`;
const CATEGORY_API_URL = `${API_BASE_URL}/category`;

export const fetchDishesAndCategories = createAsyncThunk(
  'dish/fetchDishesAndCategories',
  async (providerId: string) => {
    const categoriesResponse = await axios.get(`${CATEGORY_API_URL}/provider/${providerId}`);
    const dishesResponse = await axios.get(`${DISH_API_URL}/provider/${providerId}`);
    return {
      categories: categoriesResponse.data.data || [],
      dishes: dishesResponse.data.data || [],
    };
  }
);

const dishSlice = createSlice({
  name: 'dish',
  initialState: {
    dishes: [] as any[],
    categories: [] as any[],
    loading: false,
    error: null as string | null,
  },
  reducers: {
    addDish: (state, action) => {
      state.dishes.push(action.payload);
    },
    updateDish: (state, action) => {
      const index = state.dishes.findIndex(d => d._id === action.payload._id);
      if (index !== -1) state.dishes[index] = action.payload;
    },
    deleteDish: (state, action) => {
      state.dishes = state.dishes.filter(d => d._id !== action.payload);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchDishesAndCategories.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchDishesAndCategories.fulfilled, (state, action) => {
        state.loading = false;
        state.categories = action.payload.categories;
        state.dishes = action.payload.dishes;
      })
      .addCase(fetchDishesAndCategories.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || 'Failed to fetch';
      });
  },
});

export const { addDish, updateDish, deleteDish } = dishSlice.actions;
export default dishSlice.reducer;
