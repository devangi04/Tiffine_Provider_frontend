// store/slices/providerSlice.ts
import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface Subscription {
  status: string;
  plan?: string;
  expiryDate?: string;
}

interface ProviderState {
  id: string | null;
  email: string | null;
  name: string | null;
  phone: string | null;
  subscription: Subscription | null;
  isLoading: boolean;
  error: string | null;
}

const initialState: ProviderState = {
  id: null,
  email: null,
  name: null,
  phone:null,
  subscription: null,
  isLoading: false,
  error: null,
};

const providerSlice = createSlice({
  name: 'provider',
  initialState,
  reducers: {
    setProvider: (state, action: PayloadAction<{
      id: string;
      email: string;
      name: string;
      phone:string;
      subscription: Subscription;
    }>) => {
      state.id = action.payload.id;
      state.email = action.payload.email;
      state.name = action.payload.name;
      state.phone = action.payload.phone;
      state.subscription = action.payload.subscription;
      state.error = null;
    },
    setLoading: (state, action: PayloadAction<boolean>) => {
      state.isLoading = action.payload;
    },
    setError: (state, action: PayloadAction<string | null>) => {
      state.error = action.payload;
    },
    clearProvider: (state) => {
      state.id = null;
      state.email = null;
      state.name = null;
      state.phone = null;
      state.subscription = null;
      state.error = null;
    },
    updateSubscription: (state, action: PayloadAction<Subscription>) => {
      if (state.subscription) {
        state.subscription = { ...state.subscription, ...action.payload };
      }
    },
  },
});

export const { 
  setProvider, 
  setLoading, 
  setError, 
  clearProvider, 
  updateSubscription 
} = providerSlice.actions;

export default providerSlice.reducer;