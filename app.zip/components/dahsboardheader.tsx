import React, { useState, useRef } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput, StatusBar, Platform } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons, Feather } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useAppSelector, useAppDispatch } from '../app/store/hooks';
import { fetchSearchResults, setSearchQuery, clearSearchQuery } from '../app/store/slices/searchslice';

interface DashboardHeaderProps {
  onSearch?: (text: string) => void;
}

const DashboardHeader: React.FC<DashboardHeaderProps> = ({ onSearch }) => {
  const router = useRouter();
  const dispatch = useAppDispatch();
  const provider = useAppSelector((state) => state.provider);
  const searchState = useAppSelector((state) => state.search);
  const providerName = provider.name || 'user';
  const [localSearchText, setLocalSearchText] = useState('');
  const searchTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const handleSearch = (text: string) => {
    setLocalSearchText(text);
    dispatch(setSearchQuery(text));
    
    if (onSearch) {
      onSearch(text);
    }

    // Clear previous timeout if exists
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
    }
    
    // Debounce search to avoid too many API calls
    if (text.trim().length > 0) {
      searchTimeoutRef.current = setTimeout(() => {
        dispatch(fetchSearchResults(text));
      }, 500); // 500ms debounce
    } else {
      // Clear search results when text is empty
      dispatch(clearSearchQuery());
    }
  };

  const clearSearch = () => {
    setLocalSearchText('');
    dispatch(clearSearchQuery());
    if (onSearch) {
      onSearch('');
    }
    // Clear any pending search timeout
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current);
    }
  };

  return (
    <>
      <LinearGradient
        colors={['#7190fa', '#09d6c8']}
        style={styles.headerSection}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      >
        <View style={styles.circleTop} />
        <View style={styles.circleBottom} />
        
        <View style={styles.headerContent}>
          <View>
            <Text style={styles.greeting}>Hey</Text>
            <Text style={styles.userName}>{providerName}!</Text>
          </View>
          <TouchableOpacity 
            style={styles.profileIcon}
            onPress={() => router.push('./profile')}
          >
            <Feather name="user" size={20} color="white" />
          </TouchableOpacity>
        </View>
        
        <View style={styles.searchBar}>
          {/* <Ionicons name="search" size={16} color="#666" style={styles.searchIcon} /> */}
          <TextInput
            style={styles.searchInput}
            placeholder="Search customers, dishes, menus, responses, bills..."
            placeholderTextColor="#888"
            onChangeText={handleSearch}
            value={localSearchText}
            returnKeyType="search"
          />
          {localSearchText.length > 0 && (
            <TouchableOpacity onPress={clearSearch}>
              <Ionicons name="close-circle" size={16} color="#666" />
            </TouchableOpacity>
          )}
        </View>
      </LinearGradient>
    </>
  );
};

// ... styles remain the same
const styles = StyleSheet.create({
  headerSection: {
    padding: 20,
    paddingTop: Platform.OS === 'ios' ? 70 : 60,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    overflow: 'hidden',
    position: 'relative',
  },
  circleTop: {
    position: 'absolute',
    top: -50,
    right: -50,
    width: 150,
    height: 150,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 100,
  },
  circleBottom: {
    position: 'absolute',
    bottom: -30,
    left: -30,
    width: 100,
    height: 100,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 100,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  greeting: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.9)',
    marginBottom: 4,
  },
  userName: {
    fontSize: 24,
    fontWeight: '600',
    color: 'white',
  },
  profileIcon: {
    width: 40,
    height: 40,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 30,
    paddingHorizontal: 16,
    height: 48,
  },
  searchIcon: {
    marginRight: 5,
    justifyContent:'center'
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: '#333',
  },
});

export default DashboardHeader;