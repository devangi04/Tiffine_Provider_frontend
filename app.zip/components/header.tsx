import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Platform, StatusBar } from 'react-native';
import { ArrowLeft, User } from 'lucide-react-native';
import { useRouter } from 'expo-router';

interface HeaderProps {
  title: string;
  subtitle?: string;
  showBackButton?: boolean;
  showUserButton?: boolean;
  onBackPress?: () => void;
  onUserPress?: () => void;
  backgroundColor?: string;
  textColor?: string;
  subtitleColor?: string;
  statusBarOverlay?: boolean; // ✅ NEW PROP
}

const Header: React.FC<HeanderProps> = ({
  title,
  subtitle,
  showBackButton = true,
  showUserButton = true,
  onBackPress,
  onUserPress,
  backgroundColor = '#32C0DA',
  textColor = '#fff',
  subtitleColor = 'rgba(255, 255, 255, 0.8)',
  statusBarOverlay = false, // ✅ default is false
}) => {
  const router = useRouter();

  const handleBackPress = () => {
    if (onBackPress) {
      onBackPress();
    } else {
      router.back();
    }
  };

  const handleUserPress = () => {
    if (onUserPress) {
      onUserPress();
    } else {
      router.push('/profile');
    }
  };

  return (
    <>
      {/* ✅ StatusBar reacts to statusBarOverlay prop */}
      <StatusBar
        translucent
        backgroundColor={statusBarOverlay ? 'rgba(0,0,0,0.5)' : 'transparent'}
        barStyle="light-content"
      />

      <View style={[styles.headerSection, { backgroundColor }]}>
        <View style={styles.headerContent}>
          {showBackButton ? (
            <TouchableOpacity
              style={styles.backButton}
              onPress={handleBackPress}
              activeOpacity={0.7}
            >
              <ArrowLeft size={24} color={textColor} />
            </TouchableOpacity>
          ) : (
            <View style={styles.backButtonPlaceholder} />
          )}

          <View style={styles.headerTitleContainer}>
            <Text style={[styles.headerTitle, { color: textColor }]}>{title}</Text>
            {subtitle && (
              <Text style={[styles.headerSubtitle, { color: subtitleColor }]}>{subtitle}</Text>
            )}
          </View>

          {showUserButton ? (
            <TouchableOpacity
              style={styles.backButton}
              onPress={handleUserPress}
              activeOpacity={0.7}
            >
              <User size={24} color={textColor} />
            </TouchableOpacity>
          ) : (
            <View style={styles.backButtonPlaceholder} />
          )}
        </View>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  headerSection: {
    paddingHorizontal: 24,
    paddingBottom: 40,
    paddingTop:Platform.OS ==='ios'? 10:10,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    overflow: 'hidden',
    
    // backgroundColor:'#f5f7fa',
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
     paddingTop: Platform.OS === 'ios' ? 10 : 10, // Adjusted for iOS
    marginTop: 55,
    // REMOVED: top: 20 and marginTop - these were causing the extra space
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  backButtonPlaceholder: {
    width: 40,
    height: 40,
  },
  headerTitleContainer: {
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 16,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '600',
    marginBottom: 4,
    textAlign: 'center',
  },
  headerSubtitle: {
    fontSize: 14,
    textAlign: 'center',
  },
});

export default Header;
