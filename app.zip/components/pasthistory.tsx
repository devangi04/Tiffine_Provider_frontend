import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  FlatList
} from 'react-native';
import { History, ChevronDown, ChevronUp } from 'lucide-react-native';

interface SentMenu {
  _id: string;
  providerId: string;
  menuId: string;
  menuName: string;
  day: string;
  items: {
    categoryId: string;
    categoryName: string;
    dishes: {
      dishId: string;
      dishName: string;
    }[];
  }[];
  note?: string;
  sentAt: string;
}

interface PastHistoryProps {
  history: SentMenu[];
  loading: boolean;
  isExpanded: boolean;
  onToggle: () => void;
  day: string;
  getDishName: (dishId: string) => string;
  formatDate: (dateString: string) => string;
}

const PastHistory: React.FC<PastHistoryProps> = ({
  history,
  loading,
  isExpanded,
  onToggle,
  day,
  getDishName,
  formatDate
}) => {
  const renderHistoryItem = ({ item, index }: { item: SentMenu; index: number }) => (
    <View key={item._id || index} style={styles.historyItem}>
      <View style={styles.historyItemHeader}>
        <Text style={styles.historyMenuName} numberOfLines={1}>
          {item.menuName}
        </Text>
        <Text style={styles.historyDate}>
          {formatDate(item.sentAt)}
        </Text>
      </View>
      
      <View style={styles.historyContent}>
        {item.items && item.items.map((menuItem, itemIndex) => (
          <Text key={itemIndex} style={styles.historyLine} numberOfLines={1}>
            <Text style={styles.historyCategoryName}>
              {menuItem.categoryName}:
            </Text>
            <Text style={styles.historyDishNames}>
              {menuItem.dishes && menuItem.dishes.length > 0 
                ? menuItem.dishes.map(d => getDishName(d.dishId)).join(', ')
                : 'No dishes'
              }
            </Text>
          </Text>
        ))}
      </View>
      
      {item.note && (
        <Text style={styles.historyNote} numberOfLines={1}>
          📝 {item.note}
        </Text>
      )}
    </View>
  );

  const renderEmptyState = () => (
    <View style={styles.emptyHistory}>
      <Text style={styles.noHistoryText}>No sent menus history available</Text>
    </View>
  );

  const renderLoadingState = () => (
    <View style={styles.loadingContainer}>
      <ActivityIndicator size="small" color="#2c95f8" />
      <Text style={styles.historyLoadingText}>Loading history...</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Toggle Button */}
      <TouchableOpacity 
        style={styles.toggleButton}
        onPress={onToggle}
      >
        <View style={styles.toggleContent}>
          <History size={16} color="#64748B" />
          <Text style={styles.toggleText}>
            {isExpanded ? 'Hide History' : 'Show Sent History'}
          </Text>
          {isExpanded ? (
            <ChevronUp size={16} color="#64748B" />
          ) : (
            <ChevronDown size={16} color="#64748B" />
          )}
        </View>
      </TouchableOpacity>

      {/* History Content */}
      {isExpanded && (
        <View style={styles.historyContainer}>
          {loading ? (
            renderLoadingState()
          ) : history.length === 0 ? (
            renderEmptyState()
          ) : (
            <>
              <Text style={styles.historyTitle}>Sent Menu History</Text>
              <FlatList
                data={history}
                renderItem={renderHistoryItem}
                keyExtractor={(item, index) => item._id || index.toString()}
                scrollEnabled={false}
                showsVerticalScrollIndicator={false}
              />
            </>
          )}
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginHorizontal: 16,
    marginBottom: 12,
  },
  toggleButton: {
    backgroundColor: '#F8FAFC',
    padding: 12,
    borderRadius: 12,
    borderBottomLeftRadius: 0,
    borderBottomRightRadius: 0,
  },
  toggleContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  toggleText: {
    marginLeft: 8,
    marginRight: 4,
    color: '#64748B',
    fontSize: 14,
    fontWeight: '500',
  },
  historyContainer: {
    backgroundColor: '#F1F5F9',
    padding: 16,
    borderRadius: 8,
    borderTopLeftRadius: 0,
    borderTopRightRadius: 0,
  },
  historyTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1E293B',
    marginBottom: 12,
  },
  historyItem: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
    borderLeftWidth: 3,
    borderLeftColor: '#2c95f8',
  },
  historyItemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  historyMenuName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1E293B',
    flex: 1,
  },
  historyDate: {
    fontSize: 12,
    color: '#64748B',
    fontWeight: '500',
    marginLeft: 8,
  },
  historyContent: {
    marginBottom: 8,
  },
  historyLine: {
    fontSize: 12,
    lineHeight: 16,
    marginBottom: 4,
  },
  historyCategoryName: {
    fontWeight: '600',
    color: '#2c95f8',
    marginRight: 4,
  },
  historyDishNames: {
    color: '#475569',
  },
  historyNote: {
    fontSize: 12,
    color: '#64748B',
    fontStyle: 'italic',
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#E2E8F0',
  },
  loadingContainer: {
    alignItems: 'center',
    padding: 20,
  },
  historyLoadingText: {
    fontSize: 14,
    color: '#64748B',
    textAlign: 'center',
    marginTop: 8,
  },
  emptyHistory: {
    alignItems: 'center',
    padding: 20,
  },
  noHistoryText: {
    fontSize: 14,
    color: '#64748B',
    textAlign: 'center',
    fontStyle: 'italic',
  },
});

export default PastHistory;