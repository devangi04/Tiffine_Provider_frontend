import { useEffect } from 'react';
import { useAppSelector } from '../app/store/hooks';
import { useRouter, usePathname } from 'expo-router';

const ProviderInitializer = () => {
  const provider = useAppSelector((state) => state.provider);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    const publicRoutes = ['/welcome', '/login', '/register', '/forgotpassword']; // ✅ allow welcome page too

    // ✅ If user not logged in and tries to access protected page → go to welcome
    if (!provider.id && !publicRoutes.includes(pathname)) {
      router.replace('/welcome');
    }

    // ✅ If user logged in and visits public page → go to dashboard
    if (provider.id && publicRoutes.includes(pathname)) {
      router.replace('/dashboard');
    }
  }, [provider.id, pathname]);

  return null;
};

export default ProviderInitializer;
